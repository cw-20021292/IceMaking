/*&&*//***********************************************************************************************************************
* Version      : BAS25(STEP_UP)   - TST02FQP2361500101
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "m_wifi_make_data.h"
#include	"WIFI_SetFunctionData.h"

/*..sean [25-02-12] enum �?가?�오�??�해??function list ?�더?�일 추�? ..*/
//#include	"WIFI_A101x_FunctionList.h"
//#include	"WIFI_Config.h"

void wifi_operation_control(void);
void send_wifi_data(void);
void check_water_out_state(void);
U8 check_error_state(void);
void make_wifi_app_data(void);
void wifi_water_select(void);
void avg_mixing_water_temp(void);
void silver_care(void);
void cody_care(void);
void power_check(void);
void init_wifi_elec_watt(void);
void water_quantity(void);
void init_water_quantity(void);
void send_wifi_system_function(void);
void send_wifi_manual_test_function(void);
void send_wifi_self_test_function(void);
void send_wifi_each_data_control( U8 mu8_data );
void send_wifi_water_select_data_control( U8 mu8_data );

void check_wifi_auto_drain_state(void);
void check_wifi_uv_state(void);
void wifi_ice_out_time(void);
void init_wifi_ice_out_time(void);

void wifi_water_level_state(void);
void check_cold_tank_low_level_state(void);
void check_cold_tank_high_level_state(void);
void wifi_ice_tank_ster_state(void);
void wifi_hot_heater_state(void);
void init_wifi_hot_heater(void);

void wifi_comp_state(void);
void init_wifi_comp(void);

void wifi_ice_full(void);
void wifi_ice_step(void);

void wifi_uv_water_tank_state(void);
void wifi_uv_ice_tank_state(void);
void wifi_uv_ice_tray_state(void);
void wifi_uv_ice_tank_front_state(void);

void wifi_no_use_save_mode(void);
void wifi_ice_data_all(void);
void init_wifi_ice_data_all(void);

void wifi_no_use_time(void);
void init_wifi_no_use_time(void);

void wifi_smart_save_state(void);
void wifi_sleep_mode(void);
void wifi_neo_filter_alarm(void);
void wifi_ro_filter_alarm(void);
void wifi_ino_filter_alarm(void);
void wifi_neo_ino_filter_alarm_start(void);
void wifi_neo_ino_filter_alarm_stop(void);
void wifi_neo_ro_ino_filter_alarm_start(void);
void wifi_neo_ro_ino_filter_alarm_stop(void);
void wifi_ice_ster(void);


void check_self_manual_state(void);
void check_prohibit_state(void);


TYPE_LONG          U32ErrOldW;
#define            u32ErrOld                               U32ErrOldW.dward
#define            Bit0_Err_Old_0                          U32ErrOldW.Bit.b0
#define            Bit1_Err_Old_1                          U32ErrOldW.Bit.b1
#define            Bit2_Err_Old_2                          U32ErrOldW.Bit.b2
#define            Bit3_Err_Old_3                          U32ErrOldW.Bit.b3
#define            Bit4_Err_Old_4                          U32ErrOldW.Bit.b4
#define            Bit5_Err_Old_5                          U32ErrOldW.Bit.b5
#define            Bit6_Err_Old_6                          U32ErrOldW.Bit.b6
#define            Bit7_Err_Old_7                          U32ErrOldW.Bit.b7
#define            Bit8_Err_Old_8                          U32ErrOldW.Bit.b8
#define            Bit9_Err_Old_9                          U32ErrOldW.Bit.b9
#define            Bit10_Err_Old_10                        U32ErrOldW.Bit.b10
#define            Bit11_Err_Old_11                        U32ErrOldW.Bit.b11
#define            Bit12_Err_Old_12                        U32ErrOldW.Bit.b12
#define            Bit13_Err_Old_13                        U32ErrOldW.Bit.b13
#define            Bit14_Err_Old_14                        U32ErrOldW.Bit.b14
#define            Bit15_Err_Old_15                        U32ErrOldW.Bit.b15
#define            Bit16_Err_Old_16                        U32ErrOldW.Bit.b16
#define            Bit17_Err_Old_17                        U32ErrOldW.Bit.b17
#define            Bit18_Err_Old_18                        U32ErrOldW.Bit.b18
#define            Bit19_Err_Old_19                        U32ErrOldW.Bit.b19
#define            Bit20_Err_Old_20                        U32ErrOldW.Bit.b20
#define            Bit21_Err_Old_21                        U32ErrOldW.Bit.b21
#define            Bit22_Err_Old_22                        U32ErrOldW.Bit.b22
#define            Bit23_Err_Old_23                        U32ErrOldW.Bit.b23
#define            Bit24_Err_Old_24                        U32ErrOldW.Bit.b24
#define            Bit25_Err_Old_25                        U32ErrOldW.Bit.b25
#define            Bit26_Err_Old_26                        U32ErrOldW.Bit.b26
#define            Bit27_Err_Old_27                        U32ErrOldW.Bit.b27
#define            Bit28_Err_Old_28                        U32ErrOldW.Bit.b28


TYPE_BYTE          U8WifiSendStateB;
#define            u8WifiSendState                         U8WifiSendStateB.byte
#define            Bit0_Wifi_Auto_Drain_Start_State        U8WifiSendStateB.Bit.b0
#define            Bit1_Wifi_UV_Start_State                U8WifiSendStateB.Bit.b1


bit F_Wifi_Tx_Condition;
bit F_Wifi_Each_Data_Tx_Condition;
U8 gu8_change_data;

bit F_Wifi_Self_Test_Tx_Condition;

bit F_Wifi_Self_Periodic_Tx_Condition;

U8 u8OutHot_Temp_AVG;             // ?�균 출수?�도�?(App??


U16 gu16_silver_timer_sec;
U16 gu16_silver_timer_min;
bit F_Siver_Care_Alarm;             // ?�버케???�비??진입 ?�래�?App??
U8 u8FirstSilverCare;


U8 gu8_cody_care_timer_msec;
U16 gu16_cody_care_timer_sec;


U16 gu16_hot_heater_watt;
U16 gu16_ice_heater_watt;
U16 gu16_comp_watt;
U16 gu16_wifi_total_watt;

U16 gu16_power_check_timer;


U16 gu16_wifi_normal_quant;
U16 gu16_wifi_hot_quant;
U16 gu16_wifi_total_quant;
U8 gu8_wifi_water_send_count;
U8 gu8_wifi_ice_send_count;

U8 gu8_Err_Code_Wifi;

bit F_Wifi_Water_Out;

bit F_Wifi_Flushing;


U8 gu8_hot_avg_timer;


bit F_Tank_Cover_Wifi;

bit F_Filter_Cover_Wifi;

U8 gu8_err_cnt;
U8 gu8_tx_cnt;


U8 gu8_wifi_uv_start;
U8 gu8_wifi_uv_operation;
U8 gu8_wifi_uv_step;

U8 gu8_wifi_uv_send_cnt;

U8 gu8_water_send_timer;

U16 gu16_wifi_water_acc;


U8 gu8_wifi_tds_update;


U8 gu8_wifi_auto_drain_op;
U8 gu8_wifi_first_auto_drain;

U8 gu8_wifi_uv_op;
U8 gu8_wifi_first_uv;



U8 gu8_before_faucet;


U8 gu8_wifi_self_test_op;
U8 gu8_wifi_self_test_state;
U8 gu8_wifi_self_test_progress;
U8 gu8_wifi_self_test_timer;

bit bit_wifi_self_test_finish;


U32 gu32_wifi_ice_out_time;
bit bit_first_ice_send;


U8 gu8_wifi_cold_low_on_timer;
U8 gu8_wifi_cold_low_off_timer;
bit bit_wifi_cold_low;
bit bit_wifi_first_cold_low;

U8 gu8_wifi_cold_high_on_timer;
U8 gu8_wifi_cold_high_off_timer;
bit bit_wifi_cold_high;
bit bit_wifi_first_cold_high;


bit bit_wifi_first_drain_low;
bit bit_wifi_first_drain_high;

bit bit_wifi_first_room_low;
bit bit_wifi_first_room_high;



bit bit_wifi_first_ice_tank_ster;
bit bit_wifi_ice_tank_ster_old;

bit bit_wifi_first_hot_heater;
bit bit_wifi_hot_heater;
bit bit_wifi_heater_on_time_update;

bit bit_wifi_first_comp;
bit bit_wifi_comp;
bit bit_wifi_comp_on_time_update;

U16 gu16_wifi_total_usage_water;

bit bit_wifi_first_ice_full;
bit bit_wifi_ice_full_old;


U8 gu8_wifi_ice_make_state;


bit bit_wifi_first_water_tank_uv;
bit bit_wifi_water_tank_uv_old;

bit bit_wifi_first_ice_tank_uv;
bit bit_wifi_ice_tank_uv_old;

bit bit_wifi_first_ice_tray_uv;
bit bit_wifi_ice_tray_uv_old;

bit bit_wifi_first_ice_tank_front_uv;
bit bit_wifi_ice_tank_front_uv_old;


U32 gu32_hot_target_reach_timer_ms;
U16 gu16_hot_target_reach_timer_sec;


U32 gu32_cold_target_reach_timer_ms;
U16 gu16_cold_target_reach_timer_sec;


U16 gu16_wifi_filter_remain_day;


bit bit_wifi_first_no_use_save;
bit bit_wifi_no_use_save_old;

bit bit_wifi_first_sleep;
bit bit_wifi_sleep_old;


U8 gu8_wifi_water_select;


U32 gu32_wifi_ice_make_time;
//U32 gu32_wifi_hot_gas_time;
U32 gu32_wifi_ice_heater_time;
U16 gu16_wifi_tray_in_time;
U16 gu16_wifi_tray_in_flow;
bit bit_wifi_ice_data_send;

U8 gu8_wifi_flushing_state;

U16 gu16_wifi_no_use_timer_sec;
U16 gu16_wifi_no_use_timer_min;
U8 gu8_wifi_no_use_key;
U8 gu8_wifi_no_use_time_send;

U8 gu8_smart_operation_mode_old;
bit bit_smart_first_send;
U8 gu8_wifi_smart_save;

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_operation_control(void)
{
    make_wifi_app_data();
    send_wifi_data();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_data(void)
{
    U8 mu8_error_change = 0;

    /*..hui [21-3-15?�후 7:08:48] �?추출 종룟 ??.*/
    check_water_out_state();

    /*..hui [21-8-3?�후 4:34:47] TDS�??�뎃?�으???�버 ?�송..*/
    if( gu8_wifi_tds_update == SET )
    {
        gu8_wifi_tds_update = CLEAR;
        send_wifi_system_function();
    }
    else{}

    /*..hui [21-9-6?�전 10:36:57] 고장진단 ?�태..*/
    check_self_manual_state();

    /*..hui [21-8-3?�후 7:26:37] 1. TDS 측정 ?�료?�을??.*/
    /*..hui [21-8-3?�후 7:26:52] 2. 버튼 - ?�체?�금 ?�정..*/
    /*..hui [21-8-3?�후 7:26:56] 3. 버튼 - ?�수?�금 ?�정..*/
    /*..hui [21-8-3?�후 7:27:06] 4. 버튼 - ?�수 ON/OFF ?�정..*/
    /*..hui [21-8-3?�후 7:27:14] 5. LCD - 기본?�량 ?�정..*/
    /*..hui [21-8-3?�후 7:27:20] 6. LCD - ?�수?�도 ?�정..*/
    /*..hui [21-8-3?�후 7:27:26] 7. LCD - ?�운???�정..*/
    /*..hui [21-8-3?�후 7:27:34] 8. LCD - ?�비?�모???�정..*/
    /*..hui [21-8-3?�후 7:27:41] 9. LCD - ?�우???�기시�??�정..*/
    /*..hui [21-8-3?�후 7:27:50] 10. LCD - ?�체?�금 ?�정 - CP�?.*/
    /*..hui [21-8-3?�후 7:28:05] 11. UV ?�균 ??.*/
    /*..hui [21-8-3?�후 7:28:08] 12. ?�동배수 ??.*/
    if( F_Wifi_Tx_Condition == SET )
    {
        // WifiSendData(WIFI_DATA_FUNCTION);
        F_Wifi_Tx_Condition = CLEAR;

        gu8_tx_cnt++;
    }
    else{}


    if( F_Wifi_Each_Data_Tx_Condition == SET )
    {
        /*..hui [23-6-28?�전 11:01:09] ?�품?�서 개별 ?�어�??�정 변경할??.*/
        // WifiSendDataControl(WIFI_DATA_FUNCTION_CONTROL, gu8_change_data);
        F_Wifi_Each_Data_Tx_Condition = CLEAR;

        gu8_tx_cnt++;
    }
    else{}


    if( F_Wifi_Self_Test_Tx_Condition == SET )
    {
        WifiSendData(WIFI_DATA_EXAMINE);
        F_Wifi_Self_Test_Tx_Condition = CLEAR;

        gu8_tx_cnt++;
    }
    else{}

    if( F_Wifi_Self_Periodic_Tx_Condition == SET )
    {
        // WifiSendData(WIFI_DATA_PART);
        F_Wifi_Self_Periodic_Tx_Condition = CLEAR;

        gu8_tx_cnt++;
    }
    else{}
//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

    mu8_error_change = check_error_state();

    if( mu8_error_change == SET )
    {
        // WifiSendData(WIFI_DATA_ERROR);
        gu8_err_cnt++;
    }
    else{}

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_water_out_state(void)
{
    /*..hui [21-3-5?�후 2:01:13] �?추출 종료????.*/
    if( F_WaterOut == SET )
    {
        if( F_Wifi_Water_Out == CLEAR )
        {
            F_Wifi_Water_Out = SET;
            gu8_water_send_timer = 0;

            /*..hui [21-9-8?�전 10:52:32] ?��?진단 금�?�??�기??보내?�걸�?.*/
            gu8_wifi_self_test_state = WIFI_SELF_TEST_PROHIBIT;
            gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;

            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( F_Wifi_Water_Out == SET )
        {
            gu8_water_send_timer++;

            if( gu8_water_send_timer >= 5 )
            {
                gu8_water_send_timer = 0;
                F_Wifi_Water_Out = CLEAR;
				
				gu8_wifi_self_test_state = WIFI_SELF_TEST_NO_OPERATION;

                /*..hui [21-11-2?�후 7:42:57] ?�수?�크 채우기까지 ?�나�??�수 ?�레???�에 �?추출 가?�한 지?�에..*/
                /*..hui [21-11-2?�후 7:43:20] �?추출???�났?�도 ?��?진단?� 금�??�태 ?��??�야??.*/
				//?�로?�콜 미적?�으�?변�??�정
                //if( gu8_flushing_mode == FLUSHING_NONE_STATE && F_Ice == CLEAR )
                //{
                //    gu8_wifi_self_test_state = WIFI_SELF_TEST_NO_OPERATION;
                //    gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;
                //}
                //else{}

                /*send_wifi_system_function();*/
				//?�로?�콜 미적?�으�?변�??�정
                //send_wifi_each_data_control( WIFI_FUNC_000D_WATER_OUTQUANTITY );
                /*..hui [24-1-9?�후 1:29:37] 1010보내�?1014까�? 보내�??�후 초기?�하기위??카운??.*/
                /*gu8_wifi_water_send_count = 0;*/
            }
            else{}
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 check_error_state(void)
{
    U8 mu8_return = 0;

    if( Bit0_Hot_Tank_Temp_Open_Short_Error == SET )
    {
        if( Bit0_Err_Old_0 != SET )
        {
            Bit0_Err_Old_0 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit0_Err_Old_0 == SET )
        {
            Bit0_Err_Old_0 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    /*..hui [21-3-12?�후 3:12:16] ?�수 ?�터 ?�서 ?�러..*/
    if( Bit1_Room_OverHeat_Error == SET )
    {
        if( Bit1_Err_Old_1 != SET )
        {
            Bit1_Err_Old_1 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit1_Err_Old_1 == SET )
        {
            Bit1_Err_Old_1 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit2_Room_Temp_Open_Short_Error == SET )
    {
        if( Bit2_Err_Old_2 != SET )
        {
            Bit2_Err_Old_2 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit2_Err_Old_2 == SET )
        {
            Bit2_Err_Old_2 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit3_Leakage_Sensor_Error == SET )
    {
        if( Bit3_Err_Old_3 != SET )
        {
            Bit3_Err_Old_3 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit3_Err_Old_3 == SET )
        {
            Bit3_Err_Old_3 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit4_Room_Low_Water_Level_Error == SET )
    {
        if( Bit4_Err_Old_4 != SET )
        {
            Bit4_Err_Old_4 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit4_Err_Old_4 == SET )
        {
            Bit4_Err_Old_4 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit5_Hot_Heater_OverHeat_Error == SET )
    {
        if( Bit5_Err_Old_5 != SET )
        {
            Bit5_Err_Old_5 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit5_Err_Old_5 == SET )
        {
            Bit5_Err_Old_5 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit9_Room_Level_Unbalance_Error == SET )
    {
        if( Bit9_Err_Old_9 != SET )
        {
            Bit9_Err_Old_9 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit9_Err_Old_9 == SET )
        {
            Bit9_Err_Old_9 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit10_Cold_Temp_Open_Short_Error == SET )
    {
        if( Bit10_Err_Old_10 != SET )
        {
            Bit10_Err_Old_10 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit10_Err_Old_10 == SET )
        {
            Bit10_Err_Old_10 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit11_Amb_Temp_Open_Short_Error == SET )
    {
        if( Bit11_Err_Old_11 != SET )
        {
            Bit11_Err_Old_11 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit11_Err_Old_11 == SET )
        {
            Bit11_Err_Old_11 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit12_Drain_Pump_Error == SET )
    {
        if( Bit12_Err_Old_12 != SET )
        {
            Bit12_Err_Old_12 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit12_Err_Old_12 == SET )
        {
            Bit12_Err_Old_12 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit13_Tray_Micro_SW_Dual_Detect_Error == SET )
    {
        if( Bit13_Err_Old_13 != SET )
        {
            Bit13_Err_Old_13 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit13_Err_Old_13 == SET )
        {
            Bit13_Err_Old_13 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit14_Tray_Micro_SW_Up_Move_Error == SET )
    {
        if( Bit14_Err_Old_14 != SET )
        {
            Bit14_Err_Old_14 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit14_Err_Old_14 == SET )
        {
            Bit14_Err_Old_14 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }

    if( Bit15_Tray_Micro_SW_Down_Move_Error == SET )
    {
        if( Bit15_Err_Old_15 != SET )
        {
            Bit15_Err_Old_15 = SET;
            mu8_return = SET;
        }
        else{}
    }
    else
    {
        if( Bit15_Err_Old_15 == SET )
        {
            Bit15_Err_Old_15 = CLEAR;
            mu8_return = SET;
        }
        else{}
    }
	
    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void make_wifi_app_data(void)
{
    /*..hui [23-9-25?�후 3:35:50] 7초후 복�??�에??보내면안??.*/
    /*..hui [23-9-25?�후 3:36:12] ??조작?�로 변경시?�만 A1014�?보내?�함..*/
    /*wifi_water_select();*/

    /*avg_mixing_water_temp();*/

    silver_care();

    cody_care();

    //filter_change();

    power_check();

    water_quantity();

    wifi_ice_out_time();

    wifi_water_level_state();

    wifi_hot_heater_state();

    wifi_comp_state();

    wifi_ice_full();

    wifi_ice_step();

    wifi_uv_water_tank_state();
    wifi_uv_ice_tank_state();
    wifi_uv_ice_tray_state();

    wifi_no_use_save_mode();

    /*..hui [23-8-29?�후 4:56:28] ?�음 ?�스??관???�이?�..*/
    wifi_ice_data_all();

    /*..hui [23-8-30?�전 9:48:04] ?�러??관???�이?�..*/
    //wifi_flushing();

    /*..hui [23-8-31?�후 2:48:21] ?�품 미사???�간..*/
    wifi_no_use_time();

    /*..hui [23-8-31?�후 2:48:27] ?�마???�전 ?�태\..*/
    wifi_smart_save_state();

    /*..hui [23-12-6?�전 10:39:35] 취침모드 ?�태..*/
    wifi_sleep_mode();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_water_select(void)
{
    #if 0
    /*..hui [23-8-2?�후 5:12:16] ?�온??변경상??추�?..*/
    /*..hui [23-8-2?�후 5:12:21] ?�???�건 1010�?보냄..*/
    if( u8WaterOutState != gu8_wifi_water_select )
    {
        gu8_wifi_water_select = u8WaterOutState;
        send_wifi_water_select_data_control( WIFI_FUNC_000B_WATER_SEL );
    }
    else{}
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void avg_mixing_water_temp(void)
{
    #if 0
    gu8_hot_avg_timer++;

    if( gu8_hot_avg_timer >= 10 )
    {
        gu8_hot_avg_timer = 0;
    }
    else
    {
        return;
    }

    /*..hui [23-6-26?�후 7:18:28] 미온??추출..*/
    if( F_WaterOut == SET && u8WaterOutState == HOT_WATER_SELECT )
    {
        if( gu8_hot_setting_temperature == HOT_SET_TEMP_2__170_oF_77_oC
            || gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )
        {
            u8OutHot_Temp_AVG += gu8_Mixing_Out_Temperature_One_Degree;
            u8OutHot_Temp_AVG = u8OutHot_Temp_AVG/2;
        }
        else{}
    }
    else{}
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void silver_care(void)
{
    if( F_WaterOut == SET )
    {
        gu16_silver_timer_sec = 0;
        gu16_silver_timer_min = 0;
        F_Siver_Care_Alarm = CLEAR;
    }
    else{}

    gu16_silver_timer_sec++;

    if( gu16_silver_timer_sec >= 600 )
    {
        gu16_silver_timer_sec = 0;
        gu16_silver_timer_min++;
    }
    else{}

    if( gu16_silver_timer_min >= SILVER_CARE_TIME_MIN )
    {
        gu16_silver_timer_min = SILVER_CARE_TIME_MIN;

        if( F_Siver_Care_Alarm != SET )
        {
            F_Siver_Care_Alarm = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void cody_care(void)
{
    #if 0
    /*..hui [21-3-5?�전 9:58:17] 커버 ?�힘..*/
    if( bit_filter_cover != F_Tank_Cover_Wifi )
    {
        F_Tank_Cover_Wifi = bit_filter_cover;
        send_wifi_system_function();
    }
    else{}
    #endif

    /*..hui [21-3-5?�전 9:58:17] 커버 ?�힘..*/
    if( F_Tank_Cover_Input != F_Tank_Cover_Wifi )
    {
        F_Tank_Cover_Wifi = F_Tank_Cover_Input;
        send_wifi_system_function();
    }
    else{}

    /*..hui [21-3-12?�후 4:50:57] ?�렸?�때�?카운??.*/
    if( F_Tank_Cover_Input == CLEAR )
    {
        gu8_cody_care_timer_msec++;

        if( gu8_cody_care_timer_msec >= 10 )
        {
            gu8_cody_care_timer_msec = 0;
            gu16_cody_care_timer_sec++;
        }
        else{}

        if( gu16_cody_care_timer_sec >= CODY_CARE_MAX_TIME )
        {
            gu16_cody_care_timer_sec = CODY_CARE_MAX_TIME;
        }
        else{}
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void power_check(void)
{
    /*..hui [21-8-3���� 3:15:27] ���� ����Ÿ�� 1�п� �ѹ��� ���� - �����̰�..*/
    /*..hui [23-6-28���� 10:57:18] 5�п� �ѹ��� �����°ɷ� ����.. �հ���..*/
    gu16_power_check_timer++;

    if( gu16_power_check_timer >= 10 )
    {
        gu16_power_check_timer = 0;
    }
    else
    {
        return;
    }
	//western AIS
    /*..hui [21-3-5���� 11:58:23] �¼����� 2920/3600 = 0.81 = 0.80 = 0.65..*/
    /*..hui [21-3-5���� 11:58:55] COMP 100/3600 = 0.027 = 0.03..*/
    /*..hui [21-3-5���� 11:59:18] Ż������ 150/3600 = 0.04..*/
    /*..hui [23-6-26���� 7:45:15] �¼����� 500/3600 = 0.138 = 0.138..*/
    /*..hui [23-7-25���� 5:15:15] �¼����� 430/3600 = 0.119..*/
	
	//Ro Lite

    /*..sean [21-3-5���� 11:58:23] �¼����� 2920/3600 = 0.81 = 0.80 = 0.65..*/
    /*..sean [21-3-5���� 11:58:55] COMP 100/3600 = 0.027 = 0.03..*/
    /*..sean [21-3-5���� 11:59:18] Ż������ 150/3600 = 0.04..*/
    /*..sean [23-6-26���� 7:45:15] �¼����� 250/3600 = 0.069 = 0.069..*/
    /*..sean [23-7-25���� 5:15:15] �¼����� 430/3600 = 0.06..*/
    if( pHEATER_HOT == SET )
    {
        gu16_hot_heater_watt += HOT_HEATER_WATT_FULL;

        /*..hui [21-10-15?�후 5:12:31] 최�? 50W ?�한..*/
        if( gu16_hot_heater_watt >=  MAX_HOT_HEATER_WATT )
        {
            gu16_hot_heater_watt = MAX_HOT_HEATER_WATT;
        }
        else{}
    }
    else{}

    if( F_Comp_Output == SET )
    {
        if( gu8_GasSwitch_Status == GAS_SWITCH_COLD )
        {
            /*..hui [23-11-9?�전 9:33:43] ?�기 30??초과. ?�각 90W == 90/3600 = 0.025..*/
            gu16_comp_watt += COMP_COLD_90_WATT;
        }
        else
        {
            /*..hui [23-11-9?�전 9:34:20] ?�기 30??초과. ?�음 80W == 80/3600 == 0.022..*/
            gu16_comp_watt += COMP_ICE_80_WATT;
        }
    }
    else{}

    if( gu16_comp_watt >= MAX_COMP_WATT )
    {
        gu16_comp_watt = MAX_COMP_WATT;
    }
    else{}

    gu16_wifi_total_watt = gu16_hot_heater_watt + gu16_comp_watt;

    if( gu16_wifi_total_watt >= MAX_TOTAL_WATT )
    {
        gu16_wifi_total_watt = MAX_TOTAL_WATT;
    }
    else{}

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_elec_watt(void)
{
    gu16_hot_heater_watt = 0;
    gu16_comp_watt = 0;
    gu16_wifi_total_watt = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void water_quantity(void)
{
    /*..hui [21-3-5?�후 12:36:51] 계산?� acc_water ?�용..*/
    /*gu16_wifi_total_quant = gu16_wifi_normal_quant + gu16_wifi_hot_quant;*/


    gu16_wifi_total_quant = gu16_wifi_water_acc;

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_water_quantity(void)
{
    gu16_wifi_total_quant = 0;
    gu16_wifi_water_acc = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_system_function(void)
{
    /*..hui [21-3-5?�후 2:03:48] WIFI ?�정 변�??�이?� ?�신..*/
    F_Wifi_Tx_Condition = SET;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_manual_test_function(void)
{
    /*..hui [21-3-5?�후 2:03:48] WIFI ?�정 변�??�이?� ?�신..*/
    F_Wifi_Self_Test_Tx_Condition = SET;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_self_test_function(void)
{
    F_Wifi_Self_Periodic_Tx_Condition = SET;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_each_data_control( U8 mu8_data )
{
    F_Wifi_Each_Data_Tx_Condition = SET;
    gu8_change_data = mu8_data;

    /*..hui [23-6-28?�전 11:01:09] ?�품?�서 개별 ?�어�??�정 변경할??.*/
    /*WifiSendDataControl(WIFI_DATA_FUNCTION_CONTROL, mu8_data);*/

    /*..hui [23-7-21?�후 6:55:28] 개별 ?�정 변경시?�는..*/
    /*..hui [23-7-21?�후 6:56:10] 개별 ?�정 변경시?�는 ?�체 ?�이?�도 ?�꼐 ?�송.. ?�과??.*/
    send_wifi_system_function();

    /*..hui [24-1-9?�후 1:29:37] 1010보내�?1014까�? 보내�??�후 초기?�하기위??카운??초기??.*/
	//header file ?�어?????�어???�체로 ?�정
    //if( gu8_change_data == WIFI_FUNC_000D_WATER_OUTQUANTITY )
    if( gu8_change_data == 13 )
    {
        gu8_wifi_water_send_count = 0;
    }
    //else if( gu8_change_data == WIFI_FUNC_0030_ICE_MAKETIME )
    else if( gu8_change_data == 48 )
    {
        gu8_wifi_ice_send_count = 0;
    }
    else{}
	
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void send_wifi_water_select_data_control( U8 mu8_data )
{
    F_Wifi_Each_Data_Tx_Condition = SET;
    gu8_change_data = mu8_data;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_wifi_auto_drain_state(void)
{
    #if 0
    if( bit_auto_drain_start == SET )
    {
        if( gu8_wifi_auto_drain_op == WIFI_AUTO_DRAIN_OPERATION_OFF )
        {
            gu8_wifi_auto_drain_op = WIFI_AUTO_DRAIN_OPERATION_ON;
            send_wifi_system_function();
        }
        else
        {
            if( gu8_wifi_auto_drain_op == WIFI_AUTO_DRAIN_OPERATION_ON )
            {
                gu8_wifi_auto_drain_op = WIFI_AUTO_OPERATION_GOING;
                send_wifi_system_function();
            }
            else{}
        }
    }
    else
    {
        if( gu8_wifi_auto_drain_op != WIFI_AUTO_DRAIN_OPERATION_OFF )
        {
            gu8_wifi_auto_drain_op = WIFI_AUTO_DRAIN_OPERATION_OFF;
            send_wifi_system_function();
        }
        else{}
    }
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_wifi_uv_state(void)
{
    #if 0
    /*..hui [21-9-9?�전 10:23:49] ?�시 ?��?중에??0?�로 보내�??�시?�할???�시~..*/
    if( F_UV_Control_State == SET && u8UvSensorOFF == 0 )
    {
        if( gu8_wifi_uv_op == WIFI_UV_OPERATION_OFF )
        {
            gu8_wifi_uv_op = WIFI_UV_OPERATION_ON;
            send_wifi_system_function();
        }
        else
        {
            if( gu8_wifi_uv_op == WIFI_UV_OPERATION_ON )
            {
                gu8_wifi_uv_op = WIFI_UV_OPERATION_GOING;
                send_wifi_system_function();
            }
            else{}
        }
    }
    else
    {
        if( gu8_wifi_uv_op != WIFI_UV_OPERATION_OFF )
        {
            gu8_wifi_uv_op = WIFI_UV_OPERATION_OFF;
            send_wifi_system_function();
        }
        else{}
    }
    #endif
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_ice_out_time(void)
{
    /*..hui [23-8-2?�후 4:48:04] ?�크�??�는 ?�간�?계산..*/
    if( F_Ice == SET && pMOTOR_ICE_OUT_CCW == SET )
    {
        gu32_wifi_ice_out_time++;

        if( gu32_wifi_ice_out_time >= MAX_ICE_OUT_TIME )
        {
            gu32_wifi_ice_out_time = MAX_ICE_OUT_TIME;
        }
        else{}

        bit_first_ice_send = SET;
    }
    else
    {
        if( gu32_wifi_ice_out_time >= 5 )
        {
            if( bit_first_ice_send == SET )
            {
                bit_first_ice_send = CLEAR;
                /*send_wifi_system_function();*/
				
				//header file ?�어?????�어???�체로 ?�정
				//send_wifi_each_data_control( WIFI_FUNC_0030_ICE_MAKETIME );
				//send_wifi_each_data_control( 48 );
            }
            else{}
        }
        else
        {
            gu32_wifi_ice_out_time = 0;
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_ice_out_time(void)
{
    gu32_wifi_ice_out_time = 0;

}
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_water_level_state(void)
{
    /*..hui [23-6-23?�후 4:45:23] ?�수 ?�?�위/만수?�만..*/
    /*..hui [23-6-23?�후 4:45:35] ?�레?�탱???�?�위/만수?�는 water_level ?�쪽?�서 처리..*/
    check_cold_tank_low_level_state();
    check_cold_tank_high_level_state();

}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_cold_tank_low_level_state(void)
{
    if( pLEVEL_PURIFY_LOW == SET )
    {
        gu8_wifi_cold_low_on_timer++;
        gu8_wifi_cold_low_off_timer = 0;

        if( gu8_wifi_cold_low_on_timer >= 20 )
        {
            gu8_wifi_cold_low_on_timer = 20;

            if( bit_wifi_cold_low == CLEAR )
            {
                bit_wifi_cold_low = SET;
                send_wifi_system_function();
            }
            else{}
        }
        else{}
    }
    else
    {
        gu8_wifi_cold_low_on_timer = 0;
        gu8_wifi_cold_low_off_timer++;

        if( gu8_wifi_cold_low_off_timer >= 20 )
        {
            gu8_wifi_cold_low_off_timer = 20;

            if( bit_wifi_cold_low == SET )
            {
                bit_wifi_cold_low = CLEAR;
                send_wifi_system_function();
            }
            else{}
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_cold_tank_high_level_state(void)
{
    if( pLEVEL_PURIFY_HIGH == SET )
    {
        gu8_wifi_cold_high_on_timer++;
        gu8_wifi_cold_high_off_timer = 0;

        if( gu8_wifi_cold_high_on_timer >= 20 )
        {
            gu8_wifi_cold_high_on_timer = 20;

            if( bit_wifi_cold_high == CLEAR )
            {
                bit_wifi_cold_high = SET;
                send_wifi_system_function();
            }
            else{}
        }
        else{}
    }
    else
    {
        gu8_wifi_cold_high_on_timer = 0;
        gu8_wifi_cold_high_off_timer++;

        if( gu8_wifi_cold_high_off_timer >= 20 )
        {
            gu8_wifi_cold_high_off_timer = 20;

            if( bit_wifi_cold_high == SET )
            {
                bit_wifi_cold_high = CLEAR;
                send_wifi_system_function();
            }
            else{}
        }
        else{}
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_hot_heater_state(void)
{
#if 1
    if( pHEATER_HOT == SET )
    /*if( F_Heater_Output == SET )*/
    {
        gu32_hot_target_reach_timer_ms++;

        if( gu32_hot_target_reach_timer_ms >= 99990 )
        {
            gu32_hot_target_reach_timer_ms = 99990;
        }
        else{}

        gu16_hot_target_reach_timer_sec = (U16)(gu32_hot_target_reach_timer_ms / 10);

        if( bit_wifi_hot_heater == CLEAR )
        {
            bit_wifi_hot_heater = SET;
            bit_wifi_heater_on_time_update = CLEAR;
            send_wifi_system_function();

            init_wifi_hot_heater();
        }
        else{}
    }
    else
    {
        if( bit_wifi_hot_heater == SET )
        {
            bit_wifi_hot_heater = CLEAR;
            bit_wifi_heater_on_time_update  = SET;
            send_wifi_system_function();
        }
        else{}
    }
#endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_hot_heater(void)
{
    gu32_hot_target_reach_timer_ms = 0;
    gu16_hot_target_reach_timer_sec = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_comp_state(void)
{
    if( F_Comp_Output == SET )
    {
        if( Bit0_Cold_Mode_On_State == SET )
        {
            gu32_cold_target_reach_timer_ms++;

            if( gu32_cold_target_reach_timer_ms >= 99990 )
            {
                gu32_cold_target_reach_timer_ms = 99990;
            }
            else{}

            gu16_cold_target_reach_timer_sec = (U16)(gu32_cold_target_reach_timer_ms / 10);
        }
        else
        {
            gu32_cold_target_reach_timer_ms = 0;
            gu16_cold_target_reach_timer_sec = 0;
        }

        if( bit_wifi_comp == CLEAR )
        {
            bit_wifi_comp = SET;
            bit_wifi_comp_on_time_update = CLEAR;
            send_wifi_system_function();

            init_wifi_comp();
        }
        else{}
    }
    else
    {
        if( bit_wifi_comp == SET )
        {
            bit_wifi_comp = CLEAR;
            bit_wifi_comp_on_time_update = SET;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_comp(void)
{
    gu32_cold_target_reach_timer_ms = 0;
    gu16_cold_target_reach_timer_sec = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_ice_full(void)
{
    if( F_IceFull == SET )
    {
        if( bit_wifi_ice_full_old == CLEAR )
        {
            bit_wifi_ice_full_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_ice_full_old == SET )
        {
            bit_wifi_ice_full_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_ice_step(void)
{
    if( gu8IceStep == STATE_0_STANDBY )
    {
        gu8_wifi_ice_make_state = WIFI_ICE_MAKING_STANDBY;
        // if( gu8_wifi_ice_make_state != WIFI_ICE_MAKING_STANDBY )
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_MAKING_STANDBY;
        //     send_wifi_system_function();
        // }
        // else{}
    }
    else if( gu8IceStep == STATE_20_WATER_IN_ICE_TRAY )
    {
        gu8_wifi_ice_make_state = WIFI_ICE_TRAY_IN_START;
        // if( gu8_wifi_ice_make_state != WIFI_ICE_TRAY_IN_START && gu8_wifi_ice_make_state != WIFI_ICE_TRAY_IN_ING )
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_TRAY_IN_START;
        //     send_wifi_system_function();
        // }
        // else
        // {
            // gu8_wifi_ice_make_state = WIFI_ICE_TRAY_IN_ING;
        // }
    }
    else if( gu8IceStep == STATE_31_MAIN_ICE_MAKING )
    {
        gu8_wifi_ice_make_state = WIFI_ICE_MAKING_START;
        // if( gu8_wifi_ice_make_state != WIFI_ICE_MAKING_START && gu8_wifi_ice_make_state != WIFI_ICE_MAKING_ING )
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_MAKING_START;
        //     send_wifi_system_function();
        // }
        // else
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_MAKING_ING;
        // }
    }
    else if( gu8IceStep == STATE_41_ICE_TAKE_OFF )
    {
        gu8_wifi_ice_make_state = WIFI_ICE_TAKE_OFF_START;
        // if( gu8_wifi_ice_make_state != WIFI_ICE_TAKE_OFF_START && gu8_wifi_ice_make_state != WIFI_ICE_TAKE_OFF_ING )
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_TAKE_OFF_START;
        //     send_wifi_system_function();
        // }
        // else
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_TAKE_OFF_ING;
        // }

    }
    else if( gu8IceStep == STATE_50_ICE_FULL_IR_CHECK )
    {
        gu8_wifi_ice_make_state = WIFI_ICE_MAKING_FINISH_START;
        // if( gu8_wifi_ice_make_state != WIFI_ICE_MAKING_FINISH_START && gu8_wifi_ice_make_state != WIFI_ICE_MAKING_FINISH_ING )
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_MAKING_FINISH_START;
        //     send_wifi_system_function();
        // }
        // else
        // {
        //     gu8_wifi_ice_make_state = WIFI_ICE_MAKING_FINISH_ING;
        // }
    }
    else
    {

    }


}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_uv_water_tank_state(void)
{
    if( bit_uv_water_tank_out == SET )
    {
        if( bit_wifi_water_tank_uv_old == CLEAR )
        {
            bit_wifi_water_tank_uv_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_water_tank_uv_old == SET )
        {
            bit_wifi_water_tank_uv_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_uv_ice_tank_state(void)
{
    if( bit_uv_ice_tank_out == SET )
    {
        if( bit_wifi_ice_tank_uv_old == CLEAR )
        {
            bit_wifi_ice_tank_uv_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_ice_tank_uv_old == SET )
        {
            bit_wifi_ice_tank_uv_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_uv_ice_tray_state(void)
{
    /*if( bit_uv_ice_tray_out == SET )*/
    if( bit_uv_ice_tray_out == SET && bit_ice_tray_making_enable == CLEAR )
    {
        if( bit_wifi_ice_tray_uv_old == CLEAR )
        {
            bit_wifi_ice_tray_uv_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_ice_tray_uv_old == SET )
        {
            bit_wifi_ice_tray_uv_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_no_use_save_mode(void)
{
    if( bit_9_hour_no_use_start == SET )
    {
        if( bit_wifi_no_use_save_old == CLEAR )
        {
            bit_wifi_no_use_save_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_no_use_save_old == SET )
        {
            bit_wifi_no_use_save_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_ice_data_all(void)
{
    /*..hui [23-8-29?�후 4:55:49] ?�빙 ?�료?�간 / ?�빙 ?�료?�간 / ?�레???�수 ?�간 / ?�레???�수 ?�량 ?�송..*/
    /*..hui [23-8-29?�후 4:55:54] ?�빙 ?�나�??�방??.*/
    if( gu8IceStep == STATE_50_ICE_FULL_IR_CHECK )
    {
        if( bit_wifi_ice_data_send == CLEAR )
        {
            bit_wifi_ice_data_send = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        bit_wifi_ice_data_send = CLEAR;

		//?�정 ?�요
		//if( gu8IceStep >= STATE_10_ICE_TRAY_MOVE_UP && gu8IceStep <= STATE_14_CHECK_ICE_TRAY_HZ )
        //{
        //   init_wifi_ice_data_all();
        //}
        //else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_ice_data_all(void)
{
    gu32_wifi_ice_make_time = 0;
    gu32_wifi_ice_heater_time = 0;
    gu16_wifi_tray_in_time = 0;
    gu16_wifi_tray_in_flow = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_no_use_time(void)
{
    if( gu8_wifi_no_use_key == SET )
    {
        gu8_wifi_no_use_key = 0;

        if( gu16_wifi_no_use_timer_min >= 10 )
        {
            send_wifi_system_function();
            gu8_wifi_no_use_time_send = SET;
        }
        else{}
    }
    else{}

    gu16_wifi_no_use_timer_sec++;

    if( gu16_wifi_no_use_timer_sec >= 600 )
    {
        gu16_wifi_no_use_timer_sec = 0;

        if( gu16_wifi_no_use_timer_min < 65535 )
        {
            gu16_wifi_no_use_timer_min++;
        }
        else{}
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_wifi_no_use_time(void)
{
    gu16_wifi_no_use_timer_sec = 0;
    gu16_wifi_no_use_timer_min = 0;

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_smart_save_state(void)
{
    if( gu8_smart_operation_mode_old != gu8_smart_operation_mode )
    {
        gu8_smart_operation_mode_old = gu8_smart_operation_mode;

        send_wifi_system_function();
        bit_smart_first_send = SET;
    }
    else{}
}
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_sleep_mode(void)
{
    if( bit_sleep_mode_start == SET )
    {
        if( bit_wifi_sleep_old == CLEAR )
        {
            bit_wifi_sleep_old = SET;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        if( bit_wifi_sleep_old == SET )
        {
            bit_wifi_sleep_old = CLEAR;
            send_wifi_system_function();
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_self_manual_state(void)
{
    check_prohibit_state();

    /*..hui [21-9-8?�전 10:54:00] ?��?진단 금�? ?�태?�경??리턴..*/
    if( gu8_wifi_self_test_state == WIFI_SELF_TEST_PROHIBIT )
    {
            	/* �� */
        bit_self_test_start = CLEAR;
        return;
    }
    else{}
	
	/* �� */
    if( bit_self_test_start == SET )
    //if(1)
    {
        switch( gu8_wifi_self_test_state )
        {
            case WIFI_SELF_TEST_NO_OPERATION:

                gu8_wifi_self_test_state = WIFI_SELF_TEST_START;
                gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;
                /*..hui [21-9-8?�전 10:23:33] ?�작?�면 ?�동?�로 ?�?�파?�쪽?�서 보냄..*/
                /*send_wifi_system_function();*/

                gu8_wifi_self_test_timer = 0;

            break;

            case WIFI_SELF_TEST_START:

                gu8_wifi_self_test_timer++;

                if( gu8_wifi_self_test_timer >= 3 )
                {
                    gu8_wifi_self_test_timer = 3;

                    /*if( gu8_self_test_manual_step >= 4 )*/
                    if( gu8_self_test_manual_step >= 4 )
                    {
                        gu8_wifi_self_test_timer = 0;
                        gu8_wifi_self_test_state = WIFI_SELF_TEST_ING;
                        gu8_wifi_self_test_progress = WIFI_SELF_TEST_10_PERCENT;
                        send_wifi_system_function();
                    }
                    else{}
                }
                else{}

            break;

            case WIFI_SELF_TEST_ING:

                if( gu8_self_test_manual_step == 4 )
                {
                    if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_10_PERCENT )
                    {
                        if( gu8_component_test_step >= 4 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_20_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_20_PERCENT )
                    {
                        if( gu8_component_test_step >= 6 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_30_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_30_PERCENT )
                    {
                        if( gu8_component_test_step >= 7 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_40_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_40_PERCENT )
                    {
                        if( gu8_component_test_step >= 8 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_50_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_50_PERCENT )
                    {
                        if( gu8_component_test_step >= 9 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_60_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_60_PERCENT )
                    {
                        if( gu8_component_test_step >= 10 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_70_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_70_PERCENT )
                    {
                        if( gu8_component_test_step >= 12 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_80_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_80_PERCENT )
                    {
                        if( gu8_component_test_step >= 14 )
                        {
                            gu8_wifi_self_test_progress = WIFI_SELF_TEST_90_PERCENT;
                            send_wifi_system_function();
                        }
                        else{}
                    }
                    else{}
                }
                else if( gu8_self_test_manual_step == 5 )
                {
                    if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_90_PERCENT )
                    {
                        gu8_wifi_self_test_progress = WIFI_SELF_TEST_100_PERCENT;
                        send_wifi_system_function();
                    }
                    else if( gu8_wifi_self_test_progress == WIFI_SELF_TEST_100_PERCENT )
                    {
                        gu8_wifi_self_test_state = WIFI_SELF_TEST_FINISH;
                        gu8_wifi_self_test_progress = WIFI_SELF_TEST_100_PERCENT;
                        send_wifi_system_function();
                    }
                    else{}
                }
                else{}

            break;

            case WIFI_SELF_TEST_FINISH:

                if( bit_wifi_self_test_finish == CLEAR )
                {
                    /*..hui [21-9-7?�후 4:26:34] 최종 결과 ?�이?� ?�송..*/
                    bit_wifi_self_test_finish = SET;
                }
                else{}

            break;

            case WIFI_SELF_TEST_STOP:


            break;

            default:


            break;
        }
    }
    else
    {
        /*..hui [21-9-7?�후 4:20:42] ?�나�?0?� ?�보?�줘????.*/
        gu8_wifi_self_test_timer = 0;
        gu8_wifi_self_test_state = WIFI_SELF_TEST_NO_OPERATION;
        gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;


        /*..hui [21-9-9?�후 4:11:13] 최종 결과?�이?��? ?�기??보내?�걸�?...*/
        /*..hui [21-9-9?�후 4:11:29] 최종 결과?�이??보내�?wifi 쪽에???�태?�보 ?�동?�로 ?�는 �?같음.....*/
        if( bit_wifi_self_test_finish == SET )
        {
            bit_wifi_self_test_finish = CLEAR;
            send_wifi_manual_test_function();
        }
        else{}
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_prohibit_state(void)
{
    /*..hui [23-12-22���� 10:28:58] �÷��� ���϶� ����..*/
    /*..hui [24-3-25���� 4:02:20] �������?�����߿��� ����..*/
    if( F_Ice == CLEAR )
    {
        if( bit_self_test_start != SET && F_WaterOut != SET && F_Ice != SET )
        {

            gu8_wifi_self_test_state = WIFI_SELF_TEST_NO_OPERATION;
            gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;
            send_wifi_system_function();
        }
        else{}
    }
    else
    {
        //gu8_wifi_self_test_state = WIFI_SELF_TEST_PROHIBIT;
        //gu8_wifi_self_test_progress = WIFI_SELF_TEST_0_PERCENT;
        //send_wifi_system_function();
    }
}


