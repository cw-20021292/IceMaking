/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Remote_Comm.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "Fan_Control.h"




void output_fan(void);



TYPE_BYTE          U8CoolingFanONB;
#define            u8CoolingFanON                                U8CoolingFanONB.byte
#define            Bit0_CF_Comp_Operation_State                  U8CoolingFanONB.Bit.b0
#define            Bit1_CF_Fan_Delay_Operation_State             U8CoolingFanONB.Bit.b1
#define            Bit2_CF_Fan_First_Operation_State             U8CoolingFanONB.Bit.b2
#define            Bit3_CF_Acid_Clean_Operation_State            U8CoolingFanONB.Bit.b3




TYPE_BYTE          U8CoolingFanOFFB;
#define            u8CoolingFanOFF                       U8CoolingFanOFFB.byte
//#define            Bit0_Filling_Valve_Error_State                U8CoolingFanOFFB.Bit.b0

U16 gu16_fan_delay_timer;

bit bit_fan_first;
U16 gu16_fan_first_timer;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void output_fan(void)
{
    if( bit_self_test_start == SET )
    {
        return;
    }
    else{}

    Bit0_CF_Comp_Operation_State = F_Comp_Output;

    if( F_Comp_Output == SET )
    {
        /*..hui [23-5-17���� 6:40:40] �ܱ� �µ� 39�� �̻��� ��� COMP OFF�ǵ� 10�� ���� �� ���� �߰�..*/
        /*..hui [23-5-17���� 6:40:51] ������ ���¿��� COMP Ʈ�� ����.. �õ�..*/
        /*if( gu8_Amb_Temperature_One_Degree >= 39 )*/
        /*..hui [23-7-12���� 11:28:04] �ܱ� 34�� �̻��ϰ�� COMP OFF �ϰ� 5�� �߰� ���� �� ����..*/
        /*..sean [25-02-24] ���� �������� 30 �̻��� ��� fan �߰� ����..*/
        if( gu8_Amb_Temperature_One_Degree >= 30 )
        {
            Bit1_CF_Fan_Delay_Operation_State = SET;
            gu16_fan_delay_timer = 0;
        }
        else{}
    }
    else
    {
        if( Bit1_CF_Fan_Delay_Operation_State == SET )
        {
            gu16_fan_delay_timer++;

            /*..hui [23-5-17���� 6:40:17] 10�� ���� ���� �� FAN ����..*/
            if( gu16_fan_delay_timer >= FAN_DELAY_10_MIN )
            {
                gu16_fan_delay_timer  = 0;
                Bit1_CF_Fan_Delay_Operation_State = CLEAR;
            }
            else{}
        }
        else
        {
            gu16_fan_delay_timer = 0;
        }
    }

    if( bit_fan_first == CLEAR )
    {
        gu16_fan_first_timer++;

        /*..hui [23-7-12���� 11:21:08] ó�� �����Ѱ� ����Ż�� �� 5�е��� FAN ���� - ��������..*/
        if( gu16_fan_first_timer >= 3000 )
        {
            bit_fan_first = SET;

            gu16_fan_first_timer = 0;
            Bit2_CF_Fan_First_Operation_State = CLEAR;
        }
        else
        {
            Bit2_CF_Fan_First_Operation_State = SET;
        }
    }
    else
    {
        gu16_fan_first_timer = 0;
        Bit2_CF_Fan_First_Operation_State = CLEAR;
    }

/***********************************************************************************************/
    if (u8CoolingFanOFF > 0)
    {
        pDC_FAN = CLEAR;  /*off*/
    }
    else
    {
        if (u8CoolingFanON > 0)
        {
            pDC_FAN = SET; /*on*/
        }
        else
        {
            pDC_FAN = CLEAR;  /*off*/
        }
    }
/***********************************************************************************************/
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


