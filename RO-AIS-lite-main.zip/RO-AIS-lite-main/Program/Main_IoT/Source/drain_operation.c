/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "drain_operation.h"



void output_drain_pump(void);
void drain_pump_output_decision(void);
void detect_drain_tank_high_level( void );
void drain_operation(void);
void drain_operation_24hour(void);
//void IceWaterExtrate(void);
void drain_retry_operation(void);
void keep_3_hour_check(void);
void ice_full_condition_check(void);
void detect_drain_pump_error(void);
U8 drain_pump_error_retry_proc( void );
void forced_drain_check(void);
void ice_off_check(void);
void first_drain_check(void);
void start_drain_pump( U16 u16_data );
void stop_drain_pump( void );
void check_empty_ice_tray_in(void);





TYPE_BYTE          U8DrainOperateB;
#define            u8DrainOperate                       U8DrainOperateB.byte
#define            Bit0_Drain_Level_Full                U8DrainOperateB.Bit.b0
#define            Bit1_Drain_Low_3_Hour                U8DrainOperateB.Bit.b1
#define            Bit2_Drain_Ice_Full                  U8DrainOperateB.Bit.b2
#define            Bit3_Drain_Forced                    U8DrainOperateB.Bit.b3
#define            Bit4_Drain_Ice_Tray_In               U8DrainOperateB.Bit.b4
#define            Bit5_Drain_Ice_Off                   U8DrainOperateB.Bit.b5
#define            Bit6_Drain_First                     U8DrainOperateB.Bit.b6



TYPE_BYTE          U8DrainPumpONB;
#define            u8DrainPumpON                        U8DrainPumpONB.byte
#define            Bit0_Drain_Tank_Level_Full_State     U8DrainPumpONB.Bit.b0
#define            Bit1_Drain_Error_Check_On_State      U8DrainPumpONB.Bit.b1
#define            Bit2_Drain_3_hour_State              U8DrainPumpONB.Bit.b2
#define            Bit3_Drain_ice_full_State            U8DrainPumpONB.Bit.b3
#define            Bit4_Auto_drain_State                U8DrainPumpONB.Bit.b4



TYPE_BYTE          U8DrainPumpOFFB;
#define            u8DrainPumpOFF                       U8DrainPumpOFFB.byte
#define            Bit0_Drain_Error_Check_Off_State     U8DrainPumpOFFB.Bit.b0
#define            Bit1_Drain_Error_Confirm_State       U8DrainPumpOFFB.Bit.b1
#define            Bit2_Bldc_Over_Current_Off_State     U8DrainPumpOFFB.Bit.b2


U8 gu8drain_1s_time;


U16 gu16_drain_pump_first_op_timer;
U8 gu8drain_pump_error_retry_chk_mode;

U16 gu16_drain_pump_1min_off_timer;
U16 gu16_drain_pump_2min_on_timer;

U16 gu16_drain_low_water_1min_tmr;
U16 gu16_drain_low_water_3hour_tmr;


U16 gu16_over_current_off_timer;
U16 gu16_over_current_detect_timer;



bit F_Drain_Pump_Output;


U8 gu8_drain_err_10_count;

bit F_old_ice_full;
bit F_old_ice_on;

U16 gu16_ice_off_drain_timer;

//bit Bit2_Drain_Ice_Full;

bit F_drain_err_check_on_state;
bit F_drain_err_check_off_state;


bit F_drain_error_check_enable;

U8 gu8_drain_pump_max_operation_count;

bit bit_first_drain;

bit F_forced_drain_enable;

U8 gu8_forced_drain_add_timer;


bit F_Drain_Pump_Output;

U16 gu16_drain_pwm_out;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 dbg_drainpump;
U16 dbg_pumppwmVal;
void output_drain_pump(void)
{
    /*..hui [17-12-18���� 5:49:56] �巹������ ���� Ȯ��..*/
    detect_drain_pump_error();
/*	
	if(pLEVEL_ICE_DRAIN_LOW == CLEAR)
		{
	F_drain_err_check_on_state = CLEAR;
		}
*/
    /*..hui [17-12-18���� 5:50:02] ���� ��� ����..*/
    drain_pump_output_decision();

	//for test
	if(dbg_drainpump == SET)
	{
        start_drain_pump( dbg_pumppwmVal ); /*on*/

		return;
	}

    if( u8DrainPumpOFF > 0 )
    {
        stop_drain_pump();  /*off*/
        gu8_drain_pump_max_operation_count = 0;
        F_Drain_Pump_Output = CLEAR;
		Bit5_Drain_Pump_12V_Out_State = CLEAR;
    }
    else
    {
        if( u8DrainPumpON > 0 )
        {
        	Bit5_Drain_Pump_12V_Out_State = SET;
            /*..hui [18-1-30���� 3:11:35] ���� �ʹ� 3�ʵ��� max�� �����ϴٰ� �� 66%�� ����.. ..*/
            /*..hui [18-1-30���� 3:11:53] �ٸ����� 75%��� �������� �����δ� 66%��..*/
            gu8_drain_pump_max_operation_count++;

            if(gu8_drain_pump_max_operation_count >= DRAIN_PUMP_MAX_OP_TIME)
            {
                gu8_drain_pump_max_operation_count = DRAIN_PUMP_MAX_OP_TIME;

                /*..hui [18-7-19���� 1:31:20] ��õ� 10ȸ �� 2ȸ°���ʹ� Full duty�� �����Ѵ�...*/
                /*..hui [18-7-19���� 1:31:46] ��� �ȵǼ� ���� �߻��ϴ� �� ���� �������°� �� ����....*/
                if(gu8_drain_err_10_count >= DRAIN_PUMP_MAX_OUTPUT_ERROR_COUNT)
                {
                    start_drain_pump( DRAIN_PUMP_PWM_MAX ); /*on*/
                }
                else
                {
                    start_drain_pump( DRAIN_PUMP_PWM_OP ); /*on*/
                }
            }
            else
            {
                start_drain_pump( DRAIN_PUMP_PWM_MAX ); /*on*/
            }

            F_Drain_Pump_Output = SET;
        }
        else
        {
            stop_drain_pump(); /*off*/
            gu8_drain_pump_max_operation_count = 0;
            F_Drain_Pump_Output = CLEAR;
        }
    }


}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void drain_pump_output_decision(void)
{
	//Bit4_Auto_drain_State = SET;
	//return;
/***************************************************************************************************/

    /*..hui [18-1-14���� 8:57:59] ��ȯ��� ��� �������϶��� ����üũ ����..*/
    Bit1_Drain_Error_Check_On_State = F_drain_err_check_on_state & ~F_DrainStatus;

    Bit4_Auto_drain_State = F_auto_drain_mode_pump_out;

/***************************************************************************************************/
    Bit0_Drain_Error_Check_Off_State = F_drain_err_check_off_state & ~F_DrainStatus;

    Bit1_Drain_Error_Confirm_State = Bit12_Drain_Pump_Error;
#if 1
    /*..hui [23-7-7���� 12:06:47] BLDC �������� OFF ������ �ٽ� ����� ��..*/
	/*..sean [25-3-18] bldc pump ���� �ǵ�� ���� �ʿ�..*/
    //if( Bit1_Drain_Error_Check_On_State == SET && Bit2_Bldc_Over_Current_Off_State == CLEAR )
    if( pLEVEL_ICE_DRAIN_LOW == SET && Bit2_Bldc_Over_Current_Off_State == CLEAR )
    {
        if( gu16_AD_Drain_Pump_Current <= PUMP_OVER_CURRENT_ADC )
        {
            gu16_over_current_detect_timer++;

            if( gu16_over_current_detect_timer >= PUMP_OVER_CURRENT_DETECT_TIME )
            {
                gu16_over_current_detect_timer = 0;
                gu16_over_current_off_timer = 0;
                Bit2_Bldc_Over_Current_Off_State = SET;
            }
            else{}
        }
        else
        {
            gu16_over_current_detect_timer = 0;
            gu16_over_current_off_timer = 0;
        }
    }
    else
    {
        if( Bit2_Bldc_Over_Current_Off_State == SET )
        {
            gu16_over_current_off_timer++;

            if( gu16_over_current_off_timer >= PUMP_OVER_CURRENT_OFF_TIME )
            {
                gu16_over_current_detect_timer = 0;
                gu16_over_current_off_timer = 0;
                Bit2_Bldc_Over_Current_Off_State = CLEAR;
            }
            else{}
        }
        else
        {
            gu16_over_current_detect_timer = 0;
            gu16_over_current_off_timer = 0;
        }
    }
#endif
    #if 0
    /*..hui [19-10-23���� 10:59:24] �¼� �巹�� �Ǵ� �����߿� �ǵ��� �ݴ´�..*/
    /*..hui [19-10-23���� 10:59:34] ��� ���� �����ؼ� �� �ɸ�..*/
    /*..hui [19-10-23���� 11:12:41] �巹�������� �����Ѵ�..*/
    if(F_WaterOut == SET)
    {
        if(u8WaterOutState == HOT_WATER_SELECT)
        {
            Bit2_Hot_Water_Drain_Off_State = F_WaterOut;
        }
        else
        {
            Bit2_Hot_Water_Drain_Off_State = CLEAR;
        }
    }
    else
    {
        Bit2_Hot_Water_Drain_Off_State = CLEAR;
    }
    #endif

    #if 0
    if( F_First_Hot_Effluent == SET )
    {
        Bit3_Hot_Filling_Drain_Off_State = bit_hot_filling_start;
    }
    else
    {
        Bit3_Hot_Filling_Drain_Off_State = CLEAR;
    }
    #endif

    #if 0
    /*..hui [20-4-8���� 8:18:56] �¼� ���� ��..*/
    if( Bit5_Hot_Heater_OverHeat_Error == SET )
    {
        Bit4_Hot_Cooling_Drain_Off_State = bit_hot_colling_start;
    }
    else
    {
        Bit4_Hot_Cooling_Drain_Off_State = CLEAR;
    }
    #endif
/***************************************************************************************************/

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_full_condition_check(void)
{
    /*..hui [18-1-8���� 3:50:20] ���� �������� �߰�..*/
    if(F_IceFull == SET)
    {
        if(F_old_ice_full != F_IceFull)
        {
            F_old_ice_full = F_IceFull;

            if(u8DrainWaterLevel >= DRAIN_LEVEL_LOW)
            {
                Bit2_Drain_Ice_Full = SET;
            }
            else
            {
                Bit2_Drain_Ice_Full = CLEAR;
            }
        }
        else
        {
            if(Bit2_Drain_Ice_Full == SET)
            {
                if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
                {
                    Bit2_Drain_Ice_Full = CLEAR;
                }
                else{}
            }
            else
            {

            }
        }
    }
    else
    {
        F_old_ice_full = CLEAR;

        if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
        {
            Bit2_Drain_Ice_Full = CLEAR;
        }
        else{}
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void keep_3_hour_check(void)
{
    /*..hui [17-12-18���� 1:05:30] ������ ���� 3�ð� �̻� ������ ������ �̰������� ��� ..*/
    if(u8DrainWaterLevel == DRAIN_LEVEL_LOW)
    {
        /*..hui [17-12-18���� 1:16:57] �巹������ �����߿��� ī��Ʈ ����..*/
        if(Bit1_Drain_Low_3_Hour == SET)
        {

        }
        else
        {
            gu16_drain_low_water_1min_tmr++;
        }

        if(gu16_drain_low_water_1min_tmr >= 600)
        {
            gu16_drain_low_water_1min_tmr = 0;

            gu16_drain_low_water_3hour_tmr++;

            if(gu16_drain_low_water_3hour_tmr >= 180)
            {
                Bit1_Drain_Low_3_Hour = SET;
                gu16_drain_low_water_3hour_tmr = 0;
            }
            else{}
        }
        else{}
    }
    else
    {
        if(Bit1_Drain_Low_3_Hour == SET)
        {
            if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
            {
                Bit1_Drain_Low_3_Hour = CLEAR;
            }
            else{}
        }
        else
        {
            gu16_drain_low_water_1min_tmr = 0;
            gu16_drain_low_water_3hour_tmr = 0;
        }
    }
}



#if 0
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 detect_drain_tank_high_level( U8 mu8_current_state )
{
    U8 mu8_return = 0;

    /*..hui [17-12-15���� 10:40:27] ������ ������ ������ �̰����ɶ����� �巹������ ����..*/
    /*..hui [17-12-18���� 10:27:56] �������� ������(������ �̰���,������ ����)���� ��� ����..*/
    if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH || u8DrainWaterLevel == DRAIN_LEVEL_ERROR)
    {
        mu8_current_state = SET;
    }
    else
    {
        if(Bit0_Drain_Tank_Level_Full_State == SET)
        {
            if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
            {
                mu8_current_state = CLEAR;
            }
            else{}
        }
        else{}
    }

    return mu8_current_state;

}
#endif

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void detect_drain_tank_high_level( void )
{
    U8 mu8_return = 0;

    /*..hui [17-12-15���� 10:40:27] ������ ������ ������ �̰����ɶ����� �巹������ ����..*/
    /*..hui [17-12-18���� 10:27:56] �������� ������(������ �̰���,������ ����)���� ��� ����..*/
    if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH || u8DrainWaterLevel == DRAIN_LEVEL_ERROR)
    {
        Bit0_Drain_Level_Full = SET;
    }
    else
    {
        if(Bit0_Drain_Level_Full == SET)
        {
            if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
            {
                Bit0_Drain_Level_Full = CLEAR;
            }
            else{}
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_off_check(void)
{
    /*..hui [19-12-2���� 2:07:02] ���� ��� ON->OFF�� ��� ������ �̻��̸� �巹�� ���� ����..*/
    /*if(F_IceOn == CLEAR)*/

    /*if( gu8_ice_setting == ICE_SETTING_OFF )*/
    if(F_IceOn == CLEAR)
    {
        if( F_old_ice_on == SET )
        {
            F_old_ice_on = CLEAR;

            if(u8DrainWaterLevel >= DRAIN_LEVEL_LOW)
            {
                Bit5_Drain_Ice_Off = SET;
            }
            else
            {
                Bit5_Drain_Ice_Off = CLEAR;
            }
        }
        else
        {
            if(Bit5_Drain_Ice_Off == SET)
            {
                if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
                {
                    Bit5_Drain_Ice_Off = CLEAR;
                }
                else{}
            }
            else{}
        }
    }
    else
    {
        F_old_ice_on = SET;

        if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
        {
            Bit5_Drain_Ice_Off = CLEAR;
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_empty_ice_tray_in(void)
{
    /*..hui [19-12-2���� 2:04:44] ������.. ��� ����..*/
    if(gu8IceStep > STATE_0_STANDBY
        && gu8IceStep <= STATE_12_CHECK_DRAIN_LEVEL)
    {
        if(u8DrainWaterLevel > DRAIN_LEVEL_EMPTY)
        {
            Bit4_Drain_Ice_Tray_In = SET;
        }
        else
        {
            if(Bit4_Drain_Ice_Tray_In == SET)
            {
                if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
                {
                    Bit4_Drain_Ice_Tray_In = CLEAR;
                }
                else{}
            }
            else{}
        }
    }
    else
    {
        Bit4_Drain_Ice_Tray_In = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void first_drain_check(void)
{
    /*..hui [23-4-4���� 2:35:55] �巹�� ��ũ ���� �д½ð� ���..*/
    if(F_FW_Version_Display_Mode == CLEAR)
    {
        return;
    }
    else{}

    if( bit_first_drain == SET )
    {
        bit_first_drain = CLEAR;

        if(u8DrainWaterLevel == DRAIN_LEVEL_LOW)
        {
            Bit6_Drain_First = SET;
        }
        else
        {
            Bit6_Drain_First = CLEAR;
        }
    }
    else
    {
        if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
        {
            Bit6_Drain_First = CLEAR;
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void detect_drain_pump_error(void)
{
    U8 mu8_error_chk_enable = 0;

    /*..hui [17-12-15���� 10:40:27] ������ ������ ������ �̰����ɶ����� �巹������ ����..*/
    /*..hui [17-12-18���� 1:19:04] �������� ������ ���� �߰�..*/
    detect_drain_tank_high_level();

    /*..hui [17-12-18���� 5:49:40] ������ 3�ð� ���� Ȯ��..*/
    keep_3_hour_check();

    /*..hui [17-12-18���� 5:49:47] ���� ���� Ȯ��..*/
    ice_full_condition_check();

    /*..hui [19-12-2���� 2:16:19] ������� OFF üũ..*/
    ice_off_check();

    /*..hui [18-2-12���� 4:08:15] ��ũ ���� ��� ��� ���� Ȯ��..*/
    forced_drain_check();

    /*..hui [23-4-4���� 2:38:22] ���� ���� ON�� �巹�� ������ ���� �����̸� ����.. �����ܾ��̽� ��� �߰�..*/
    first_drain_check();

    /*check_empty_ice_tray_in();*/

    /*..hui [18-1-22���� 4:34:56] ��ȯ��� ��� �۵����϶� �������� �ʵ��� ����..*/
    /*..hui [19-10-23���� 11:39:05] �¼� �������϶��� �����ߴ� ó������ �ٽ� ����(���� ��)..*/
    /*..hui [20-4-21���� 12:30:57] ù�ܵ巹�� �� ���� �𸵽� �巹�� ���� �� �ٽ� ���� �߰�..*/
    /*..hui [23-4-4���� 2:40:31] ���� ���� ON�� �������ϰ�� ���� �߰� - �����ܾ��̽� ��� - �ŷڼ�..*/
    F_drain_error_check_enable
        = ( ( Bit0_Drain_Level_Full | Bit1_Drain_Low_3_Hour
              | Bit2_Drain_Ice_Full | Bit3_Drain_Forced | Bit5_Drain_Ice_Off | Bit6_Drain_First )
              & ~F_DrainStatus );


    if(F_drain_error_check_enable == SET)
    {
        mu8_error_chk_enable = SET;
    }
    else
    {
        mu8_error_chk_enable = CLEAR;
    }

    if(mu8_error_chk_enable != SET || Bit12_Drain_Pump_Error == SET)
    {
        gu16_drain_pump_first_op_timer = 0;
        gu8drain_pump_error_retry_chk_mode = DRAIN_PUMP_OFF_PROC;
        gu16_drain_pump_2min_on_timer = 0;
        gu16_drain_pump_1min_off_timer = 0;
        F_drain_err_check_on_state = CLEAR;
        F_drain_err_check_off_state = CLEAR;
        gu8_drain_err_10_count = 0;
    }
    else
    {
        gu16_drain_pump_first_op_timer++;

        if(gu16_drain_pump_first_op_timer >= DRAIN_ERROR_PUMP_ON_10_MIN)   //10min
        {
            gu16_drain_pump_first_op_timer = DRAIN_ERROR_PUMP_ON_10_MIN;

            F_drain_err_check_on_state = drain_pump_error_retry_proc();
            F_drain_err_check_off_state = ~F_drain_err_check_on_state;
        }
        else
        {
            F_drain_err_check_on_state = SET;
            F_drain_err_check_off_state = CLEAR;
        }
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 drain_pump_error_retry_proc( void )
{
    U8 mu8_return = CLEAR;

    /*..hui [17-12-18���� 3:29:43] 10�� �����ص� ������ ������ �ȵǸ� 2�� ON, 1�� OFF 10ȸ �ݺ�..*/
    switch(gu8drain_pump_error_retry_chk_mode)
    {
        case DRAIN_PUMP_OFF_PROC :

            gu16_drain_pump_1min_off_timer++;

            if(gu16_drain_pump_1min_off_timer >= DRAIN_ERROR_PUMP_OFF_1_MIN)
            {
                gu16_drain_pump_1min_off_timer = 0;
                gu16_drain_pump_2min_on_timer = 0;
                gu8drain_pump_error_retry_chk_mode = DRAIN_PUMP_ON_PROC;
                /*mu8_return = SET;*/

                if(gu8_drain_err_10_count >= 10)
                {
                    /*..hui [17-12-18���� 5:33:37] ���� set..*/
                    gu8_drain_err_10_count = 0;

                    Bit12_Drain_Pump_Error = SET;
                    mu8_return = CLEAR;
                }
                else
                {
                    mu8_return = SET;
                }

            }
            else
            {
                mu8_return = CLEAR;
            }

            break;

        case DRAIN_PUMP_ON_PROC :

            gu16_drain_pump_2min_on_timer++;

            if(gu16_drain_pump_2min_on_timer >= DRAIN_ERROR_PUMP_ON_2_MIN)
            {
                gu16_drain_pump_1min_off_timer = 0;
                gu16_drain_pump_2min_on_timer = 0;
                gu8drain_pump_error_retry_chk_mode = DRAIN_PUMP_OFF_PROC;

                gu8_drain_err_10_count++;
                mu8_return = CLEAR;
            }
            else
            {
                mu8_return = SET;
            }

            break;

        default :
             //
             mu8_return = CLEAR;
            break;
    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void forced_drain_check(void)
{
    /*..hui [18-2-12���� 4:13:12] ������ũ, �ü���ũ �������϶� �巹����ũ�� ������ �̻��̸� ������� ��� ����..*/
    if( u8DrainWaterLevel >= DRAIN_LEVEL_LOW
        && gu8_Room_Water_Level == ROOM_LEVEL_LOW
        && F_Tank_Cover_Input == CLEAR
        && F_Overflow == CLEAR )
    {
        Bit3_Drain_Forced = SET;
        gu8_forced_drain_add_timer = 0;
    }
    else
    {
        if(Bit3_Drain_Forced == SET)
        {
            if(u8DrainWaterLevel == DRAIN_LEVEL_EMPTY)
            {
                gu8_forced_drain_add_timer++;

                /*..hui [18-2-12���� 4:14:14] ��� �Ϸ� �� 10�� �߰� ���..*/
                if(gu8_forced_drain_add_timer >= FORCED_DRAIN_ADDITIONAL_TIME)
                {
                    gu8_forced_drain_add_timer = 0;
                    Bit3_Drain_Forced = CLEAR;
                }
                else
                {
                    Bit3_Drain_Forced = SET;
                }
            }
            else{}
        }
        else
        {
            gu8_forced_drain_add_timer = 0;
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void start_drain_pump( U16 u16_data )
{
    gu16_drain_pwm_out = u16_data;
    TDR06 = gu16_drain_pwm_out;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void stop_drain_pump( void )
{
    gu16_drain_pwm_out = 0;
    TDR06 = gu16_drain_pwm_out;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/



