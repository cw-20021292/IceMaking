/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Output.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "M5_Output.h"

void Output(void);
//void output_swing_bar(void);
//void IceWaterExtrate(void);
//void output_feed_valve(void);
void output_valve_ice_tray(void) ;
//void CyclePump(void);
//void start_drain_pump( U16 u16_data );
//void stop_drain_pump( void );
void output_valve(void);
void output_pump(void);








bit F_IceWaterExt;
U8 gu8IceWaterExtDelay;
bit F_IceWaterExt_Set;


bit F_LineTestEnd;


U8 u8_system_init_timer;

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Output(void)
{
    output_swing_bar();

    output_ac_motor();

    output_comp_control();

    output_fan();

    output_pump();

    output_valve();

    ControlGasSwitch();

    /*..hui [19-10-24���� 7:59:26] UV ���� ��� �߰�..*/
    /*output_uv_sensor();*/
    output_ice_tank_uv();
    output_faucet_uv();
	//output_ice_extraction_uv();

	/*.. sean [24-09-30] ���� ���ⱸ UV �߰� ..*/
	output_ice_extraction_uv();
    /*..hui [19-12-19���� 2:15:31] ����/�ü� ���� ���� ON/OFF ��� �߰�..*/
    output_temp_power();

    /*..hui [23-3-24���� 11:26:27] �ν�Ʈ ���� ��� �߰�..*/
    output_boost_pump();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void output_pump(void)
{
    if( bit_self_test_start == SET )
    {
        return;
    }
    else{}
	
    output_drain_pump();

    /*..hui [23-2-6���� 11:00:45] Ʈ���� ����.. �¼� ���������� ����..*/
    output_tray_pump();
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void output_valve(void)
{
    /*..hui [19-7-18���� 5:01:36] ���� �� ���������� ��ٸ���..*/
    if(u8_system_init_timer < 50)
    {
        u8_system_init_timer++;
        return;
    }
    else
    {
        u8_system_init_timer = 50;
    }

    if( bit_self_test_start == SET )
    {
        return;
    }
    else{}

    /*..hui [19-6-21���� 4:38:48] �ǵ��� ���..*/
    output_valve_feed();
    /*..hui [19-6-21���� 4:38:53] �뽺��� ���..*/
    output_valve_nos();
    /*..hui [19-6-21���� 4:39:01] ��/��/�¼� ���� ��� ���..*/
    output_valve_extract();
    /*..hui [19-6-21���� 4:39:09] ���̽� Ʈ���� �Լ���� ���..*/
    /*output_valve_ice_tray();*/

    output_cold_drain_valve();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


