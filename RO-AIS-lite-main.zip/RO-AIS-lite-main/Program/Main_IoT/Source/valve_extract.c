/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "valve_extract.h"



void output_valve_extract(void);





U8 gu8LockLEDFlick;

bit F_LineTest;                   // ���� �׽�Ʈ
bit F_LineTest2;                  // ���� �׽�Ʈ2
//bit F_PartTest;                   // ��Ʈ �׽�Ʈ
//bit F_PBATest;                    // PBA TEST
//bit F_NfcTest;

//===================================== Part Test
bit F_PartHeater;
bit F_PartComp;
bit F_PartIceHeater;
bit F_PartTrayVV;
bit F_PartColdVV;
bit F_PartTrayCW;
bit F_PartDrainPump;
bit F_PartCristal;
bit F_PartIR;
bit F_PartIce;


U8 gu8_hot_close_delay_timer;

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
//""SUBR COMMENT""************************************************************
// ID         : Water Output
// ����       : ���� ���
//----------------------------------------------------------------------------
// ���       : ���� ��� ����

//----------------------------------------------------------------------------
//""SUBR COMMENT END""********************************************************
void output_valve_extract(void)
{
    /*calc_mix_water();*/
    open_hot_valve();

    if( F_WaterOut == SET )
    {
        /*..hui [23-3-22���� 5:38:51] ������ �����Ҷ� �� ������ ������ ������ ����..*/
        if( bit_my_cup_setting_start == SET )
        {
            pVALVE_24V_POWER = SET;
            pVALVE_ROOM_OUT = SET;
            pVALVE_COLD_OUT = CLEAR;
            pVALVE_HOT_OUT = CLEAR;
        }
        else if( u8WaterOutState == PURE_WATER_SELECT )
        {
            pVALVE_24V_POWER = SET;
            pVALVE_ROOM_OUT = SET;
            pVALVE_COLD_OUT = CLEAR;
            /*pVALVE_HOT_OUT = CLEAR;*/

            /*..hui [23-4-3���� 1:08:49] ������ũ ������ �����Ǹ� �¼� ���⵵ ����..*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
            {
                pVALVE_HOT_OUT = CLEAR;
            }
            else
            {
                if( bit_open_hot_valve == SET )
                {
                    pVALVE_HOT_OUT = SET;
                }
                else
                {
                    pVALVE_HOT_OUT = CLEAR;
                }
            }
        }
        else if( u8WaterOutState == COLD_WATER_SELECT )
        {
            pVALVE_24V_POWER = SET;
            pVALVE_COLD_OUT = SET;
            pVALVE_ROOM_OUT = CLEAR;
            pVALVE_HOT_OUT = CLEAR;
        }
        else if( u8WaterOutState == HOT_WATER_SELECT )
        {
            pVALVE_24V_POWER = SET;
            pVALVE_COLD_OUT = CLEAR;
            pVALVE_ROOM_OUT = CLEAR;
            pVALVE_HOT_OUT = SET;
        }
        else
        {
            pVALVE_24V_POWER = CLEAR;
            pVALVE_ROOM_OUT = CLEAR;
            pVALVE_COLD_OUT = CLEAR;
            pVALVE_HOT_OUT = CLEAR;
        }
    }
    else
    {
        //pVALVE_24V_POWER = CLEAR;
        
        if( pVALVE_COLD_DRAIN == SET )
        {
            pVALVE_24V_POWER = SET;
        }
        else
        {
            pVALVE_24V_POWER = CLEAR;
        }

        
        pVALVE_ROOM_OUT = CLEAR;
        pVALVE_COLD_OUT = CLEAR;
        pVALVE_HOT_OUT = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/







/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/




