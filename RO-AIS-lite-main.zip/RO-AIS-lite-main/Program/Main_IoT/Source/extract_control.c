/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "extract_control.h"


void water_extract_control(void);





U8 gu8_effluent_control_timer;
bit F_Effluent_OK;




/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void water_extract_control(void)
{
    if(F_WaterOut == SET)
    {
        gu16Water_Extract_Timer++;

        if( gu16Water_Extract_Timer >= u16Efluent_Time )
        {
            F_WaterOut = CLEAR;
            gu16Water_Extract_Timer = 0;
            u16Efluent_Time = 0;

            /*BuzStep(BUZZER_EFFLUENT_END);*/

            if( bit_my_cup_setting_start == SET )
            {
                BuzStep(BUZZER_SETUP);
            }
            else
            {
                BuzStep(BUZZER_EFFLUENT_END);
            }

            /*..hui [18-1-11���� 11:12:11] �������� ����..*/
            u8Extract_Continue = CLEAR;

            /*..hui [18-3-14���� 3:50:40] �������� ����..*/
            F_WaterOut_Disable_State = SET;
        }
        else
        {
            if( bit_my_cup_setting_start == SET )
            {
                if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
                {
                    BuzStep(BUZZER_ERROR);
                    /*..hui [23-3-23���� 1:51:31] ������ ���� ����. �ٽ� Set ǥ�� ȭ������..*/
                    halt_my_cup_setting();
                    start_low_water_flick();

                    F_WaterOut = CLEAR;
                    gu16Water_Extract_Timer = 0;
                    u16Efluent_Time = 0;
                }
                else{}
            }
            else{}

            /*..hui [23-5-9���� 11:46:25] �¼� ������ �������� ��� ����..*/
            if( u8WaterOutState == HOT_WATER_SELECT )
            {
                if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
                {
                    BuzStep(BUZZER_ERROR);

                    F_WaterOut = CLEAR;
                    gu16Water_Extract_Timer = 0;
                    u16Efluent_Time = 0;

                    /*..hui [18-1-11���� 11:12:11] �������� ����..*/
                    u8Extract_Continue = CLEAR;

                    /*..hui [18-3-14���� 3:50:40] �������� ����..*/
                    F_WaterOut_Disable_State = SET;
                }
                else{}
            }
            else{}
        }
    }
    else
    {
        gu16Water_Extract_Timer = 0;

        /*..hui [18-1-22���� 5:37:49] �ü� ��ũ û�Ҹ�� ����..*/
        /*..hui [20-1-30���� 10:13:58] �ǵ��� ���� ����, �ð�/���� ������ �ڵ���� ���˱�ɿ��� �Ѵ�..*/
        F_ColdConty = CLEAR;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


