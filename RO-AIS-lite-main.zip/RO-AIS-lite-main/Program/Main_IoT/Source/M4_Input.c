/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Input.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "M4_Input.h"


void Input(void);
//void input_select_bar(void);
//void input_cds(void);

//void input_overflow(void);
void check_ice_full(void);
void power_saving_init(void);

//void LeverInput(void);

bit F_Bar;
bit F_BeBar;
bit F_BarSet;
bit F_SelectBar;
U8 gu8Bar;


//----------------------------------------------------// IR
U8 gu8IRTime, gu8IRCount;
U16 gu16IRInterval;



bit F_IceFull;                        // ����
bit F_IR;                             // ���� �˻�



/*..hui [18-3-8���� 5:25:49] ó�� ���� ON�� ���� üũ..*/
bit bit_first_ice_full;

U8 gu8ContyCancel;
U8 gu8Out;
U16 gu16Conty;

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Input(void)
{
    /*..hui [19-6-26���� 1:54:08] �������� �Է�..*/
    input_water_level();

    /*..hui [19-6-26���� 1:12:26] Ʈ���� ����ũ�ν���ġ �Է�..*/
    input_ice_tray_micro_sw();

    /*..hui [19-6-26���� 1:54:12] ���� �Է�..*/
    check_ice_full();

    /*..hui [19-7-22���� 7:36:53] ��������..*/
    calculate_flow_input();

    /*..hui [19-7-25���� 8:25:00] �������� �ٽ� �߰���..*/
    /*input_cds();*/

    //detect_front_cds();

    /*..hui [19-10-23���� 7:56:31] ��ũ Ŀ�� ���彺��ġ ..*/
    service_reed_sw_input();

    /*..hui [20-2-19���� 5:57:55] UV ���ܿ� ��ũ Ŀ�� ���彺��ġ ���� �и�..*/
    /*..hui [20-2-19���� 5:58:13] ��ũ Ŀ�� �������� ��� UV �����ϱ� ���� �и���..*/
    uv_tank_reed_sw_input();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_ice_full(void)
{
    if(gu8IRTime > 0)
    {
        gu8IRTime--;                             // �����˻� 10��
    }
    else{}

    //==================================================================
    if(F_IR != SET && F_LineTest != SET)
    {
        return;
    }
    else{}
//
    if(pIR_POWER != SET)                                         // IR ��� �������
    {
        pIR_POWER = SET;

        if(F_LineTest == SET)
        {
            gu8IRTime = 30;
        }
        else
        {
            gu8IRTime = 100;
        }
    }
    else{}

    if(gu16ADIceFull >= ICEFULL_LEV)
    {
        gu8IRCount++;
    }
    else{}

    if(gu8IRTime == 0)
    {
        bit_first_ice_full = SET;

        if(F_LineTest == SET)
        {
            if(gu8IRCount >= 10)
            {
                F_IceFull = CLEAR;
            }
            else
            {
                F_IceFull = SET;
            }
        }
        else
        {
            if(gu8IRCount >= 50)
            {
                F_IceFull = CLEAR;
            }
            else
            {
                F_IceFull = SET;

                if( gu8_Make_Mode == MAKE_ICE
                    && gu8IceStep == STATE_50_ICE_FULL_IR_CHECK )
                {
                    bit_ice_one_more = CLEAR;
                }
                else{}
            }
        }

        gu8IRCount = 0;
        pIR_POWER = CLEAR;
        F_IR = CLEAR;

        if(F_LineTest == SET)
        {
            gu16IRInterval = 0;
        }
        else
        {
            gu16IRInterval = IR_INTERVAL;
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


