/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "flushing_water.h"


void pre_water_flushing( U8 mu8_off_state, U8 mu8_on_state );
U8 water_flushing_proc(void);


TYPE_BYTE          U8PreWaterFlushingB;
#define            u8PreWaterFlushing                                         U8PreWaterFlushingB.byte
#define            Bit0_Pre_WF_Power_On_State                                 U8PreWaterFlushingB.Bit.b0
#define            Bit1_Pre_WF_Low_Water_State                                U8PreWaterFlushingB.Bit.b1
#define            Bit2_Pre_WF_6_Hour_No_Input_Water_State                    U8PreWaterFlushingB.Bit.b2
#define            Bit3_Pre_WF_24_Hour_No_Water_Flushing_State                U8PreWaterFlushingB.Bit.b3



U8 gu8_water_flushing_step;
U16 gu16_water_flushing_timer;

bit bit_first_water_flushing;

bit bit_feed_on_state;
bit bit_feed_on_state_old;


U32 gu32_wf_6hour_timer;

U32 gu32_wf_24hour_timer;
bit bit_flushing_water_start;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void pre_water_flushing( U8 mu8_off_state, U8 mu8_on_state )
{
    U8 mu8_finish = 0;
    U8 mu8_start = 0;
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
    /*..hui [23-6-15���� 10:00:33] ���� �ΰ� �� ù ��° �޼� ��..*/
    if( bit_first_water_flushing == CLEAR )
    {
        bit_first_water_flushing = SET;
        /*Bit0_Pre_WF_Power_On_State = SET;*/

        /*..hui [24-1-4���� 11:28:09] �÷����߿��� ������ �����÷��� �ϱ� ������ �߰��� �� �ʿ����..*/
        if( gu8_flushing_mode == FLUSHING_NONE_STATE )
        {
            Bit0_Pre_WF_Power_On_State = SET;
        }
        else
        {
            Bit0_Pre_WF_Power_On_State = CLEAR;
        }
    }
    else{}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
    #if 0
    /*..hui [23-6-15���� 10:01:06] ������ ������ ���..*/
    if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
    {
        if( bit_flushing_low_water == SET )
        {
            bit_flushing_low_water = CLEAR;
            Bit1_Pre_WF_Low_Water_State = SET;
        }
        else{}
    }
    else
    {
        bit_flushing_low_water = SET;
    }
    #endif


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

    if( bit_feed_output == SET )
    {
        gu32_wf_6hour_timer = 0;
    }
    else
    {
        gu32_wf_6hour_timer++;
    }

    if( gu32_wf_6hour_timer >= NO_INPUT_WATER_6_HOUR )
    {
        gu32_wf_6hour_timer = 0;
        Bit2_Pre_WF_6_Hour_No_Input_Water_State = SET;
    }
    else{}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

    gu32_wf_24hour_timer++;

    if( gu32_wf_24hour_timer >= NO_WATER_FLUSHING_24_HOUR )
    {
        gu32_wf_24hour_timer = 0;
        Bit3_Pre_WF_24_Hour_No_Water_Flushing_State = SET;
    }
    else{}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
    /*..hui [23-8-23���� 3:08:33] �÷��̸�� �ƴ� ��쿡��..*/
    /*..hui [23-8-23���� 3:26:39] ���� ����� ���� �����϶���..*/
    /*..hui [23-8-24���� 9:12:35] �¼���ô�ҋ��� ���۾���..*/
    if( mu8_off_state == 0x00 && mu8_on_state == 0x01
        && gu8_flushing_mode == FLUSHING_NONE_STATE
        && bit_filter_all == SET
        && bit_ice_tank_ster_start == CLEAR
        && bit_self_test_start == CLEAR
        && bit_acid_clean_start == CLEAR )
    {
        if( bit_feed_on_state_old == SET )
        {
            bit_feed_on_state_old = CLEAR;

            if( u8PreWaterFlushing > 0 )
            {
                bit_feed_on_state = SET;
            }
            else{}
        }
        else{}
    }
    else
    {
        bit_feed_on_state_old = SET;
    }

    /*..hui [23-6-16���� 2:34:45] ������ ������ ���¿��� �ǵ� ON �����̵Ǹ� ����..*/
    if( u8PreWaterFlushing > 0 && bit_feed_on_state == SET )
    {
        mu8_finish = water_flushing_proc();

        if( mu8_finish == SET )
        {
            u8PreWaterFlushing = 0;

            /*..hui [23-6-15���� 12:12:08] 24�ð� Ÿ�̸� �ʱ�ȭ..*/
            gu32_wf_24hour_timer = 0;
            bit_flushing_water_start = CLEAR;
            /*..hui [23-6-16���� 2:41:15] �ǵ� ���������� �����ϰ�, ��� �����ִ� ���¿��� �ٽ� ���� ������������ �������� �ʱ�����..*/
            bit_feed_on_state = CLEAR;
        }
        else
        {
            bit_flushing_water_start = SET;
        }
    }
    else
    {
        gu8_water_flushing_step = 0;
        bit_flushing_water_start = CLEAR;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


}






/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 water_flushing_proc(void)
{
    U8 mu8_return = 0;

    switch( gu8_water_flushing_step )
    {
        case 0:

            gu16_water_flushing_timer++;

            if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 1:

            gu16_water_flushing_timer++;

            /*..hui [23-6-14���� 7:30:47] �÷��� ������ȯ ��� ON..*/
            if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 2:

            gu16_water_flushing_timer++;

            /*..hui [23-6-14���� 7:31:06] FEED ��� ON..*/
            if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 3:

            gu16_water_flushing_timer++;

            /*..hui [23-6-14���� 7:31:25] 3�� ���..*/
            if( gu16_water_flushing_timer >= PRE_WATER_FLUSHING_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;

                /*..hui [23-6-14���� 7:33:43] RO �÷��� ��ũ ���� OPEN..*/
                run_open_ro_drain();
            }
            else
            {
                /*..hui [23-8-23���� 3:16:51] ���� �÷��� ���� �� �÷������� ��ȯ�Ǹ� �ߴ�..*/
                if( gu8_flushing_mode > FLUSHING_NONE_STATE
                    || bit_filter_all == CLEAR
                    || bit_ice_tank_ster_start == SET )
                {
                    gu16_water_flushing_timer = 0;
                    gu8_water_flushing_step = 6;
                }
                else{}
            }

            break;

        case 4:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� OPEN �Ϸ�Ǹ�..*/
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_OPEN )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 5:

            gu16_water_flushing_timer++;

            /*..hui [23-6-14���� 7:37:37] 3�� ���� �÷���..*/
            if( gu16_water_flushing_timer >= RO_WATER_FLUSHING_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 6:

            gu16_water_flushing_timer++;

            /*..hui [23-6-14���� 7:38:36] FEED ��� ����..*/
            /*if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )*/
            if( gu16_water_flushing_timer >= 20 )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;

                /*run_close_ro_drain();*/
            }
            else{}

            break;

        case 7:

            gu16_water_flushing_timer++;

            /*..hui [23-6-16���� 2:47:15] �÷��� ������ȯ ��� OFF..*/
            if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;

                run_close_ro_drain();
            }
            else{}

            break;

        case 8:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� CLOSE �Ϸ�Ǹ�..*/
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_CLOSE )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 9:

            gu16_water_flushing_timer++;

            /*..hui [23-6-16���� 2:48:42] �������� ���� �ǵ��� ON�Ҷ����� 0.5�� ���..*/
            if( gu16_water_flushing_timer >= FLUSHING_WATER_DELAY_TIME )
            {
                gu16_water_flushing_timer = 0;
                gu8_water_flushing_step++;
            }
            else{}

            break;

        case 10:

            gu8_water_flushing_step = 0;
            gu16_water_flushing_timer = 0;

            /*..hui [23-6-14���� 7:40:33] �޼� �÷��� ����..*/
            mu8_return = SET;


            break;


        default:

            gu8_water_flushing_step = 0;
            gu16_water_flushing_timer = 0;

        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


