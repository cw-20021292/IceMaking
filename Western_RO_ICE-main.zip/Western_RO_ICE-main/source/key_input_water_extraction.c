/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "key_input_water_extraction.h"

void input_water_extract_key(void);
void extract_key_management(void);

void Extract_Key_Short_Input(void);
void water_extract_key(void);
void effluent_time_decision(void);
void effluent_time_decision_normal(void);
void effluent_time_ambient_normal(void);
void effluent_time_cold_normal(void);
void effluent_time_hot_normal(void);

void effluent_time_decision_low_water(void);
void effluent_time_ambient_low_water(void);
void effluent_time_cold_low_water(void);
void effluent_time_hot_low_water(void);

void Extract_Key_Long_Input(void);

void water_extract_long_key(void);

void key_input_water_extract(void);
void Extract_Key_Very_Long_Input(void);
void Extract_No_Key(void);

U8  gu8_Key_Water_Extract;
U8  u8Extract_Key_Buffer;
U16  u16Extract_Key_Sampling_Counter;
bit F_Extract_Key_Short_Push_State;
bit F_Extract_Key_Long_Push_State;
bit F_Extract_Key_Very_Long_Push_State;

U8  u8Extract_Key_Input_Value;

U16  u16Extract_Key_Long_Counter;
U16  u16Extract_Key_Short_Counter;

U8  u8Efluent_Time;


U8  u8Extract_Continue;

U16 u16Efluent_Time;
bit F_ColdConty;


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void key_input_water_extract(void)
{
    input_water_extract_key();
    extract_key_management();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void input_water_extract_key(void)
{
    if(gu8_Key_Water_Extract == u8Extract_Key_Buffer)
    {
        if(u8Extract_Key_Buffer == UKey_Mask)
        {
            u16Extract_Key_Sampling_Counter = 0;
            F_Extract_Key_Short_Push_State = CLEAR;
            F_Extract_Key_Long_Push_State = CLEAR;
            F_Extract_Key_Very_Long_Push_State = CLEAR;
        }
        else
        {
            u16Extract_Key_Sampling_Counter++;
        }

        if(u16Extract_Key_Sampling_Counter >= 1)
        {
            u16Extract_Key_Short_Counter = u16Extract_Key_Sampling_Counter;
            u16Extract_Key_Long_Counter++;

            /*..hui [19-11-19���� 4:26:26] Ű �����ִµ��� �¼� ���� ī���� �ʱ�ȭ..*/
            /*gu16_water_select_return_time = 0;*/
        }
        else{}
    }
    else
    {
        u8Extract_Key_Buffer = gu8_Key_Water_Extract;

        u16Extract_Key_Sampling_Counter = 0;
        u16Extract_Key_Long_Counter = 0;
        u16Extract_Key_Short_Counter = 0;
    }
}
/***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void extract_key_management(void)
{
    if(F_Extract_Key_Short_Push_State == CLEAR)
    {
        if( (u16Extract_Key_Short_Counter >= 1) && (u16Extract_Key_Short_Counter < 2000) )
        {
            if(u8FactoryTestMode == NONE_TEST_MODE)
            {
                Extract_Key_Short_Input();
            }
            else
            {
                PCB_Test_Mode_Extract_Key_Short_Input();
            }

            F_Extract_Key_Short_Push_State = SET;
            u16Extract_Key_Short_Counter = 0;
        }
        else{}
    }
    else
    {
        if(F_Extract_Key_Long_Push_State == CLEAR)
        {
            if( u16Extract_Key_Long_Counter >= 2000 )
            {
                F_Extract_Key_Long_Push_State = SET;

                if(u8FactoryTestMode == NONE_TEST_MODE)
                {
                    Extract_Key_Long_Input();
                }
                else{}
            }
            else{}
        }
        else
        {
            if(F_Extract_Key_Very_Long_Push_State == CLEAR)
            {
                if( u16Extract_Key_Long_Counter >= 8000 )
                {
                    F_Extract_Key_Very_Long_Push_State = SET;
                    u16Extract_Key_Long_Counter = 0;

                    if(u8FactoryTestMode == NONE_TEST_MODE)
                    {
                        Extract_Key_Very_Long_Input();
                    }
                    else{}
                }
                else{}
            }
            else{}
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Extract_Key_Short_Input(void)
{
    /////F_lcd_standby_input = SET;
    gu16_water_select_return_time = 0;
    /*gu8_clear_block_error = SET;*/

    auto_drain_key_off_check();
    power_saving_init();

    /*..hui [23-5-12���� 3:27:25] ��ư ���� ON, OFF ǥ���� ��ư ������ ǥ�� �ٷ� ����..*/
    stop_button_set_display();
    /*..hui [24-4-25���� 7:12:26] LED �������̴��� ����..*/
    off_all_flick();

    if(F_FW_Version_Display_Mode != SET)
    {
        return;
    }
    else{}

    water_extract_key();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void water_extract_key(void)
{
    //F_WaterOut == 0�̸� ����..
    //F_WaterOut = SET;
    /*..hui [17-12-11���� 1:55:46] 0�̸� ������, 1�̸� ����� ����..�򰥷���....*/

    if( gu8_fota_start == SET )
    {
        play_melody_warning_197();
        return;
    }
    else{}

    if( bit_self_test_start == SET )
    {
        play_melody_warning_197();
        return;
    }
    else{}

    if( gu8_Led_Display_Step == LED_Display__WIFI_PAIRING )
    {
        //bit_wifi_pairing_start = CLEAR;
        finish_pairing_screen();
    }
    else{}

    if( bit_memento_start == SET )
    {
        play_melody_warning_197();
        return;
    }
    else{}

    /*..hui [24-5-23���� 7:31:11] ������ �����Ҷ�..*/
    if( gu8_Led_Display_Step == LED_Display__ACID_CLEAN )
    {
        #if 0
        if( bit_acid_clean_start == SET )
        {
            if( gu8_acid_clean_step == 8 || gu8_acid_clean_step == 20 )
            {
                bit_acid_start_key = SET;
            }
            else
            {
                play_melody_warning_197();
            }

            return;
        }
        else{}
        #endif

        /*..hui [24-7-30���� 10:35:07] ������ ��ô�� �ܼ����� �ɸ��� ��ư ������ ����..*/
        if( Bit6_Main_Water_Flow_Block_Error__E09 == SET )
        {
            gu8_clear_block_error = SET;
            play_melody_select_196();
        }
        else
        {
            play_melody_warning_197();
        }

        return;
    }
    else{}

    if( gu8_Led_Display_Step == LED_Display__FLUSHING )
    {
        if( gu8_flushing_mode == FLUSHING_STANDBY_STATE )
        {
            /*..hui [23-8-16���� 5:42:18] �ܼ����� �ɸ��� ���� ��ư���ε� �ܼ� ���� �����ǵ���..*/
            if( Bit6_Main_Water_Flow_Block_Error__E09 == SET )
            {
                gu8_clear_block_error = SET;
                play_melody_select_196();
            }
            else
            {
                gu8_flushing_okay_key_indicator = SET;
            }
        }
        else if( gu8_flushing_mode == FLUSHING_MAIN_STATE )
        {
            /*gu8_flushing_okay_key_indicator = SET;*/

            /*..hui [23-8-16���� 4:07:57] ���� �÷��� �ϰ��������� ��� �����ϵ���..*/
            /*..hui [23-8-16���� 4:08:03] �ʱ� ro �巹�νÿ��� ��� �Ұ�..*/
            if( gu8_flushing_step == 8 )
            {
                gu8_flushing_okay_key_indicator = SET;
            }
            else
            {
                play_melody_warning_197();
            }
        }
        else if( gu8_flushing_mode == FLUSHING_TANK_STATE )
        {
            /*if( gu8_flushing_tank_step == 2 || gu8_flushing_tank_step == 3 )*/
            /*..hui [23-8-23���� 10:41:30] 10 ���� ��� �������� ��� �����ϵ���..*/
            /*if( gu8_flushing_tank_step <= 10 )*/
            if( gu8_flushing_tank_step <= 15 )
            {
                gu8_flushing_okay_key_indicator = SET;
            }
            else
            {
                play_melody_warning_197();
            }
        }
        else
        {
            play_melody_warning_197();
        }

        return;
    }
    else{}


    if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN )
    {
        /*play_melody_warning_197();*/
        if( bit_filter_cover == CLEAR )
        {
            /*..hui [23-12-19���� 3:36:52] ����Ŀ�� �������� �����ư ������..*/
            play_voice_filter_cover_open_extract_89();
        }
        else
        {
            /*..hui [23-12-19���� 3:37:15] ���� Ŀ���� �����ְ� ���� ���尡 �������� ������.. �̶��� �층�층..*/
            play_melody_warning_197();
        }

        return;
    }
    else{}


    /*..hui [23-2-9���� 2:03:49] ���ø�忡���� ���������� ����ȵ�..*/
    if( bit_setting_mode_start == SET )
    {
        return;
    }
    else{}

    if( bit_time_setting_start == SET )
    {
        return;
    }
    else{}

    if( bit_sound_setting_start == SET )
    {
        return;
    }
    else{}

    if( bit_altitude_setting_start == SET )
    {
        return;
    }
    else{}

    if( bit_ct_filter_type_start == SET )
    {
        return;
    }
    else{}

    /*if(F_All_Lock == SET)*/
    if( F_All_Lock == SET && F_Child_Lock == SET )
    {
        start_all_lock_flick();
        /*play_melody_warning_197();*/
        play_voice_all_lock_select_103();
        return;
    }
    else{}

    /*..hui [23-5-22���� 4:16:36] �켱 �¼�����Ҷ� �� ����, ���� ������ ���°ɷ�..*/
    if( bit_ice_tank_ster_start == SET )
    {
        if( gu8_ice_ster_mode > STER_MODE_NONE_STATE )
        {
            /*play_melody_warning_197();*/
            play_voice_ice_tank_clean_extract_60();
            start_breath_steam_clean();
            return;
        }
        else{}
    }
    else{}

    /*..hui [18-3-14���� 3:07:31] �������� �Ϸ�ǰ� 500ms ���� �� ���� ��ư disable..*/
    if(F_WaterOut_Disable_State == SET)
    {
        return;
    }
    else{}

    /*..hui [19-8-22���� 1:44:22] �߼��� �Ǵ� ������������ �¼� ���� ����..*/
    if(u8WaterOutState == HOT_WATER_SELECT)
    {
        if( F_WaterOut == CLEAR )
        {
            /*..hui [23-5-31���� 1:48:50] ���� ������ ���� �������� �������� ǥ��.. �ϴ�..*/
            /*if( gu8_Room_Water_Level == ROOM_LEVEL_LOW || bit_hot_first_op == CLEAR )*/
            /*..hui [24-2-20���� 4:11:02] ���� ������ ���� �����̴��� �¼� ������ �����ϵ��� ����....*/
            /*..hui [24-2-20���� 4:11:09] �������� ���� ����..*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
            {
                ////////////////play_melody_warning_197();
                play_voice_low_water_hot_room_out_108();
                /*start_low_water_breath();*/
                start_low_water_flick();
                return;
            }
            else{}
        }
        else{}
    }
    else{}

    if(u8WaterOutState == PURE_WATER_SELECT)
    {
        if( F_WaterOut == CLEAR )
        {
            /*..hui [23-7-17���� 9:16:09] ������ �������ϋ��� ���� ����.. ������ro ���...*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
            {
                ////////////////play_melody_warning_197();
                play_voice_low_water_hot_room_out_108();
                /*start_low_water_breath();*/
                start_low_water_flick();
                return;
            }
            else{}
        }
        else{}
    }
    else{}

    /*..hui [23-4-25���� 12:05:48] �¼� �������ÿ� ���� ���� ���� ���� �߰�..*/
    /*..hui [23-4-25���� 12:05:55] ���� ���� ���� �߻� �� ���� ���� �Ұ�..*/
    /*if( u8WaterOutState == PURE_WATER_SELECT )*/
    /*..hui [23-8-23���� 12:16:12] ���� �ü� �Ѹ��̹Ƿ� �� �� ����..*/
    if( u8WaterOutState == PURE_WATER_SELECT || u8WaterOutState == COLD_WATER_SELECT )
    {
        if( F_WaterOut == CLEAR )
        {
            if( Bit1_Room_OverHeat_Error__E49 == SET )
            {
                play_melody_warning_197();
                gu8_error_popup_enable = SET;
                return;
            }
            else{}
        }
        else{}
    }
    else{}


    finish_filter_alarm();

    stop_cooling_breath();

    if( F_WaterOut == CLEAR )
    {
        F_WaterOut = SET;
        F_Effluent_OK = CLEAR;

        /*..hui [19-9-5���� 4:49:47] ���������� �޴�������..*/
        if( gu8Cup_level == CUP_LEVEL__CONTINUE )
        {
            u8Extract_Continue = SET;
            /*BuzStep(BUZZER_EFFLUENT_CONTINUE);*/
            play_melody_continue_extract_start_192();
        }
        else
        {
            /*BuzStep(BUZZER_EFFLUENT);*/
            play_melody_normal_extract_start();
        }
    }
    else
    {
        F_WaterOut = CLEAR;
        u8Extract_Continue = CLEAR;
        /*BuzStep(BUZZER_EFFLUENT_END);*/
        play_melody_extract_complete_194();
        /*hot_extract_return();*/
    }

    if(F_WaterOut == SET)
    {
        if(u8Extract_Continue != SET)
        {
            effluent_time_decision();

            water_out_compensation();
            gu16_water_out_time = u16Efluent_Time;
            calc_mix_water();
            /*Pure_Temp_Compensation_time_Cold_Big();*/
        }
        else
        {
            u16Efluent_Time = EXTRACT_TIME_CONTINUE;
            gu16_water_out_time = u16Efluent_Time;
            calc_mix_water();
        }
    }
    else
    {
        u16Efluent_Time = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_decision(void)
{
    #if 0
    U8 mu8_a = 0;
    U8 mu8_b = 0;


    mu8_b = TARGET_HOT_43_TEMP - gu8_Cold_Temperature_One_Degree;
    mu8_a = gu8_Hot_Tank_Temperature_One_Degree - TARGET_HOT_43_TEMP;

////////////////////////////////////////////////////////////////////////////////////////

    if( mu8_b <= mu8_a - 10 )
    {
        bit_big_mode = COLD__BIG;
    }
    else
    {
        bit_big_mode = HOT__BIG;
    }
    #endif


    if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
    {
        effluent_time_decision_low_water();
    }
    else
    {
        effluent_time_decision_normal();
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_decision_normal(void)
{
    if(u8WaterOutState == PURE_WATER_SELECT)
    {
        /*effluent_time_ambient_normal();*/


        /*..hui [23-10-18���� 9:35:23] ������ �ü��� ����..*/
        effluent_time_cold_normal();

    }
    //else if(F_ColdOut == SET)
    else if(u8WaterOutState == COLD_WATER_SELECT)
    {
        effluent_time_cold_normal();


    }
    else if(u8WaterOutState == HOT_WATER_SELECT)
    {
        #if 0
        if( gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )
        {
            if( bit_big_mode == HOT__BIG )
            {
                effluent_time_hot_normal();
            }
            else
            {
                effluent_time_cold_normal();
            }
        }
        else
        {
            effluent_time_hot_normal();
        }
        #endif


        effluent_time_hot_normal();
    }
    else
    {
        /*u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ;*/
        u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML;
    }

    /*gu16_water_out_time = u16Efluent_Time;*/
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/

void effluent_time_ambient_normal(void)
{
    #if 0
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ;

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_6_OZ;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_8_OZ;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_10_OZ;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_12_OZ;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_14_OZ;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_16_OZ;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_20_OZ;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_32_OZ;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ;

            break;
    }
    #endif


}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/

void effluent_time_cold_normal(void)
{
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML;

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_6_OZ_175_ML;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_8_OZ_235_ML;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_10_OZ_295_ML;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_12_OZ_355_ML;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_14_OZ_415_ML;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_16_OZ_475_ML;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_20_OZ_590_ML;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_32_OZ;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML;

            break;
    }



}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/

void effluent_time_hot_normal(void)
{
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_4_OZ_120_ML;

            #if 0
            /*..hui [23-11-29���� 9:57:20] 43�� ������ 120ml�� ���ߵ���....*/
            if( gu8_hot_setting_temperature == HOT_SET_TEMP_4__200_oF_95_oC )
            {
                u16Efluent_Time = u16Efluent_Time + 11;
            }
            else if( gu8_hot_setting_temperature == HOT_SET_TEMP_2__170_oF_77_oC )
            {
                u16Efluent_Time = u16Efluent_Time + 6;
            }
            else if( gu8_hot_setting_temperature == HOT_SET_TEMP_3__185_oF_85_oC )
            {
                u16Efluent_Time = u16Efluent_Time + 2;
            }
            else{}
            #endif

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_6_OZ_175_ML;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_8_OZ_235_ML;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_10_OZ_295_ML;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_12_OZ_355_ML;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_14_OZ_415_ML;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_16_OZ_475_ML;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_20_OZ_590_ML;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_32_OZ;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_4_OZ_120_ML;

            break;
    }



}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_decision_low_water(void)
{
    if(u8WaterOutState == PURE_WATER_SELECT)
    {
        /*effluent_time_ambient_low_water();*/

        /*..hui [23-10-18���� 9:35:46] ������ �ü��� ����..*/
        effluent_time_cold_low_water();

    }
    else if(u8WaterOutState == COLD_WATER_SELECT)
    {

        effluent_time_cold_low_water();

    }
    /*..hui [23-10-18���� 9:37:27] �¼��� �������� ����ȵ�..*/
    /*else if(u8WaterOutState == HOT_WATER_SELECT)
    {
        effluent_time_hot_low_water();

    }*/
    else
    {
        /*u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ__LOW_WATER;*/
        u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML__LOW_WATER;
    }

    /*gu16_water_out_time = u16Efluent_Time;*/
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_ambient_low_water(void)
{
    #if 0
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_6_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_8_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_10_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_12_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_14_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_16_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_20_OZ__LOW_WATER;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_32_OZ__LOW_WATER;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_AMBIENT_WATER_4_OZ__LOW_WATER;

            break;
    }
    #endif

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_cold_low_water(void)
{
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML__LOW_WATER;

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_6_OZ_175_ML__LOW_WATER;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_8_OZ_235_ML__LOW_WATER;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_10_OZ_295_ML__LOW_WATER;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_12_OZ_355_ML__LOW_WATER;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_14_OZ_415_ML__LOW_WATER;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_16_OZ_475_ML__LOW_WATER;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_20_OZ_590_ML__LOW_WATER;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_32_OZ__LOW_WATER;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_COLD_WATER_4_OZ_120_ML__LOW_WATER;

            break;
    }



}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void effluent_time_hot_low_water(void)
{
    #if 0
    switch(gu8Cup_level)
    {
        case CUP_LEVEL__4_OZ__120_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_4_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__6_OZ__175_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_6_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__8_OZ__235_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_8_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__10_OZ__295_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_10_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__12_OZ__355_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_12_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__14_OZ__415_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_14_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__16_OZ__475_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_16_OZ__LOW_WATER;

            break;

        case CUP_LEVEL__20_OZ__590_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_20_OZ__LOW_WATER;

            break;

    #if 0
        case CUP_LEVEL__32_OZ__945_ML:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_32_OZ__LOW_WATER;

            break;
    #endif

        default:

            u16Efluent_Time = EXTRACT_TIME_HOT_WATER_4_OZ__LOW_WATER;

            break;
    }
    #endif


}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Extract_Key_Long_Input(void)
{
    /*..hui [19-9-25���� 9:41:46] ���� ������ �޴�������..*/
    /*..hui [19-11-8���� 12:50:23] �ٽ� �߰�.. �����ϱ� �� ����..*/
    /*..hui [23-10-4���� 2:52:27] ��ǰ��ȹ, �̱� ����.. ���� ��Ű ���� ���� ��� ����..*/
    /*..hui [23-10-4���� 2:52:40] �̱��ε��� ��Ű�� �ͼ�ġ �ʾ� ���۵� ��� �ִٰ� ��..*/
    /*water_extract_long_key();*/
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void water_extract_long_key(void)
{
    #if 0
    gu16_water_select_return_time = 0;

    /*..hui [19-11-18���� 2:48:30] ���� �޴��� ���� ��..*/
    if(u8Extract_Continue == SET)
    {
        return;
    }
    else{}

    if( F_WaterOut == SET )
    {
        if(F_LineTest == SET)
        {
            /*..hui [18-1-9���� 10:24:39] �����׽�Ʈ��忡���� 10������ ����..*/
            u16Efluent_Time = EXTRACT_TIME_CONTINUE_LINE_TEST;
        }
        else
        {
            /* �ü� ���� ��� */
            if( F_Tank_Cover_Input == CLEAR && u8WaterOutState == COLD_WATER_SELECT )
            {
                F_ColdConty = SET;
                u16Efluent_Time = EXTRACT_TIME_COLD_DRAIN;

                /*..hui [19-12-18���� 8:47:04] �������̸� ����Ż�� ����..*/
                /*..hui [20-1-30���� 10:15:03] �ڵ���� ���˱�ɿ��� ����..*/
                /*force_take_off_ice();*/
            }
            else
            {
                u16Efluent_Time = EXTRACT_TIME_CONTINUE;
            }
        }

        BuzStep(BUZZER_EFFLUENT_CONTINUE);
        u8Extract_Continue = SET;

        /*..hui [19-12-5���� 4:48:26] ���� ��ư���� ���� ���������� ������ ���� ���ϴ°ɷ�..*/
        /*gu8Cup_level = CUP_LEVEL_CONTINUE;*/
    }
    else
    {
        u16Efluent_Time = 0;
    }
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Extract_Key_Very_Long_Input(void)
{
    gu16_water_select_return_time = 0;

    if( F_WaterOut == SET )
    {
        /*..hui [19-11-18���� 1:36:04] 7�� �̻� ����Ű ����������� ��� ���� ����..*/
        gu16Water_Extract_Timer = u16Efluent_Time;
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Extract_No_Key(void)
{
    F_Extract_Key_Short_Push_State = SET;
    F_Extract_Key_Long_Push_State = SET;
    F_Extract_Key_Very_Long_Push_State = SET;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


