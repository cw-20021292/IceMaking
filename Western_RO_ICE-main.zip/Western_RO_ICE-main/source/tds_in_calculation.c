/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "tds_in_calculation.h"

#if 0
void TDS_In_Control(void);
void TDS_In_FACTOR(void);
void INTP4_TDS_Input(void);
#endif

bit F_TDS_ON;                     // ����/���� TDS ���� Start
bit F_TDS_IN_Check;               // ���� ���ļ� ���� ����
bit F_TDS_Decide;                 // ���� TDS ���� �� ��ȯ


U16  gu16Cnt100ms_TDS;             // ���� TDS ���� ���ļ��� ���� ī��Ʈ
U16  gu16TDS_IN_Pulse;             // ���� TDS ���� ���ļ�
U16  gu16Factor_Temp_1;            // ���� TDS ��ȯ ����
U8   gu8TDS_IN_AVR_Count;          // ���� TDS ����� ���� ������ ī��Ʈ
U32  gu32TDS_IN_Sum;               // ���� TDS ����� ���� ����
U16  gu16TDS_IN_Max;               // ���� TDS ����� ���� �ְ���
U16  gu16TDS_IN_Min;               // ���� TDS ����� ���� ������
U16  gu16TDS_IN_Data;              // ���� TDS ��� Data
U16  gu16TDS_IN_Final;             // ���� TDS ���� Data

U16 gu16TDS_IN_CON;



U8 gu8TDS_IN_Level;

#if 0
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/* Function Information--------------------------------------------------------
�� �Լ���: INPUT TDS
�� ��  ��: TDS_IN (ȯ�⿬)
           TDS_OUT(�����)
�� �ۼ���: Phil
�� �ۼ���: 2016.4.11
�� ���ó: Int_interval()
�� ��  ��: 1ms
------------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//                      INPUT TDS Control
//------------------------------------------------------------------------------
void TDS_In_Control(void)   // per 1ms
{
    if(F_TDS_ON == SET)
    {

        pTDS_IN_Power = 0;                // Power ON
        F_TDS_IN_Check = 1;               // Enable Interrupt Count

        if(++gu16Cnt100ms_TDS >= 100)     // 100ms�Ŀ� (1�� �ʹ� ��� �����Ǵ�)
        {
            gu16Cnt100ms_TDS = 0;
            F_TDS_Decide = 1;               // TDS ��� �� �Ǵ�
        }
        else{}
    }
    else
    {
        pTDS_IN_Power = 1;                // Power OFF
        gu16Cnt100ms_TDS = 0;
        F_TDS_IN_Check = 0;               // Disable Interrupt Count
        F_TDS_Decide = 0;

        gu16TDS_IN_Pulse = 0;
    }

    // �Է� TDS ���� �� �Ǵ�
    if(F_TDS_Decide == SET)
    {
        F_TDS_Decide = 0;

        gu16TDS_IN_CON = gu16TDS_IN_Pulse * 10;     // �Լ� ���ļ�(�ʴ� Pulse ����)
        TDS_In_FACTOR();                   // TDS ����

        if( u8FactoryTestMode != NONE_TEST_MODE )
        {
            gu16_uart_test_pulse = gu16TDS_IN_Pulse;
        }
        else{}

        gu16TDS_IN_Pulse = 0;
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
//------------------------------------------------------------------------------
//                      TDS FACTOR (TDS ����)
//------------------------------------------------------------------------------
void TDS_In_FACTOR(void)
{
    gu16Factor_Temp_1 = gu16TDS_IN_Pulse * 10;      // 100ms���� �Էµ� Signal�� 1�� ������ ���� ����

// ������ 2017�� 2�� 9�� ��
// �Լ� �µ� 6�� �̸�   : y = 2E-08x3 + 0.0001x2 + 0.4091x + 0.2205
// �Լ� �µ� 6 ~ 9��    : y = 2E-08x3 + 1E-04x2 + 0.3832x + 0.1762
// �Լ� �µ� 9 ~ 11��   : y = 2E-08x3 + 8E-05x2 + 0.3462x + 0.1615
// �Լ� �µ� 11 ~ 14��  : y = 3E-08x3 + 6E-05x2 + 0.3284x - 0.6361
// �Լ� �µ� 14 ~ 16��  : y = 4E-08x3 + 3E-05x2 + 0.3131x - 1.4181
// �Լ� �µ� 16 ~ 19��  : y = 3E-08x3 + 5E-05x2 + 0.2899x - 0.8228
// �Լ� �µ� 19 ~ 21��  : y = 2E-08x3 + 6E-05x2 + 0.2683x - 0.155
// �Լ� �µ� 21 ~ 24��  : y = 2E-08x3 + 5E-05x2 + 0.2532x - 0.1544
// �Լ� �µ� 24 ~ 26��  : y = 2E-08x3 + 5E-05x2 + 0.2398x - 0.1511
// �Լ� �µ� 26 ~ 29��  : y = 2E-08x3 + 4E-05x2 + 0.2235x + 0.0222
// �Լ� �µ� 29 ~ 31��  : y = 2E-08x3 + 4E-05x2 + 0.2095x + 0.1505
// �Լ� �µ� 31 ~ 34��  : y = 3E-08x3 + 1E-05x2 + 0.2118x - 3.0446
// �Լ� �µ� 34�� �̻�  : y = 3E-08x3 - 9E-06x2 + 0.2217x - 6.3495

    // ������ ���(?)
    if (gu16_AD_Result_TDS_In_Temp < TDS_TEMP6_0)
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.0001 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.4091 * (D64)(gu16Factor_Temp_1)) + 0.2205);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP6_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP9_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.0001 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.3832 * (D64)(gu16Factor_Temp_1)) + 0.1762);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP9_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP11_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00008 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.3462 * (D64)(gu16Factor_Temp_1)) + 0.1615);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP11_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP14_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000003 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00006 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.3284 * (D64)(gu16Factor_Temp_1)) - 0.6361);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP14_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP16_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000004 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00003 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.3131 * (D64)(gu16Factor_Temp_1)) - 1.4181);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP16_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP19_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000003 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00005 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2899 * (D64)(gu16Factor_Temp_1)) - 0.8228);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP19_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP21_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00006 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2683 * (D64)(gu16Factor_Temp_1)) - 0.155);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP21_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP24_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00005 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2532 * (D64)(gu16Factor_Temp_1)) - 0.1544);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP24_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP26_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00005 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2398 * (D64)(gu16Factor_Temp_1)) - 0.1511);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP26_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP29_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00004 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2235 * (D64)(gu16Factor_Temp_1)) + 0.0222);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP29_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP31_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000002 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00004 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2095 * (D64)(gu16Factor_Temp_1)) + 0.1505);
    }
    else if ((gu16_AD_Result_TDS_In_Temp >= TDS_TEMP31_0) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP34_0))
    {
        gu16TDS_IN_Data = (U16)((0.00000003 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.00001 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2118 * (D64)(gu16Factor_Temp_1)) - 3.0446);
    }
    else if (gu16_AD_Result_TDS_In_Temp >= TDS_TEMP34_0)
    {
        gu16TDS_IN_Data = (U16)((0.00000003 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) - (0.000009 * ((D64)(gu16Factor_Temp_1) * (D64)(gu16Factor_Temp_1))) + (0.2217 * (D64)(gu16Factor_Temp_1)) - 6.3495);
    }
    else{}


    // �µ��� ���� TDS�� ����
    if((TDS_TEMP6_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP7_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.83);
    }
    else if((TDS_TEMP7_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP8_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.82);
    }
    else if((TDS_TEMP8_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP9_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.80);
    }
    else if((TDS_TEMP9_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP10_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.87);
    }
    else if((TDS_TEMP10_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP11_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP11_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP12_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP12_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP13_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP13_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP14_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.80);
    }
    else if((TDS_TEMP14_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP15_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP15_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP16_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.82);
    }
    else if((TDS_TEMP16_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP17_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP17_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP18_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.82);
    }
    else if((TDS_TEMP18_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP19_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.80);
    }
    else if((TDS_TEMP19_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP20_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP20_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP21_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP21_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP22_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP22_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP23_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP23_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP24_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.82);
    }
    else if((TDS_TEMP24_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP25_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP25_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP26_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.82);
    }
    else if((TDS_TEMP26_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP27_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP27_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP28_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP28_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP29_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.83);
    }
    else if((TDS_TEMP29_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP30_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP30_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP31_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP31_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP32_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.90);
    }
    else if((TDS_TEMP32_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP33_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.85);
    }
    else if((TDS_TEMP33_0 <= gu16_AD_Result_TDS_In_Temp) && (gu16_AD_Result_TDS_In_Temp < TDS_TEMP34_0))
    {
      gu16TDS_IN_Data = (U16)(gu16TDS_IN_Data * 0.83);
    }

    if (!gu16TDS_IN_Pulse)
    {
        gu16TDS_IN_Data = 0;
    }
    else{}

    // ��հ� ���ϱ�
    gu32TDS_IN_Sum += gu16TDS_IN_Data;

    if (gu16TDS_IN_Data > gu16TDS_IN_Max)
    {
        gu16TDS_IN_Max = gu16TDS_IN_Data;      // �ִ밪 ����
    }
    else{}

    if (gu16TDS_IN_Data < gu16TDS_IN_Min)
    {
      gu16TDS_IN_Min = gu16TDS_IN_Data;      // �ּҰ� ����
    }
    else{}

    if (++gu8TDS_IN_AVR_Count >= 10)
    {
        gu16TDS_IN_Data = (U16)((gu32TDS_IN_Sum - (gu16TDS_IN_Max + gu16TDS_IN_Min)) / 8);

        //gu16TDS_IN_Data = 550;     // TEST

        gu16TDS_IN_Final = gu16TDS_IN_Data;

        if(gu16TDS_IN_Final <= 160)
        {
            gu8TDS_IN_Level = 0;
        }
        else if(gu16TDS_IN_Final > 160 && gu16TDS_IN_Final <= 200)
        {
            gu8TDS_IN_Level = 1;
        }
        else if(gu16TDS_IN_Final > 200 && gu16TDS_IN_Final <= 250)
        {
            gu8TDS_IN_Level = 2;
        }
        else if(gu16TDS_IN_Final > 250 && gu16TDS_IN_Final < 350)
        {
            gu8TDS_IN_Level = 3;
        }
        else if(gu16TDS_IN_Final > 350 && gu16TDS_IN_Final < 500)
        {
            gu8TDS_IN_Level = 4;
        }
        else if(gu16TDS_IN_Final > 500)
        {
            gu8TDS_IN_Level = 5;
        }
        else{}

        gu8TDS_IN_AVR_Count = 0;
        gu32TDS_IN_Sum = 0;
        gu16TDS_IN_Max = 0;
        gu16TDS_IN_Min = 1024;
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void INTP4_TDS_Input(void)
{
    if(F_TDS_IN_Check == SET)
    {
        if(gu16TDS_IN_Pulse < 6000)
        {
            ++gu16TDS_IN_Pulse;
        }
        else{}
    }
    else{}
}
#endif
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/

