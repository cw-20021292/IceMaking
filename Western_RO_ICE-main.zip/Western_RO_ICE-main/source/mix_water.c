/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "mix_water.h"

void calc_mix_water(void);
void calc_hot_85_degree_mix_water(void);
void calc_hot_77_degree_mix_water(void);
void open_cold_valve(void);
void calc_room_mix_water(void);
void open_hot_valve(void);
void Pure_Temp_Compensation_time_Cold_Big( void );
void Pure_Temp_Compensation_time_Hot_Big( void );

void Hot_Temp_Compensation_time( void );
void Hot_Temp_45_Degree_Compensation_time_Hot_Big( void );
void Hot_Temp_45_Degree_Compensation_time_Cold_Big( void );

void calc_hot_43_degree_mix_water( void );
void check_hot_not_use(void);
void check_hot_95_temp_use(void);
void check_hot_85_95_temp_use(void);
void check_hot_fast_dec(void);





U16 gu16_water_out_time;
U16 gu16_hot_mix_time;
bit bit_open_hot_valve;
bit bit_first_room_open;
U8 gu8_room_open_timer;
U16 gu16_hot_open_timer;
U16 g16_extract_decrease_time;
U16 g16_extract_increase_time;

U8 g8_aaaa;

U16 gu16_cold_mix_time;
bit bit_open_cold_valve;
U16 gu16_cold_open_timer;

bit bit_first_open_room_valve_pure;
bit bit_first_open_room_valve_hot;


bit bit_big_mode;


U8 gu8_room_mix_abnormal_mode;


U16 gu16_devide_extract_timer;

U16 gu16_devide_total_time;
U16 gu16_devide_mix_time;
U8 gu8_devide_odd_time;
U8 gu8_devide_count;


U8 gu8_test_test;
U8 gu8_test_conv;

U16 gu16_cold_devide_extract_timer;
U16 gu16_cold_devide_total_time;
U16 gu16_cold_devide_mix_time;
U8 gu8_cold_devide_count;

U8 gu8_cold_mix_start_time;

bit bit_hot_long_not_use_state;
U16 gu16_hot_not_use_timer;


bit bit_95_degree_use_state;
U16 gu16_95_degree_use_timer;
U8 gu8_95_degree_extract_timer;

bit bit_85_95_degree_use_state;
U16 gu16_85_95_degree_use_timer;
U8 gu8_85_95_degree_extract_timer;

U16 gu16_hot_fast_dec_timer;
bit bit_hot_fast_dec;
U8 gu8_hot_temp_before;
U8 gu8_hot_temp_before_2;
U8 gu8_hot_dec_clear_cnt;
U16 gu16_dec_finish_timer;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_mix_water(void)
{
    if( u8WaterOutState == HOT_WATER_SELECT )
    {
        if( gu8_hot_setting_temperature == HOT_SET_TEMP_3__185_oF_85_oC )
        {
            calc_hot_85_degree_mix_water();
        }
        else if( gu8_hot_setting_temperature == HOT_SET_TEMP_2__170_oF_77_oC )
        {
            calc_hot_77_degree_mix_water();
        }
        else if( gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )
        {
            calc_hot_43_degree_mix_water();
        }
    }
    else if( u8WaterOutState == PURE_WATER_SELECT )
    {
        calc_room_mix_water();
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_hot_85_degree_mix_water(void)
{
    U8 mu8_a = 0;
    U8 mu8_b = 0;
    F32 f32_c = 0;
    F32 f32_time = 0;
    U16 mu16_max_time = 0;

    /*..hui [24-11-25���� 3:21:26] ������� 3��, 4�� ���� �� �ͽ� ���� ����..*/
    /*..hui [24-11-25���� 3:22:01] 3�� ������ �����µ� 86/80�̹Ƿ� 85�� ������ �ʿ����..*/
    if( gu8AltitudeStep == ALTITUDE_3_MODE_LOW )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    /*..hui [24-11-25���� 3:22:25] 4�� ������ �����µ� 79/73�̹Ƿ� 77�� ������ �ʿ����..*/
    if( gu8AltitudeStep == ALTITUDE_4_MODE_VERY_LOW )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    if( gu8_Cold_Temperature_One_Degree >= (U8)(TARGET_HOT_85_TEMP - 3) )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    /*if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_HOT_85_TEMP + 3) )*/
    if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_HOT_85_TEMP + 1) )
    {
        if( gu8_Hot_Tank_Temperature_One_Degree >= 83 )
        {
            /*..hui [24-3-29���� 11:07:37] ���� ���� �� 85�� �����Ҷ� ������ 0.3�� �ü� ����..*/
            /*..hui [24-3-29���� 11:07:53] �¼� 95�� 240ml -> 120ml -> 85�� �����ϸ� 89~�̻󳪿�..*/
            /*..hui [24-3-29���� 11:08:07] �¼���ũ�� �ü� ���� ���ܼ� �߻��ϴ� ����.....*/
            if( bit_95_degree_use_state == SET )
            {
                gu16_cold_mix_time = 3;
            }
            else
            {
                gu16_cold_mix_time = 0;
            }
        }
        else
        {
            gu16_cold_mix_time = 0;
        }

        return;
    }
    else{}

    mu8_b = TARGET_HOT_85_TEMP - gu8_Cold_Temperature_One_Degree;
    mu8_a = gu8_Hot_Tank_Temperature_One_Degree - TARGET_HOT_85_TEMP;

    f32_c = (F32)((F32)mu8_b / mu8_a);
    /*f32_c = (F32)(f32_c * 2.0f);*/
    /*2_c = (F32)(f32_c * 1.6f);*/

    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        /*f32_c = (F32)(f32_c * 1.6f);*/
        /*f32_c = (F32)(f32_c * 1.8f);*/
        f32_c = (F32)(f32_c * 1.7f);

        /*..hui [23-11-27���� 9:30:14] 1�ð� ��ġ ���� �߰�..*/
        if( bit_hot_long_not_use_state == SET )
        {
            /*..hui [24-3-29���� 9:32:40] ���ϴ� ���� Ŀ������ �ü� ���� ����..*/
            /*..hui [24-3-29���� 9:32:55] 1�ð� ��ġ�Ŀ��� �ü� �ִ��� ����..*/
            f32_c = (F32)(f32_c * 1.6f);
        }
        else if( bit_95_degree_use_state == SET )
        {
            /*..hui [24-3-29���� 11:37:29] ������ �¼� 95�� ����������.. �ü� �� �־������.. ���̻���..*/
            f32_c = (F32)(f32_c / 1.7f);
        }
        else if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            /*f32_c = (F32)(f32_c * 1.4f);*/
            f32_c = (F32)(f32_c * 1.5f);
        }
        /*else if( gu8_Mixing_Out_Temperature_One_Degree <= 70 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )*/
        else if( gu8_Mixing_Out_Temperature_One_Degree <= 60 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            /*f32_c = (F32)(f32_c * 1.3f);*/
            f32_c = (F32)(f32_c * 1.1f);
        }
        else{}

    }
    else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
    {
        f32_c = (F32)(f32_c * 1.6f);
    }
    else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
    {
        f32_c = (F32)(f32_c * 1.6f);
    }
    else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
    {
        f32_c = (F32)(f32_c * 2.0f);
    }
    else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
    {
        f32_c = (F32)(f32_c * 2.0f);
    }
    else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
    {
        /*f32_c = (F32)(f32_c * 2.0f);*/
        /*f32_c = 0;*/
        f32_c = (F32)(f32_c * 2.5f);
    }
    else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
    {
        /*f32_c = (F32)(f32_c * 2.0f);*/
        /*f32_c = 0;*/
        f32_c = (F32)(f32_c * 3.0f);
    }
    else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
    {
        /*f32_c = (F32)(f32_c * 2.0f);*/
        /*f32_c = 0;*/
        f32_c = (F32)(f32_c * 3.5f);
    }
    else
    {
        f32_c = (F32)(f32_c * 1.6f);
    }

    if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
    {
        f32_c = (F32)(f32_c * 1.5f);
    }
    else{}

    if( f32_c < 1.0f )
    {
        f32_c = 1.0f;
    }
    else{}

    f32_time = (F32)((F32)gu16_water_out_time / f32_c);

    gu16_cold_mix_time = (U16)f32_time;

    mu16_max_time = gu16_water_out_time;

    if( gu16_cold_mix_time >= mu16_max_time )
    {
        gu16_cold_mix_time = mu16_max_time;
    }
    else{}

    if( gu16_cold_mix_time <= 2 )
    {
        gu16_cold_mix_time = 0;
    }
    else
    {
        if(u8Extract_Continue != SET)
        {
            Hot_Temp_Compensation_time();
        }
        else{}
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_hot_77_degree_mix_water(void)
{
    U8 mu8_a = 0;
    U8 mu8_b = 0;
    F32 f32_c = 0;
    F32 f32_time = 0;
    U16 mu16_max_time = 0;

    /*..hui [24-11-25���� 3:22:25] 4�� ������ �����µ� 79/73�̹Ƿ� 77�� ������ �ʿ����..*/
    if( gu8AltitudeStep == ALTITUDE_4_MODE_VERY_LOW )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    if( gu8_Cold_Temperature_One_Degree >= (U8)(TARGET_HOT_77_TEMP - 3) )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    /*if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_HOT_77_TEMP + 3) )*/
    if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_HOT_77_TEMP + 1) )
    {
        /*gu16_cold_mix_time = 0;*/

        if( gu8_Hot_Tank_Temperature_One_Degree >= 73 )
        {
            /*..hui [24-3-29���� 11:07:37] ���� ���� �� 85�� �����Ҷ� ������ 0.3�� �ü� ����..*/
            /*..hui [24-3-29���� 11:07:53] �¼� 95�� 240ml -> 120ml -> 85�� �����ϸ� 89~�̻󳪿�..*/
            /*..hui [24-3-29���� 11:08:07] �¼���ũ�� �ü� ���� ���ܼ� �߻��ϴ� ����.....*/
            if( bit_85_95_degree_use_state == SET || bit_hot_fast_dec == SET )
            {
                gu16_cold_mix_time = 5;
            }
            else
            {
                gu16_cold_mix_time = 0;
            }
        }
        else
        {
            gu16_cold_mix_time = 0;
        }

        return;
    }
    else{}

    mu8_b = TARGET_HOT_77_TEMP - gu8_Cold_Temperature_One_Degree;
    mu8_a = gu8_Hot_Tank_Temperature_One_Degree - TARGET_HOT_77_TEMP;

    f32_c = (F32)((F32)mu8_b / mu8_a);

    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        /*f32_c = (F32)(f32_c * 1.9f);*/
        /*f32_c = (F32)(f32_c * 2.0f);*/
        /*f32_c = (F32)(f32_c * 2.1f);*/
        /*..hui [24-3-8���� 2:04:20] �۰��Ҽ��� �ü� ���̼���..*/
        /*f32_c = (F32)(f32_c * 2.1f);*/
        /*..hui [24-3-14���� 9:03:01] ������ ����.. �缱����..*/
        f32_c = (F32)(f32_c * 1.9f);

        /*..hui [23-11-27���� 9:35:01] �¼� 1�ð� ��ġ ���� �߰�..*/
        if( bit_hot_long_not_use_state == SET )
        {
            f32_c = (F32)(f32_c * 1.4f);
        }
        else if( gu8_Cold_Temperature_One_Degree  >= 25 )
        {
            f32_c = (F32)(f32_c * 1.3f);
        }
        else if( gu8_Cold_Temperature_One_Degree  >= 15 )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else if( bit_85_95_degree_use_state == SET || bit_hot_fast_dec == SET )
        {
            /*..hui [24-3-29���� 11:37:29] ������ �¼� 95�� ����������.. �ü� �� �־������.. ���̻���..*/
            f32_c = (F32)(f32_c / 1.3f);
        }
        else if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
    {
        f32_c = (F32)(f32_c * 1.9f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.4f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
    {
        f32_c = (F32)(f32_c * 2.2f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
    {
        f32_c = (F32)(f32_c * 2.5f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
    {
        f32_c = (F32)(f32_c * 2.7f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
    {
        f32_c = (F32)(f32_c * 2.9f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }
    else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
    {
        f32_c = (F32)(f32_c * 2.9f);
    }
    else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
    {
        f32_c = (F32)(f32_c * 2.9f);
    }
    else
    {
        f32_c = (F32)(f32_c * 1.9f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 40 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }


    #if 0
    if( gu8_Mixing_Out_Temperature_One_Degree <= 25 )
    {
        f32_c = (F32)(f32_c * 1.7f);
    }
    else
    {
        f32_c = (F32)(f32_c * 1.9f);
    }
    #endif

    #if 0
    if( gu8_Mixing_Out_Temperature_One_Degree <= 40 )
    {
        f32_c = (F32)(f32_c * 1.4f);
    }
    else{}
    #endif

    if( f32_c < 1.0f )
    {
        f32_c = 1.0f;
    }
    else{}


    f32_time = (F32)((F32)gu16_water_out_time / f32_c);

    gu16_cold_mix_time = (U16)f32_time;

    mu16_max_time = gu16_water_out_time;

    if( gu16_cold_mix_time >= mu16_max_time )
    {
        gu16_cold_mix_time = mu16_max_time;
    }
    else{}

    if( gu16_cold_mix_time <= 2 )
    {
        gu16_cold_mix_time = 0;
    }
    else
    {
        if(u8Extract_Continue != SET)
        {
            Hot_Temp_Compensation_time();
        }
        else{}
    }

    /*Hot_Temp_Compensation_time();*/

}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void open_cold_valve(void)
{
    if( Bit0_Hot_Tank_Temp_Open_Short_Error__E45 == SET
        || ( F_Hot_Enable == CLEAR && gu16_AD_Result_Hot_Tank_Temp >= TEMPERATURE_SENSOR_OPEN )
        || ( F_Hot_Enable == CLEAR && gu16_AD_Result_Hot_Tank_Temp <= TEMPERATURE_SENSOR_SHORT )
        || Bit14_Cold_Temp_Open_Short_Error__E44 == SET )
        /////|| gu16_cold_mix_time <= 2 )
    {
        bit_open_cold_valve = CLEAR;
        bit_first_open_room_valve_hot = CLEAR;
        gu16_cold_mix_time = 0;

        gu16_cold_devide_extract_timer = 0;
        gu16_cold_devide_total_time = 0;
        gu16_cold_devide_mix_time = 0;
        gu8_cold_devide_count = 0;
        return;
    }
    else{}

    if( F_WaterOut == SET )
    {
        if( u8WaterOutState == HOT_WATER_SELECT )
        {
            if( gu8_hot_setting_temperature == HOT_SET_TEMP_3__185_oF_85_oC
                || gu8_hot_setting_temperature == HOT_SET_TEMP_2__170_oF_77_oC
                || gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )
            {
                if( gu8Cup_level == CUP_LEVEL__CONTINUE )
                {
                    gu16_cold_devide_total_time = u16Efluent_Time / 5;
                    gu16_cold_devide_mix_time = gu16_cold_mix_time / 5;

                    if( gu16_cold_mix_time >= 20 && gu16_cold_mix_time <= u16Efluent_Time - 30 )
                    {
                        gu16_cold_devide_extract_timer++;

                        if( gu16Water_Extract_Timer >= COLD_MIX_START_TIME )
                        {
                            gu16_cold_open_timer++;

                            /*if( gu16_hot_open_timer >= gu16_hot_mix_time )*/
                            /*..hui [23-10-19���� 5:06:53] �ͽ�Ÿ���� Ȧ���ΰ�� 1 ������..*/
                            if( gu16_cold_open_timer >= gu16_cold_devide_mix_time )
                            {
                                gu16_cold_open_timer = gu16_cold_devide_mix_time;
                                bit_open_cold_valve = CLEAR;
                            }
                            else
                            {
                                bit_open_cold_valve = SET;
                            }

                            /*if( gu16Water_Extract_Timer >= gu16_cold_devide_total_time )*/
                            if( gu16_cold_devide_extract_timer >= gu16_cold_devide_total_time )
                            {
                                gu16_cold_devide_extract_timer = 0;

                                gu8_cold_devide_count++;

                                if( gu8_cold_devide_count <= 1 )
                                {
                                    gu16_cold_open_timer = 0;
                                }
                                else if( gu8_cold_devide_count == 2 )
                                {
                                    gu16_cold_open_timer = 0;
                                }
                                else if( gu8_cold_devide_count == 3 )
                                {
                                    gu16_cold_open_timer = 0;
                                }
                                else if( gu8_cold_devide_count == 4 )
                                {
                                    gu16_cold_open_timer = 0;
                                }
                                else
                                {
                                    gu8_cold_devide_count = 5;
                                }
                            }
                            else{}
                        }
                        else{}
                    }

                }
                else
                {
                    if( gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC
                        && gu8_Cold_Temperature_One_Degree >= 15
                        && gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
                    {
                        gu8_cold_mix_start_time = 5;
                    }
                    else
                    {
                        gu8_cold_mix_start_time = COLD_MIX_START_TIME;
                    }


                    /*if( gu16Water_Extract_Timer >= COLD_MIX_START_TIME )*/
                    if( gu16Water_Extract_Timer >= gu8_cold_mix_start_time )
                    {
                        gu16_cold_open_timer++;

                        if( gu16_cold_open_timer >= gu16_cold_mix_time )
                        {
                            gu16_cold_open_timer = gu16_cold_mix_time;
                            bit_open_cold_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_cold_valve = SET;
                        }
                    }
                    else{}
                }
            }
            else
            {
                bit_open_cold_valve = CLEAR;
                gu16_cold_open_timer = 0;

                gu16_cold_devide_extract_timer = 0;
                gu16_cold_devide_total_time = 0;
                gu16_cold_devide_mix_time = 0;
                gu8_cold_devide_count = 0;
            }


            /*..hui [23-7-17���� 10:19:59] ù �¼� �����Ҷ� ������ �������..*/
            if( bit_first_room_open == CLEAR )
            {
                if( gu16Water_Extract_Timer >= 20 )
                {
                    gu8_room_open_timer++;

                    if( gu8_room_open_timer >= 10 )
                    {
                        gu8_room_open_timer = 10;
                        bit_first_open_room_valve_hot = CLEAR;
                        bit_first_room_open = SET;
                    }
                    else
                    {
                        bit_first_open_room_valve_hot = SET;
                    }
                }
                else
                {
                    bit_first_open_room_valve_hot = CLEAR;
                    gu8_room_open_timer = 0;
                }
            }
            else
            {
                bit_first_open_room_valve_hot = CLEAR;
            }
        }
        else
        {
            bit_open_cold_valve = CLEAR;
            bit_first_open_room_valve_hot = CLEAR;
            gu16_cold_open_timer = 0;

            gu16_cold_devide_extract_timer = 0;
            gu16_cold_devide_total_time = 0;
            gu16_cold_devide_mix_time = 0;
            gu8_cold_devide_count = 0;
        }
    }
    else
    {
        bit_open_cold_valve = CLEAR;
        bit_first_open_room_valve_hot = CLEAR;
        gu16_cold_open_timer = 0;

        gu16_cold_devide_extract_timer = 0;
        gu16_cold_devide_total_time = 0;
        gu16_cold_devide_mix_time = 0;
        gu8_cold_devide_count = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_room_mix_water(void)
{
    U8 mu8_a = 0;
    U8 mu8_b = 0;
    F32 f32_c = 0;
    F32 f32_time = 0;
    U16 mu16_max_time = 0;
    U8 mu8_conv = 0;

    if( gu8_Cold_Temperature_One_Degree >= (U8)(TARGET_ROOM_27_TEMP - 3) )
    {
        gu16_hot_mix_time = 0;
        gu8_room_mix_abnormal_mode = MIX_COLD_TEMP_ABNORMAL_HIGH;
        return;
    }
    else{}

    if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_ROOM_27_TEMP + 3) )
    {
        gu16_hot_mix_time = 0;
        /*..hui [23-10-16���� 1:52:17] �¼��θ� �����Ҷ��� �¼� ����ð����� ����..*/
        /*..hui [24-1-12���� 5:15:13] ���� ���� �� �����ϸ� 4oz ����Ǵ� ����.. ū�ϳ���~~~..*/
        if(u8Extract_Continue != SET)
        {
            effluent_time_hot_normal();
        }
        else{}
        gu8_room_mix_abnormal_mode = MIX_HOT_TEMP_ABNORMAL_LOW;
        return;
    }
    else{}

    gu8_room_mix_abnormal_mode = MIX_ALL_NORMAL;

    /*..hui [23-7-11���� 3:15:47] �����µ� ������ 25~30����..*/
    mu8_a = TARGET_ROOM_27_TEMP - gu8_Cold_Temperature_One_Degree;
    mu8_b = gu8_Hot_Tank_Temperature_One_Degree - TARGET_ROOM_27_TEMP;

    //if( mu8_a <= mu8_b && mu8_a + 7 <= mu8_b )

    if( mu8_a <= mu8_b && mu8_a + 15 >= mu8_b )
    {
        mu8_conv = 1;
        gu8_test_conv = 1;
    }
    else
    {
        gu8_test_conv = 0;
    }

    if( mu8_a <= mu8_b && mu8_conv == 0 )
    {
        bit_big_mode = COLD__BIG;

        f32_c = (F32)((F32)mu8_b / mu8_a);

        if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 60 )
            {
                //f32_c = (F32)(f32_c / 2.3f);
                //f32_c = (F32)(f32_c / 2.1f);
                f32_c = (F32)(f32_c / 2.4f);
            }
            else if( gu8_Cold_Temperature_One_Degree >= 15 )
            {
                //f32_c = (F32)(f32_c / 2.3f);
                //f32_c = (F32)(f32_c / 2.1f);
                f32_c = (F32)(f32_c / 2.5f);
            }
            else if( gu8_Cold_Temperature_One_Degree >= 10 && gu8_Hot_Tank_Temperature_One_Degree >= 80 )
            {
                f32_c = (F32)(f32_c / 2.3f);
            }
            else if( gu8_Mixing_Out_Temperature_One_Degree >= 70 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
            {
                f32_c = (F32)(f32_c / 1.8f);
            }
            else
            {
                //f32_c = (F32)(f32_c / 2.1f);
                f32_c = (F32)(f32_c / 2.0f);
            }

            /*..hui [23-11-29���� 11:27:35] 1�ð� �̻� �̻���..*/
            /*..hui [23-12-1���� 5:12:47] �¼��� �� �־������?..*/
            if( bit_hot_long_not_use_state == SET )
            {
                f32_c = (F32)(f32_c / 1.1f);
            }
            else if( bit_hot_fast_dec == SET )
            {
                f32_c = (F32)(f32_c * 1.1f);
            }
            else{}
        }
        else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
        {
            /*f32_c = (F32)(f32_c / 2.1f);*/
            f32_c = (F32)(f32_c / 2.0f);
        }
        else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
        {
            /*f32_c = (F32)(f32_c / 2.0f);*/
            f32_c = (F32)(f32_c / 1.9f);
        }
        else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
        {
            /*f32_c = (F32)(f32_c / 1.9f);*/
            /*..hui [24-2-28���� 11:13:50] ���������� �µ� �ö�..*/
            f32_c = (F32)(f32_c / 2.0f);
        }
        else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
        {
            /*f32_c = (F32)(f32_c / 1.8f);*/
            f32_c = (F32)(f32_c / 1.9f);
        }
        else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
        {
            /*f32_c = (F32)(f32_c / 1.8f);*/
            f32_c = (F32)(f32_c / 1.9f);
        }
        else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
        {
            /*f32_c = (F32)(f32_c / 1.7f);*/
            f32_c = (F32)(f32_c / 1.8f);
        }
        else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
        {
            f32_c = (F32)(f32_c / 1.7f);
        }
        else if( gu8Cup_level == CUP_LEVEL__CONTINUE )
        {
            /*f32_c = (F32)(f32_c / 1.7f);*/
            f32_c = (F32)(f32_c / 1.9f);
        }
    }
    else
    {
        /*..hui [24-3-29���� 5:23:47] �¼��� ��ӿ��� �ü��� ����..*/
        bit_big_mode = HOT__BIG;
        f32_c = (F32)((F32)mu8_a / mu8_b);

        if( gu8_test_conv == 0 )
        {
            ///f32_c = (F32)(f32_c * 2.5f);
            //f32_c = (F32)(f32_c * 2.8f);
            //f32_c = (F32)(f32_c * 2.7f);
            /*f32_c = (F32)(f32_c * 2.7f);*/
            f32_c = (F32)(f32_c * 2.5f);
        }
        else
        {
            /*f32_c = (F32)(f32_c * 3.3f);*/
            f32_c = (F32)(f32_c * 3.2f);
        }

        if( bit_hot_fast_dec == SET )
        {
            f32_c = (F32)(f32_c / 1.2f);
        }
        else{}

        if(u8Extract_Continue != SET)
        {
            effluent_time_hot_normal();
            gu16_water_out_time = u16Efluent_Time;
        }
        else{}
    }

    if( f32_c < 1.0f )
    {
        f32_c = 1.0f;
    }
    else{}

    if( bit_big_mode == COLD__BIG )
    {
        f32_time = (F32)((F32)gu16_water_out_time / f32_c);

        gu16_hot_mix_time = (U16)f32_time;

        mu16_max_time = gu16_water_out_time;

        if( gu16_hot_mix_time >= mu16_max_time )
        {
            gu16_hot_mix_time = mu16_max_time;
        }
        else{}

        if(u8Extract_Continue != SET)
        {
            Pure_Temp_Compensation_time_Cold_Big();
        }
        else{}
    }
    else /*if( bit_big_mode == HOT__BIG )*/
    {
        f32_time = (F32)((F32)gu16_water_out_time / f32_c);

        gu16_hot_mix_time = (U16)f32_time;

        mu16_max_time = gu16_water_out_time;

        if( gu16_hot_mix_time >= mu16_max_time )
        {
            gu16_hot_mix_time = mu16_max_time;
        }
        else{}

        if(u8Extract_Continue != SET)
        {
            Pure_Temp_Compensation_time_Hot_Big();
        }
        else{}
    }

}





/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void open_hot_valve(void)
{
    U8 mu8_odd = 0;
    U8 mu8_devide_max = 0;

    if( Bit0_Hot_Tank_Temp_Open_Short_Error__E45 == SET
        || ( F_Hot_Enable == CLEAR && gu16_AD_Result_Hot_Tank_Temp >= TEMPERATURE_SENSOR_OPEN )
        || ( F_Hot_Enable == CLEAR && gu16_AD_Result_Hot_Tank_Temp <= TEMPERATURE_SENSOR_SHORT )
        || Bit14_Cold_Temp_Open_Short_Error__E44 == SET
        || gu16_hot_mix_time <= 4 )
    {
        bit_open_hot_valve = CLEAR;
        bit_first_open_room_valve_pure = CLEAR;
        gu16_hot_open_timer = 0;
        gu8_devide_count = 0;
        gu8_devide_odd_time = 0;
        gu16_devide_extract_timer = 0;
        return;
    }
    else{}

    if( F_WaterOut == SET )
    {
        if( u8WaterOutState == PURE_WATER_SELECT )
        {
            /*..hui [23-10-19���� 4:14:17] ���� 475�̸�, 590�̸��� �켱 ������ ����..*/
            if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML
                || gu8Cup_level == CUP_LEVEL__10_OZ__295_ML
                || gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
                /*|| gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )*/
            {
                gu16_devide_total_time = u16Efluent_Time / 2;
                gu16_devide_mix_time = gu16_hot_mix_time / 2;

                /////mu8_odd

                if( gu16_hot_mix_time >= 20 && gu16_hot_mix_time <= u16Efluent_Time - 30 )
                {
                    if( gu16_hot_mix_time % 2 == 1 )
                    {
                        mu8_odd = 1;
                    }
                    else{}

                    if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )
                    {
                        gu16_hot_open_timer++;

                        /*if( gu16_hot_open_timer >= gu16_hot_mix_time )*/
                        /*..hui [23-10-19���� 5:06:53] �ͽ�Ÿ���� Ȧ���ΰ�� 1 ������..*/
                        if( gu16_hot_open_timer >= gu16_devide_mix_time + gu8_devide_odd_time )
                        {
                            gu16_hot_open_timer = gu16_devide_mix_time + gu8_devide_odd_time;
                            bit_open_hot_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_hot_valve = SET;
                        }

                        if( gu16Water_Extract_Timer >= gu16_devide_total_time )
                        {
                            gu8_devide_count++;

                            if( gu8_devide_count <= 1 )
                            {
                                gu16_hot_open_timer = 0;
                                gu8_devide_odd_time = mu8_odd;
                            }
                            else
                            {
                                gu8_devide_count = 2;
                            }
                        }
                        else{}
                    }
                    else{}
                }
                else
                {
                    if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )
                    {
                        gu16_hot_open_timer++;

                        if( gu16_hot_open_timer >= gu16_hot_mix_time )
                        {
                            gu16_hot_open_timer = gu16_hot_mix_time;
                            bit_open_hot_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_hot_valve = SET;
                        }
                    }
                    else{}
                }
            }
            else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML
                     || gu8Cup_level == CUP_LEVEL__16_OZ__475_ML
                     || gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
            {
                /*..hui [24-2-28���� 1:52:39] 415�� 3�� �����°ɷ�..*/
                gu16_devide_total_time = u16Efluent_Time / 3;
                gu16_devide_mix_time = gu16_hot_mix_time / 3;

                /////mu8_odd

                if( gu16_hot_mix_time >= 20 && gu16_hot_mix_time <= u16Efluent_Time - 30 )
                {
                    if( gu16_hot_mix_time % 3 == 1 )
                    {
                        mu8_odd = 1;
                    }
                    else if( gu16_hot_mix_time % 3 == 2 )
                    {
                        mu8_odd = 2;
                    }
                    else{}

                    gu16_devide_extract_timer++;

                    if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )
                    {
                        gu16_hot_open_timer++;

                        /*if( gu16_hot_open_timer >= gu16_hot_mix_time )*/
                        /*..hui [23-10-19���� 5:06:53] �ͽ�Ÿ���� Ȧ���ΰ�� 1 ������..*/
                        if( gu16_hot_open_timer >= gu16_devide_mix_time + gu8_devide_odd_time )
                        {
                            gu16_hot_open_timer = gu16_devide_mix_time + gu8_devide_odd_time;
                            bit_open_hot_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_hot_valve = SET;
                        }

                        /*if( gu16Water_Extract_Timer >= gu16_devide_total_time )*/
                        if( gu16_devide_extract_timer >= gu16_devide_total_time )
                        {
                            gu16_devide_extract_timer = 0;

                            gu8_devide_count++;

                            if( gu8_devide_count <= 1 )
                            {
                                gu16_hot_open_timer = 0;
                                gu8_devide_odd_time = 0;
                            }
                            else if( gu8_devide_count == 2 )
                            {
                                gu16_hot_open_timer = 0;
                                gu8_devide_odd_time = mu8_odd;
                            }
                            else
                            {
                                gu8_devide_count = 3;
                            }
                        }
                        else{}
                    }
                    else{}
                }
                else
                {
                    if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )
                    {
                        gu16_hot_open_timer++;

                        if( gu16_hot_open_timer >= gu16_hot_mix_time )
                        {
                            gu16_hot_open_timer = gu16_hot_mix_time;
                            bit_open_hot_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_hot_valve = SET;
                        }
                    }
                    else{}
                }
            }
            else if( gu8Cup_level == CUP_LEVEL__CONTINUE )
            {
                /*gu16_devide_total_time = u16Efluent_Time / 5;*/
                /*gu16_devide_mix_time = gu16_hot_mix_time / 5;*/

                /*..hui [24-2-28���� 3:41:48] �¼� �ͽ� �� �ð��� 10�� �����̸� 5ȸ ����..*/
                /*..hui [24-2-28���� 3:41:54] 10�� �ʰ��̸� 10ȸ ����..*/
                /*..hui [24-2-28���� 3:43:42] 6�� �����̸� 3ȸ ����..*/
                if( gu16_hot_mix_time <= 60 )
                {
                    gu16_devide_total_time = u16Efluent_Time / 3;
                    gu16_devide_mix_time = gu16_hot_mix_time / 3;
                    mu8_devide_max = 0;
                }
                else if( gu16_hot_mix_time <= 120 )
                {
                    gu16_devide_total_time = u16Efluent_Time / 5;
                    gu16_devide_mix_time = gu16_hot_mix_time / 5;
                    mu8_devide_max = 1;
                }
                else
                {
                    gu16_devide_total_time = u16Efluent_Time / 10;
                    gu16_devide_mix_time = gu16_hot_mix_time / 10;
                    mu8_devide_max = 2;
                }

                /////mu8_odd

                /*if( gu16_hot_mix_time >= 20 && gu16_hot_mix_time <= u16Efluent_Time - 30 )*/
                if( gu16_hot_mix_time >= 30 && gu16_hot_mix_time <= u16Efluent_Time - 30 )
                {
                    gu16_devide_extract_timer++;

                    /*if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )*/
                    /*..hui [24-2-28���� 3:58:46] �ü� 2�� ���� �־��ְ��������� ����..*/
                    if( gu16Water_Extract_Timer >= 20 )
                    {
                        gu16_hot_open_timer++;

                        /*if( gu16_hot_open_timer >= gu16_hot_mix_time )*/
                        /*..hui [23-10-19���� 5:06:53] �ͽ�Ÿ���� Ȧ���ΰ�� 1 ������..*/
                        if( gu16_hot_open_timer >= gu16_devide_mix_time )
                        {
                            gu16_hot_open_timer = gu16_devide_mix_time;
                            bit_open_hot_valve = CLEAR;
                        }
                        else
                        {
                            bit_open_hot_valve = SET;
                        }

                        /*if( gu16Water_Extract_Timer >= gu16_devide_total_time )*/
                        if( gu16_devide_extract_timer >= gu16_devide_total_time )
                        {
                            gu16_devide_extract_timer = 0;

                            gu8_devide_count++;

                            if( gu8_devide_count <= 1 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 2 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 3 )
                            {
                                if( mu8_devide_max == 0 )
                                {
                                    gu8_devide_count = 3;
                                }
                                else
                                {
                                    gu16_hot_open_timer = 0;
                                }
                            }
                            else if( gu8_devide_count == 4 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 5 )
                            {
                                if( mu8_devide_max == 1 )
                                {
                                    gu8_devide_count = 5;
                                }
                                else
                                {
                                    gu16_hot_open_timer = 0;
                                }
                            }
                            else if( gu8_devide_count == 6 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 7 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 8 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else if( gu8_devide_count == 9 )
                            {
                                gu16_hot_open_timer = 0;
                            }
                            else
                            {
                                gu8_devide_count = 10;
                            }
                        }
                        else{}
                    }
                    else{}
                }
            }
            else
            {
                if( gu16Water_Extract_Timer >= HOT_MIX_START_TIME )
                {
                    gu16_hot_open_timer++;

                    if( gu16_hot_open_timer >= gu16_hot_mix_time )
                    {
                        gu16_hot_open_timer = gu16_hot_mix_time;
                        bit_open_hot_valve = CLEAR;
                    }
                    else
                    {
                        bit_open_hot_valve = SET;
                    }
                }
                else{}
            }

            if( bit_first_room_open == CLEAR )
            {
                if( gu16Water_Extract_Timer >= 20 )
                {
                    gu8_room_open_timer++;

                    if( gu8_room_open_timer >= 10 )
                    {
                        gu8_room_open_timer = 10;
                        bit_first_open_room_valve_pure = CLEAR;
                        bit_first_room_open = SET;
                    }
                    else
                    {
                        bit_first_open_room_valve_pure = SET;
                    }
                }
                else
                {
                    bit_first_open_room_valve_pure = CLEAR;
                    gu8_room_open_timer = 0;
                }
            }
            else
            {
                bit_first_open_room_valve_pure = CLEAR;
            }
        }
        else
        {
            bit_open_hot_valve = CLEAR;
            bit_first_open_room_valve_pure = CLEAR;
            gu16_hot_open_timer = 0;
            gu8_devide_count = 0;
            gu8_devide_odd_time = 0;
            gu16_devide_extract_timer = 0;
        }
    }
    else
    {
        bit_open_hot_valve = CLEAR;
        bit_first_open_room_valve_pure = CLEAR;
        gu16_hot_open_timer = 0;
        gu8_devide_count = 0;
        gu8_devide_odd_time = 0;
        gu16_devide_extract_timer = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Pure_Temp_Compensation_time_Cold_Big( void )
{
    U16 mu16_a = 0;
    U32 mu32_b = 0;
    U32 mu32_c = 0;
    U16 mu16_final = 0;
    U16 mu16_limit = 0;


    /*..hui [23-5-23���� 7:04:38] ������ �ƴҶ��� �н�..*/
    if( u8WaterOutState != PURE_WATER_SELECT )
    {
        return;
    }
    else{}

    mu16_a = gu16_hot_mix_time / 10;

    mu16_final = mu16_a * 2;

    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        if( gu8_Hot_Tank_Temperature_One_Degree <= 60 )
        {
            if( mu16_final >= 2 )
            {
                mu16_final = mu16_final - 2;
            }
            else{}
        }
        else
        {
            mu16_final = mu16_final + 2;
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
    {
        mu16_final = mu16_final + 2;
    }
    else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
    {
        /*mu16_final = mu16_final + 5;*/
        mu16_final = mu16_final + 9;
    }
    else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
    {
        mu16_final = mu16_final + 9;
    }
    else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
    {
        mu16_final = mu16_final + 12;
    }
    else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
    {
        mu16_final = mu16_final + 10;
    }
    else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
    {
        mu16_final = mu16_final + 20;
    }
    else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
    {
        mu16_final = mu16_final + 20;
    }
    else{}


    /*..hui [23-5-23���� 5:54:03] �ִ� ����ð��� 80%�� ����..*/
    /*..sean [23-5-24] �ִ� ����ð��� 70%�� ����..*/

    mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);

    if( mu16_final >= mu16_limit )
    {
        g16_extract_decrease_time = mu16_limit;
    }
    else
    {
        g16_extract_decrease_time = mu16_final;
    }

    /*..hui [23-5-23���� 5:58:04] ����.. 2�ʴ� ��ü ����ð��� 1.5 percent ���ش�..*/
    u16Efluent_Time = (u16Efluent_Time - g16_extract_decrease_time );
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Pure_Temp_Compensation_time_Hot_Big( void )
{
    U16 mu16_a = 0;
    U32 mu32_b = 0;
    U32 mu32_c = 0;
    U16 mu16_final = 0;
    U16 mu16_limit = 0;


    /*..hui [23-5-23���� 7:04:38] ������ �ƴҶ��� �н�..*/
    if( u8WaterOutState != PURE_WATER_SELECT )
    {
        return;
    }
    else{}

    /*mu16_a = gu16_hot_mix_time / 10;*/

    /*mu16_final = mu16_a * 2;*/

    if( gu8_test_conv == 0 )
    {
        /*mu16_a = (U16)(((U32)gu16_hot_mix_time * (U32)140) / 100 );*/
        /*mu16_a = (U16)(((U32)gu16_hot_mix_time * (U32)130) / 100 );*/
        mu16_a = (U16)(((U32)gu16_hot_mix_time * (U32)110) / 100 );
    }
    else
    {
        mu16_a = (U16)(((U32)gu16_hot_mix_time * (U32)120) / 100 );
    }

    mu16_final = mu16_a;

    /*..hui [23-5-23���� 5:54:03] �ִ� ����ð��� 80%�� ����..*/
    /*..sean [23-5-24] �ִ� ����ð��� 70%�� ����..*/

    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);*/

    if( gu8_test_conv == 0 )
    {
        mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);
    }
    else
    {
        /*mu16_limit = (U16)(((U32)u16Efluent_Time * 50) / 100);*/
        mu16_limit = (U16)(((U32)u16Efluent_Time * 45) / 100);
    }

    if( mu16_final >= mu16_limit )
    {
        g16_extract_decrease_time = mu16_limit;
    }
    else
    {
        g16_extract_decrease_time = mu16_final;
    }

    /*..hui [23-5-23���� 5:58:04] ����.. 2�ʴ� ��ü ����ð��� 1.5 percent ���ش�..*/
    u16Efluent_Time = (u16Efluent_Time - g16_extract_decrease_time );
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Hot_Temp_Compensation_time( void )
{
    U16 mu16_a = 0;
    U32 mu32_b = 0;
    U32 mu32_c = 0;
    U16 mu16_final = 0;
    U16 mu16_limit = 0;


    /*..hui [23-5-23���� 7:04:38] ������ �ƴҶ��� �н�..*/
    if( u8WaterOutState != HOT_WATER_SELECT )
    {
        return;
    }
    else{}

    if( gu8_hot_setting_temperature != HOT_SET_TEMP_1__110_oF_43_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_2__170_oF_77_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_3__185_oF_85_oC )
    {
        return;
    }
    else{}

    /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)140) / 100 );*/
    /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)135) / 100 );*/
    mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)130) / 100 );

    mu16_final = mu16_a;

    /*..hui [23-5-23���� 5:54:03] �ִ� ����ð��� 80%�� ����..*/
    /*..sean [23-5-24] �ִ� ����ð��� 70%�� ����..*/

    mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);

    if( mu16_final >= mu16_limit )
    {
        g16_extract_decrease_time = mu16_limit;
    }
    else
    {
        g16_extract_decrease_time = mu16_final;
    }

    u16Efluent_Time = (u16Efluent_Time - g16_extract_decrease_time );
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Hot_Temp_45_Degree_Compensation_time_Hot_Big( void )
{
    U16 mu16_a = 0;
    U32 mu32_b = 0;
    U32 mu32_c = 0;
    U16 mu16_final = 0;
    U16 mu16_limit = 0;


    /*..hui [23-5-23���� 7:04:38] ������ �ƴҶ��� �н�..*/
    if( u8WaterOutState != HOT_WATER_SELECT )
    {
        return;
    }
    else{}

    if( gu8_hot_setting_temperature != HOT_SET_TEMP_1__110_oF_43_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_2__170_oF_77_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_3__185_oF_85_oC )
    {
        return;
    }
    else{}


    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        if( gu8_Hot_Tank_Temperature_One_Degree >= 90 )
        {
            /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)95) / 100 );*/
            /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)100) / 100 );*/
            /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)105) / 100 );*/
            /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)95) / 100 );*/
            /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)85) / 100 );*/
            mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)90) / 100 );
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)100) / 100 );*/
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)105) / 100 );*/
                //mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)110) / 100 );
                ///mu16_a = mu16_a + 3;
                mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)90) / 100 );

                //if( gu8_Cold_Temperature_One_Degree >= 25 )
                if( gu8_Cold_Temperature_One_Degree >= 10 )
                {
                    mu16_a = mu16_a - 2;
                }
                else{}
            }
            else
            {
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)110) / 100 );*/
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)115) / 100 );*/
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)120) / 100 );*/
                /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)110) / 100 );*/
                //mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)90) / 100 );
                mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)85) / 100 );

                if( gu8_Cold_Temperature_One_Degree >= 25 )
                {
                    if( mu16_a > 3 )
                    {
                        mu16_a = mu16_a - 3;
                    }
                    else{}
                }
                else{}
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
    {
        if( gu8_Hot_Tank_Temperature_One_Degree <= 80 )
        {
            mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)130) / 100 );
        }
        else
        {
            //mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)140) / 100 );
            //mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)130) / 100 );
            mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)120) / 100 );
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)120) / 100 );
    }
    else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)130) / 100 );
    }
    else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)120) / 100 );
    }
    else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)140) / 100 );
    }
    else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)130) / 100 );
    }
    else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)140) / 100 );
    }
    else
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)110) / 100 );
    }


    mu16_final = mu16_a;

    /*..hui [23-5-23���� 5:54:03] �ִ� ����ð��� 80%�� ����..*/
    /*..sean [23-5-24] �ִ� ����ð��� 70%�� ����..*/

    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);*/
    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 50) / 100);*/
    if( gu8_Hot_Tank_Temperature_One_Degree >= 90 )
    {
        if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML
            && gu8_Cold_Temperature_One_Degree >= 25
            && gu16_cold_mix_time >= HOT_STOP_COLD_MIX_TIME )
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 45) / 100);
        }
        else if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML
                 && gu8_Cold_Temperature_One_Degree >= 20
                 && gu16_cold_mix_time >= HOT_STOP_COLD_MIX_TIME_2 )
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 45) / 100);
        }
        else
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 50) / 100);
        }
    }
    else
    {
        if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML
            && gu8_Cold_Temperature_One_Degree >= 25
            && gu16_cold_mix_time >= HOT_STOP_COLD_MIX_TIME )
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 45) / 100);
        }
        else if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML
                 && gu8_Cold_Temperature_One_Degree >= 20
                 && gu16_cold_mix_time >= HOT_STOP_COLD_MIX_TIME_2 )
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 45) / 100);
        }
        else if( gu8_Cold_Temperature_One_Degree >= 15 && gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 48) / 100);
        }
        else
        {
            mu16_limit = (U16)(((U32)u16Efluent_Time * 55) / 100);
        }
    }
    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 60) / 100);*/

    if( mu16_final >= mu16_limit )
    {
        g16_extract_decrease_time = mu16_limit;
    }
    else
    {
        g16_extract_decrease_time = mu16_final;
    }

    u16Efluent_Time = (u16Efluent_Time - g16_extract_decrease_time );
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void Hot_Temp_45_Degree_Compensation_time_Cold_Big( void )
{
    U16 mu16_a = 0;
    U32 mu32_b = 0;
    U32 mu32_c = 0;
    U16 mu16_final = 0;
    U16 mu16_limit = 0;

    #if 0
    /*..hui [23-5-23���� 7:04:38] ������ �ƴҶ��� �н�..*/
    if( u8WaterOutState != HOT_WATER_SELECT )
    {
        return;
    }
    else{}

    if( gu8_hot_setting_temperature != HOT_SET_TEMP_1__110_oF_43_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_2__170_oF_77_oC
        && gu8_hot_setting_temperature != HOT_SET_TEMP_3__185_oF_85_oC )
    {
        return;
    }
    else{}

    /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)140) / 100 );*/
    /*mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)70) / 100 );*/

    #if 0
    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)78) / 100 );
    }
    else
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)70) / 100 );
    }
    #endif

    #if 0
    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        //mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)75) / 100 );
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)90) / 100 );
    }
    else
    {
        mu16_a = (U16)(((U32)gu16_cold_mix_time * (U32)75) / 100 );
    }
    #endif


    mu16_final = mu16_a;


    mu16_a = gu16_hot_mix_time / 10;

    mu16_final = mu16_a * 2;

    /*..hui [23-5-23���� 5:54:03] �ִ� ����ð��� 80%�� ����..*/
    /*..sean [23-5-24] �ִ� ����ð��� 70%�� ����..*/

    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 40) / 100);*/
    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 50) / 100);*/
    mu16_limit = (U16)(((U32)u16Efluent_Time * 55) / 100);
    /*mu16_limit = (U16)(((U32)u16Efluent_Time * 60) / 100);*/

    if( mu16_final >= mu16_limit )
    {
        g16_extract_decrease_time = mu16_limit;
    }
    else
    {
        g16_extract_decrease_time = mu16_final;
    }

    u16Efluent_Time = (u16Efluent_Time - g16_extract_decrease_time );
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_hot_43_degree_mix_water( void )
{
    U8 mu8_a = 0;
    U8 mu8_b = 0;
    F32 f32_c = 0;
    F32 f32_time = 0;
    U16 mu16_max_time = 0;

    if( gu8_Cold_Temperature_One_Degree >= (U8)(TARGET_HOT_43_TEMP - 3) )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    if( gu8_Hot_Tank_Temperature_One_Degree <= (U8)(TARGET_HOT_43_TEMP + 3) )
    {
        gu16_cold_mix_time = 0;
        return;
    }
    else{}

    mu8_b = TARGET_HOT_43_TEMP - gu8_Cold_Temperature_One_Degree;
    mu8_a = gu8_Hot_Tank_Temperature_One_Degree - TARGET_HOT_43_TEMP;



////////////////////////////////////////////////////////////////////////////////////////
    /*bit_big_mode = HOT__BIG;*/

    #if 0
    if( gu8_Cold_Temperature_One_Degree >= 25 )
    {
        bit_big_mode = COLD__BIG;

    }
    else
    {
        bit_big_mode = HOT__BIG;

    }
    #endif

    bit_big_mode = HOT__BIG;

    f32_c = (F32)((F32)mu8_b / mu8_a);

    if( f32_c < 1.0f )
    {
        gu8_test_test = 1;
    }
    else
    {
        gu8_test_test = 2;
    }


    if( gu8Cup_level == CUP_LEVEL__4_OZ__120_ML )
    {
        /*f32_c = (F32)(f32_c * 1.7f);*/
        if( f32_c < 1.0f )
        {
            /*f32_c = (F32)(f32_c * 2.9f);*/
            /*f32_c = (F32)(f32_c * 3.0f);*/
            /*f32_c = (F32)(f32_c * 2.8f);*/
            /*f32_c = (F32)(f32_c * 2.9f);*/
            /*f32_c = (F32)(f32_c * 3.0f);*/
            if( gu8_Hot_Tank_Temperature_One_Degree >= 94 )
            {
                //f32_c = (F32)(f32_c * 3.2f);
                //f32_c = (F32)(f32_c * 3.3f);
                //f32_c = (F32)(f32_c * 3.4f);
                //f32_c = (F32)(f32_c * 3.3f);
                //f32_c = (F32)(f32_c * 3.2f);

                if( gu8_Cold_Temperature_One_Degree < 15 )
                {
                    f32_c = (F32)(f32_c * 3.2f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 25 )
                {
                    f32_c = (F32)(f32_c * 3.3f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 30 )
                {
                    f32_c = (F32)(f32_c * 3.4f);
                }
                else
                {
                    f32_c = (F32)(f32_c * 3.2f);
                }
            }
            else if( gu8_Hot_Tank_Temperature_One_Degree >= 80 )
            {
                //f32_c = (F32)(f32_c * 3.1f);
                //f32_c = (F32)(f32_c * 3.2f);
                //f32_c = (F32)(f32_c * 3.1f);
                //f32_c = (F32)(f32_c * 3.0f);
                //f32_c = (F32)(f32_c * 2.9f);
                if( gu8_Cold_Temperature_One_Degree < 10 )
                {
                    f32_c = (F32)(f32_c * 2.7f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 15 )
                {
                    f32_c = (F32)(f32_c * 2.9f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 25 )
                {
                    f32_c = (F32)(f32_c * 3.1f);
                }
                else
                {
                    f32_c = (F32)(f32_c * 3.2f);
                }
            }
            else
            {
                /*f32_c = (F32)(f32_c * 3.0f);*/
                /*f32_c = (F32)(f32_c * 2.9f);*/
                //f32_c = (F32)(f32_c * 3.0f);
                //f32_c = (F32)(f32_c * 2.9f);
                //f32_c = (F32)(f32_c * 2.8f);
                //f32_c = (F32)(f32_c * 2.7f);

                if( gu8_Cold_Temperature_One_Degree < 15 )
                {
                    //f32_c = (F32)(f32_c * 2.7f);
                    f32_c = (F32)(f32_c * 2.5f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 25 )
                {
                    f32_c = (F32)(f32_c * 2.9f);
                }
                else
                {
                    f32_c = (F32)(f32_c * 2.9f);
                }
            }
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 60 )
            {
                ////f32_c = (F32)(f32_c * 2.1f);
                f32_c = (F32)(f32_c * 1.8f);
            }
            else if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                //f32_c = (F32)(f32_c * 2.2f);
                /*f32_c = (F32)(f32_c * 2.3f);*/
                /*f32_c = (F32)(f32_c * 2.4f);*/
                /*f32_c = (F32)(f32_c * 2.5f);*/
                /*f32_c = (F32)(f32_c * 2.4f);*/
                //f32_c = (F32)(f32_c * 2.3f);
                //f32_c = (F32)(f32_c * 2.2f);

                if( gu8_Cold_Temperature_One_Degree < 15 )
                {
                    /////f32_c = (F32)(f32_c * 2.2f);
                    f32_c = (F32)(f32_c * 2.0f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 25 )
                {
                    ///f32_c = (F32)(f32_c * 2.5f);
                    f32_c = (F32)(f32_c * 2.3f);
                }
                else
                {
                    /////f32_c = (F32)(f32_c * 2.7f);
                    f32_c = (F32)(f32_c * 2.5f);
                }


            }
            else
            {
                /*f32_c = (F32)(f32_c * 2.5f);*/
                /*f32_c = (F32)(f32_c * 2.7f);*/
                //f32_c = (F32)(f32_c * 2.7f);
                /*f32_c = (F32)(f32_c * 2.2f);*/
                //f32_c = (F32)(f32_c * 2.5f);
                if( gu8_Cold_Temperature_One_Degree < 15 )
                {
                    ////f32_c = (F32)(f32_c * 2.6f);
                    f32_c = (F32)(f32_c * 2.4f);
                }
                else if( gu8_Cold_Temperature_One_Degree < 25 )
                {
                    /////f32_c = (F32)(f32_c * 2.9f);
                    f32_c = (F32)(f32_c * 2.7f);
                }
                else
                {
                    /////f32_c = (F32)(f32_c * 3.1f);
                    f32_c = (F32)(f32_c * 2.9f);
                }
            }
        }

        /*..hui [23-11-24���� 2:24:06] 43�� ù �� ����� 53�� ������ ����.. ����..*/
        /*if( gu8_Mixing_Out_Temperature_One_Degree <= 30 )*/
        if( bit_hot_long_not_use_state == SET )
        {
            f32_c = (F32)(f32_c * 1.1f);
        }
        else if( gu8_Mixing_Out_Temperature_One_Degree <= 30 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            /*f32_c = (F32)(f32_c * 1.7f);*/
            /*f32_c = (F32)(f32_c * 1.1f);*/
            f32_c = (F32)(f32_c * 1.1f);
        }
        else if( gu8_Mixing_Out_Temperature_One_Degree >= 80 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            /*..hui [23-11-30���� 4:27:58] ���� �����Ŀ� 43�� ����������..*/
            f32_c = (F32)(f32_c / 1.1f);
        }
        else{}

    }
    else if( gu8Cup_level == CUP_LEVEL__6_OZ__175_ML )
    {
        ///////f32_c = (F32)(f32_c * 4.0f);

        if( f32_c < 1.0f )
        {
            if( gu8_Cold_Temperature_One_Degree >= 15 )
            {
                f32_c = (F32)(f32_c * 3.5f);
            }
            else if( gu8_Hot_Tank_Temperature_One_Degree >= 90 )
            {
                ///f32_c = (F32)(f32_c * 3.5f);
                ///f32_c = (F32)(f32_c * 3.3f);
                ///f32_c = (F32)(f32_c * 3.4f);
                ///f32_c = (F32)(f32_c * 3.5f);
                f32_c = (F32)(f32_c * 3.6f);
            }
            else
            {
                //f32_c = (F32)(f32_c * 4.0f);
                //f32_c = (F32)(f32_c * 3.7f);
                //f32_c = (F32)(f32_c * 3.6f);
                //f32_c = (F32)(f32_c * 3.5f);
                f32_c = (F32)(f32_c * 3.2f);
            }
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 60 )
            {
                f32_c = (F32)(f32_c * 2.0f);
            }
            else if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.2f);
            }
            else
            {
                ////f32_c = (F32)(f32_c * 3.0f);
                ////f32_c = (F32)(f32_c * 2.6f);
                f32_c = (F32)(f32_c * 2.7f);
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__8_OZ__235_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.6f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.2f);
            }
            else
            {
                if( gu16_user_water_out_count >= 8 )
                {
                    f32_c = (F32)(f32_c * 2.2f);
                }
                else
                {
                    f32_c = (F32)(f32_c * 2.5f);
                }
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__10_OZ__295_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.7f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.4f);
            }
            else
            {
                f32_c = (F32)(f32_c * 2.8f);
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__12_OZ__355_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.7f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.4f);
            }
            else
            {
                f32_c = (F32)(f32_c * 2.8f);
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__14_OZ__415_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.7f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.4f);
            }
            else
            {
                f32_c = (F32)(f32_c * 2.8f);
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__16_OZ__475_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.7f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 3.0f);
            }
            else
            {
                f32_c = (F32)(f32_c * 3.0f);
            }
        }
    }
    else if( gu8Cup_level == CUP_LEVEL__20_OZ__590_ML )
    {
        if( f32_c < 1.0f )
        {
            f32_c = (F32)(f32_c * 3.7f);
        }
        else
        {
            if( gu8_Hot_Tank_Temperature_One_Degree <= 70 )
            {
                f32_c = (F32)(f32_c * 2.7f);
            }
            else
            {
                f32_c = (F32)(f32_c * 3.0f);
            }
        }

    }
    else
    {
        f32_c = (F32)(f32_c * 1.9f);

        if( gu8_Mixing_Out_Temperature_One_Degree <= 30 && bit_Mixing_Out_Temp_Open_Short_Error__E52 == CLEAR )
        {
            f32_c = (F32)(f32_c * 1.2f);
        }
        else{}
    }

    #if 0
    /*..hui [23-11-29���� 11:27:35] 1�ð� �̻� �̻���..*/
    if( bit_hot_long_not_use_state == SET )
    {
        f32_c = (F32)(f32_c * 1.1f);
    }
    else{}
    #endif

    if( f32_c < 1.0f )
    {
        f32_c = 1.0f;
    }
    else{}

    f32_time = (F32)((F32)gu16_water_out_time / f32_c);

    gu16_cold_mix_time = (U16)f32_time;

    mu16_max_time = gu16_water_out_time;

    if( gu16_cold_mix_time >= mu16_max_time )
    {
        gu16_cold_mix_time = mu16_max_time;
    }
    else{}

    if( gu16_cold_mix_time <= 2 )
    {
        gu16_cold_mix_time = 0;
    }
    else
    {
        /*Hot_Temp_Compensation_time();*/
        if(u8Extract_Continue != SET)
        {
            Hot_Temp_45_Degree_Compensation_time_Hot_Big();
        }
        else{}
    }


////////////////////////////////////////////////////////////////////////////////////////

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_hot_not_use(void)
{
    if( F_WaterOut == SET && u8WaterOutState == HOT_WATER_SELECT )
    {
        bit_hot_long_not_use_state = CLEAR;
        gu16_hot_not_use_timer = 0;
    }
    else
    {
        gu16_hot_not_use_timer++;

        if( gu16_hot_not_use_timer >= HOT_NOT_USE_TIME )
        {
            gu16_hot_not_use_timer = HOT_NOT_USE_TIME;
            bit_hot_long_not_use_state = SET;
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_hot_95_temp_use(void)
{
    /*..hui [24-11-25���� 3:38:06] ������� 1�ܰ迡���� ����..*/
    if( gu8AltitudeStep == ALTITUDE_2_MODE_MID
        || gu8AltitudeStep == ALTITUDE_3_MODE_LOW
        || gu8AltitudeStep == ALTITUDE_4_MODE_VERY_LOW )
    {
        gu8_95_degree_extract_timer = 0;
        bit_95_degree_use_state = CLEAR;
        gu16_95_degree_use_timer = 0;
        return;
    }
    else{}

    if( F_WaterOut == SET && u8WaterOutState == HOT_WATER_SELECT )
    {
        if( gu8_hot_setting_temperature == HOT_SET_TEMP_4__200_oF_95_oC )
        {
            gu8_95_degree_extract_timer++;

            if( gu8_95_degree_extract_timer >= 30 )
            {
                gu8_95_degree_extract_timer = 30;
                bit_95_degree_use_state = SET;
                gu16_95_degree_use_timer = 0;
            }
            else{}
        }
        else /*if( gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )*/
        {
             gu8_95_degree_extract_timer++;

             if( gu8_95_degree_extract_timer >= 30 )
             {
                 gu8_95_degree_extract_timer = 30;
                 bit_95_degree_use_state = CLEAR;
                 gu16_95_degree_use_timer = 0;
             }
             else{}
        }

    }
    else
    {
        if( bit_95_degree_use_state == SET )
        {
            gu16_95_degree_use_timer++;

            /*..hui [24-3-29���� 11:04:25] 2�е��ȸ�..*/
            if( gu16_95_degree_use_timer >= 1600 )
            {
                gu16_95_degree_use_timer = 1600;
                bit_95_degree_use_state = CLEAR;
            }
            else{}
        }
        else
        {
            gu16_95_degree_use_timer = 0;
        }

        gu8_95_degree_extract_timer = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_hot_85_95_temp_use(void)
{
    /*..hui [24-11-25���� 3:38:06] ������� 1,2,3�ܰ迡���� ����..*/
    if( gu8AltitudeStep == ALTITUDE_4_MODE_VERY_LOW )
    {
        gu8_85_95_degree_extract_timer = 0;
        bit_85_95_degree_use_state = CLEAR;
        gu16_85_95_degree_use_timer = 0;
        return;
    }
    else{}


    if( F_WaterOut == SET && u8WaterOutState == HOT_WATER_SELECT )
    {
        if( gu8_hot_setting_temperature == HOT_SET_TEMP_4__200_oF_95_oC
            || gu8_hot_setting_temperature == HOT_SET_TEMP_3__185_oF_85_oC )
        {
            gu8_85_95_degree_extract_timer++;

            if( gu8_85_95_degree_extract_timer >= 30 )
            {
                gu8_85_95_degree_extract_timer = 30;
                bit_85_95_degree_use_state = SET;
                gu16_85_95_degree_use_timer = 0;
            }
            else{}
        }
        else /*if( gu8_hot_setting_temperature == HOT_SET_TEMP_1__110_oF_43_oC )*/
        {
             gu8_85_95_degree_extract_timer++;

             if( gu8_85_95_degree_extract_timer >= 30 )
             {
                 gu8_85_95_degree_extract_timer = 30;
                 bit_85_95_degree_use_state = CLEAR;
                 gu16_85_95_degree_use_timer = 0;
             }
             else{}
        }

    }
    else
    {
        if( bit_85_95_degree_use_state == SET )
        {
            gu16_85_95_degree_use_timer++;

            /*..hui [24-3-29���� 11:04:25] 2�е��ȸ�..*/
            if( gu16_85_95_degree_use_timer >= 1600 )
            {
                gu16_85_95_degree_use_timer = 1600;
                bit_85_95_degree_use_state = CLEAR;
            }
            else{}
        }
        else
        {
            gu16_85_95_degree_use_timer = 0;
        }

        gu8_85_95_degree_extract_timer = 0;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_hot_fast_dec(void)
{
    if( gu8_Hot_Tank_Temperature_One_Degree <= 30
        || gu8_Hot_Tank_Temperature_One_Degree >= 92
        || gu8_hot_temp_before == 0
        || gu8_hot_temp_before_2 == 0 )
    {
        gu8_hot_temp_before = gu8_Hot_Tank_Temperature_One_Degree;
        gu16_hot_fast_dec_timer = 0;
        bit_hot_fast_dec = CLEAR;
        gu8_hot_temp_before_2 = gu8_Hot_Tank_Temperature_One_Degree;
        gu8_hot_dec_clear_cnt = 0;
        gu16_dec_finish_timer = 0;
        return;
    }
    else{}

    gu16_hot_fast_dec_timer++;

    /*if( gu16_hot_fast_dec_timer >= 600 )*/
    /*if( gu16_hot_fast_dec_timer >= 300 )*/
    if( gu16_hot_fast_dec_timer >= 100 )
    {
        gu16_hot_fast_dec_timer = 0;

        /*..hui [24-3-29���� 3:22:51] 1�оȿ� 10�� �̻� ����������..*/
        /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_temp_before - 5 )*/
        if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_temp_before - 3 )
        {
            bit_hot_fast_dec = SET;
            /*gu8_hot_temp_before = gu8_Hot_Tank_Temperature_One_Degree;*/
        }
        else{}

        gu8_hot_temp_before = gu8_Hot_Tank_Temperature_One_Degree;

    }
    else{}


    if( bit_hot_fast_dec == SET )
    {
        if( gu8_Hot_Tank_Temperature_One_Degree != gu8_hot_temp_before_2 )
        {
            if( gu8_Hot_Tank_Temperature_One_Degree > gu8_hot_temp_before_2 )
            {
                gu8_hot_dec_clear_cnt++;
            }
            else{}

            //if( gu8_hot_dec_clear_cnt >= 3 )
            if( gu8_hot_dec_clear_cnt >= 5 )
            {
                bit_hot_fast_dec = CLEAR;
            }
            else{}

            gu8_hot_temp_before_2 = gu8_Hot_Tank_Temperature_One_Degree;
        }
        else{}

        gu16_dec_finish_timer++;

        if( gu16_dec_finish_timer >= 1800 )
        {
            gu8_hot_dec_clear_cnt = 0;
            gu16_dec_finish_timer = 0;
            bit_hot_fast_dec = CLEAR;
        }
        else{}
    }
    else
    {
        gu8_hot_temp_before_2 = gu8_Hot_Tank_Temperature_One_Degree;
        gu8_hot_dec_clear_cnt = 0;
        gu16_dec_finish_timer = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


