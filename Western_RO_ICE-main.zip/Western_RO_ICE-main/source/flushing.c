/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "flushing.h"

void flushing_main(void);
void check_flushing_enable(void);
void flushing_standby(void);
void flushing_control(void);
U8 flushing_proc(void);
void flushing_finish(void);
void calc_flushing_remain_time(void);
void halt_flushing(void);
void flushing_pairing_start(void);
void forced_finish_flushing(void);
/////void check_acid_error(void);
void check_flushing_error(void);
void flushing_tank_control(void);
U8 flushing_tank_proc(void);
void tank_flushing_pump_output(void);
void init_tank_flushing(void);
void calc_flushing_total_time(void);
void halt_tank_flushing(void);
void save_return_step( U8 mu8_step );
void convert_filter_change_type(void);
void change_filter_type(void);

TYPE_BYTE          U8InstallFlushingEnableB;
#define            u8InstallFlushingEnable                 U8InstallFlushingEnableB.byte
#define            Bit0_First_Turn_On_State                U8InstallFlushingEnableB.Bit.b0
#define            Bit1_Filter_Flushing_Ing_State          U8InstallFlushingEnableB.Bit.b1


TYPE_BYTE          U8FlushingStopB;
#define            u8FlushingStop                          U8FlushingStopB.byte
#define            Bit0_Flushing_Error_Stop_State          U8FlushingStopB.Bit.b0
#define            Bit1_Flushing_Cover_Open_Stop_State     U8FlushingStopB.Bit.b1



bit bit_install_flushing_state;


U8 gu8_filter_flushing_state;

FLUSHING_STEP gu8_flushing_mode;
bit bit_flushing_check_finish;
bit bit_flushing_start;
U8 gu8_flushing_step;
U16 gu16_flushing_timer;
U8 gu8_flushing_operation_timer_min;

U8 gu8_display_flushing_reamin_minute;
U8 gu8_display_flushing_elapsed_percent;

U8 gu8_display_flushing_total_percent;

U8 gu8_flushing_okay_key_indicator;
bit bit_flushing_halt;
bit bit_tank_flushing_halt;

bit bit_filter_flushing_no_cancel;


bit bit_flushing_tank_start;
U8 gu8_flushing_tank_step;
U8 gu8_return_flushing_tank_step;


U16 gu16_flushing_tank_timer;
U16 gu16_tank_flushing_max_timer;
U32 gu32_tank_flushing_operation_timer;

bit bit_tank_drain_pump_output;
bit bit_tank_drain_valve_output;
U8 gu8_before_tank_drain_level;
U16 gu16_tank_drain_op_timer;

U8 gu8_tank_drain_no_water_timer;

U16 gu16_tank_drain_finish_timer;

bit bit_ro_drain_finish;


bit bit_install_voice_start;
U8 gu8_install_voice_timer;

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_main(void)
{
    switch( gu8_flushing_mode )
    {
        case FLUSHING_NONE_STATE:

            /*..hui [23-6-2���� 11:08:29] �÷��� ���� ���� Ȯ��..*/
            check_flushing_enable();

        break;

        case FLUSHING_STANDBY_STATE:

            /*..hui [23-6-2���� 11:08:33] �÷��� ���..*/
            flushing_standby();

        break;

        case FLUSHING_MAIN_STATE:

            /*..hui [23-6-2���� 11:08:38] �÷��� ����..*/
            flushing_control();

        break;

        case FLUSHING_TANK_STATE:

            /*..hui [23-8-14���� 4:21:35] �մ� �÷��� �Ϸ� �� ��ũ ������ -> ��� 1ȸ ����..*/
            flushing_tank_control();

        break;

        case FLUSHING_FINISH_STATE:

            /*..hui [23-6-2���� 11:08:42] �÷��� ����..*/
            flushing_finish();

        break;

        default:

            gu8_flushing_mode = FLUSHING_NONE_STATE;
            init_tank_flushing();

        break;
    }

    calc_flushing_total_time();

    gu8_flushing_okay_key_indicator = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_flushing_enable(void)
{
    if( bit_flushing_check_finish == SET )
    {
        /*init_tank_flushing();*/
        return;
    }
    else{}

    if( bit_install_flushing_state == SET )
    {
        gu8_flushing_mode = FLUSHING_STANDBY_STATE;
        gu8_flushing_operation_timer_min = 0;
        gu8_display_flushing_reamin_minute = 30;
        gu8_display_flushing_elapsed_percent = 0;
        gu8_display_flushing_total_percent = 0;
        gu32_tank_flushing_operation_timer = 0;

        /*..hui [21-10-6���� 9:31:55] ���� �÷��� ���� ���� ����OFF -> PBA ��ü?�� ��ġ �÷��� �� ���..*/
        /*..hui [21-10-6���� 9:32:06] ��ġ �÷����� ���� �÷��̺��� �켱�ϵ���..*/
        gu8_filter_flushing_state = FILTER_FLUSHING_NONE;
        /////Bit1_Filter_Flushing_Ing_State = CLEAR;

        /*play_voice_install_guide_75();*/
        /*..hui [23-12-15���� 1:32:25] �ڿ��� ������ �Ϸ�ǰ� ��µǰ� �ϱ�����..*/
        bit_install_voice_start = SET;

        /*..hui [23-12-19���� 3:27:33] ��ġ�÷����ϰ�� ���� ���� ����Ÿ ���� �ʱ�ȭ..*/
        init_filter_data();

        /*..hui [24-2-21���� 4:11:06] CT ���� �÷��� ����..*/
        finish_ct_forced_flushing();
    }
    else
    {
        /////Bit0_First_Turn_On_State = CLEAR;

        /*..hui [21-10-6���� 9:43:12] ���� �÷��� ������°� �ƴѰ��..*/
        if( gu8_filter_flushing_state > FILTER_FLUSHING_NONE )
        {
            gu8_flushing_mode = FLUSHING_STANDBY_STATE;
            gu8_flushing_operation_timer_min = 0;
            gu8_display_flushing_elapsed_percent = 0;
            gu8_display_flushing_total_percent = 0;
            gu32_tank_flushing_operation_timer = 0;
        }
        else
        {
            gu8_flushing_mode = FLUSHING_NONE_STATE;
            gu8_display_flushing_total_percent = 0;
            gu32_tank_flushing_operation_timer = 0;

            /*..hui [24-2-21���� 4:11:06] CT ���� �÷��� ����..*/
            finish_ct_forced_flushing();
        }
    }

    bit_tank_flushing_halt = CLEAR;

    /*..hui [23-8-16���� 3:34:07] �÷��� �ʱ� ro �巹�� 10�ʰ� ����..*/
    bit_ro_drain_finish = CLEAR;
    bit_flushing_check_finish = SET;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_standby(void)
{
    if( gu8_flushing_okay_key_indicator == SET )
    {
        if( bit_filter_all == CLEAR
            || Bit3_Leakage_Sensor_Error__E01 == SET
            || Bit6_Main_Water_Flow_Block_Error__E09 == SET
            || Bit16_Drain_Pump_Error__E60 == SET
            || Bit4_Room_Low_Water_Level_Error__E21 == SET )
        {
            play_melody_warning_197();
        }
        else
        {
            if( bit_tank_flushing_halt == SET )
            {
                gu8_flushing_mode = FLUSHING_TANK_STATE;
                /*..hui [23-8-22���� 10:12:26] ������ �Ͻ������ƴ� �������� �̵�..*/
                gu8_flushing_tank_step = gu8_return_flushing_tank_step;
            }
            else
            {
                gu8_flushing_mode = FLUSHING_MAIN_STATE;
            }

            bit_tank_flushing_halt = CLEAR;

            gu8_flushing_step = 0;
            bit_flushing_halt = CLEAR;
            /*play_melody_setting_on_198();*/
            play_voice_filter_flushing_start_23();


            /*..hui [24-1-17���� 4:55:43] yes, no �˾� �� ���¿��� ���� ��ư ���� ��쿡��....*/
            /*..hui [24-1-17���� 4:55:52] RO ��ü�ص� ��� �����ϵ��� �ٲ�..*/
            if( bit_yes_no_popup == SET )
            {
                bit_yes_no_popup = CLEAR;
                bit_filter_reset_yes = SET;
                bit_filter_reset_no = CLEAR;
            }
            else{}
        }

        /*..hui [23-12-15���� 1:34:47] �����ư�� �ѹ� ���� �Ŀ��� ��¾���..*/
        bit_install_voice_start = CLEAR;
    }
    else
    {
        if( bit_install_voice_start == SET )
        {
            gu8_install_voice_timer++;

            if( gu8_install_voice_timer >= 70 )
            {
                play_voice_install_guide_75();
                gu8_install_voice_timer = 0;
                bit_install_voice_start = CLEAR;
            }
            else{}
        }
        else{}
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_control(void)
{
    U8 mu8_finish = 0;

    check_flushing_error();

    if( u8FlushingStop == CLEAR )
    {
        if( bit_flushing_start == CLEAR )
        {
            bit_flushing_start = SET;
        }
        else{}
    }
    else
    {
        if( bit_flushing_start == SET )
        {
            halt_flushing();
            /*gu8_flushing_okay_key_indicator = SET;*/
        }
        else{}
    }

    if( bit_flushing_start == SET )
    {
        mu8_finish = flushing_proc();

        if( mu8_finish == SET )
        {
            init_tank_flushing();

            /*..hui [23-8-21���� 11:11:16] ��ũ 1ȸ ä�� ������ ��ġ �÷��̶���..*/
            if( bit_install_flushing_state == SET )
            {
                gu8_flushing_mode = FLUSHING_TANK_STATE;
            }
            else
            {
                gu8_flushing_mode = FLUSHING_FINISH_STATE;
            }

            bit_flushing_start = CLEAR;
        }
        else{}
    }
    else
    {
        gu8_flushing_step = 0;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 flushing_proc(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_ble_ap_mode = 0;
    U8 mu8_time = 0;

    switch( gu8_flushing_step )
    {
        case 0:

            /*..hui [23-8-23���� 3:20:00] ���� �÷��� ���̾����� ���������� ���..*/
            if( bit_flushing_water_start == CLEAR )
            {
                /*gu16_flushing_timer = 0;*/
                /*gu8_flushing_step++;*/

                gu16_flushing_timer++;

                /*..hui [23-12-15���� 1:45:02] ���� �÷����� �����մϴ�~ ���� ������ �����ϱ�����....*/
                /*..hui [23-12-15���� 1:45:10] �������� ������ �ڵ�����~ �����̶� ��ħ....*/
                /*if( gu16_flushing_timer >= 50 )*/
                /*..hui [24-1-10���� 2:15:51] �������� ������ �ڵ�����~ ���� ��� ����..*/
                /*if( gu16_flushing_timer >= 10 )*/
                if( gu16_flushing_timer >= 50 )
                {
                    gu16_flushing_timer = 0;
                    gu8_flushing_step++;
                }
                else{}
            }
            else
            {
                gu16_flushing_timer++;

                if( gu16_flushing_timer >= 1800 )
                {
                    gu16_flushing_timer = 0;
                    gu8_flushing_step++;
                }
                else{}
            }

            break;

        case 1:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:32:54] �÷��� ������ȯ ��� ON..*/
            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                /*..hui [23-6-14���� 11:24:50] �� ����..*/
                flushing_pairing_start();
                gu16_flushing_timer = 0;

                /*..hui [23-8-16���� 3:32:02] ro �巹�� 10�� �Ϸ��ϰ� �߰��� ��ҵǸ� �ٽ� ����..*/
                if( bit_ro_drain_finish == SET )
                {
                    gu8_flushing_step = 7;
                }
                else
                {
                    gu8_flushing_step++;
                }
            }
            else{}

            break;

        case 2:

            gu16_flushing_timer++;

            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;

                /*..hui [23-6-14���� 7:33:43] RO �÷��� ��ũ ���� OPEN..*/
                run_open_ro_drain();
            }
            else{}

            break;

        case 3:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� OPEN �Ϸ�Ǹ�..*/
            #if 0
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_OPEN )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}
            #endif

            if( gu8_ro_drain_status == RO_DRAIN_STATUS_OPEN )
            {
                gu16_flushing_timer++;

                /*..hui [23-11-1���� 1:55:11] ������ �� ä��� �ð� ���� ..*/
                /*if( gu16_flushing_timer >= 100 )*/
                /*..hui [24-1-11���� 10:31:22] �ǵ��� �������� ������.. 30�ʸ� ���� ��ä��½ð� ����ҵ�....*/
                if( gu16_flushing_timer >= 10 )
                {
                    gu16_flushing_timer = 0;
                    gu8_flushing_step++;
                }
                else{}
            }
            else{}

            break;

        case 4:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:33:19] �ǵ��� ON..*/
            /*..hui [23-8-16���� 3:12:14] 10�� ���� ����..*/
            /*..hui [23-8-18���� 2:53:51] 10�� �Ϸ� �� �ǵ��� OFF..*/
            /*if( gu16_flushing_timer >= 100 )*/
            /*..hui [23-9-21���� 2:00:13] 30�ʷ� ����.. ������ ����..ro ct�� ���� ����.. ����� ����..*/
            /*..hui [23-9-21���� 2:00:23] �� �ð����� ���� �ܼ� �����ϴ°ɷ� ���� ���濹��..*/
            if( gu16_flushing_timer >= RO_DRAIN_FLUSHING_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 5:

            gu16_flushing_timer++;

            /*if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )*/
            if( gu16_flushing_timer >= 20 )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;

                /*..hui [23-8-16���� 3:12:54] �ǵ��� �ݰ� ro �巹�� ��� ����..*/
                run_close_ro_drain();
                /*..hui [23-8-16���� 3:32:29] ro �巹�� �Ϸ�..*/
                bit_ro_drain_finish = SET;
            }
            else{}

            break;

        case 6:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� CLOSE �Ϸ�Ǹ�..*/
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_CLOSE )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 7:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:33:19] �ǵ��� ON..*/
            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
                bit_flushing_halt = CLEAR;
            }
            else{}

            break;

        case 8:

            gu16_flushing_timer++;

            if( gu16_flushing_timer >= 600 )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_operation_timer_min++;
            }
            else{}

            if( bit_install_flushing_state == SET )
            {
                mu8_time = INSTALL_FLUSHING_TIME;
            }
            else
            {
                if( gu8_filter_flushing_state == FILTER_FLUSHING_RO )
                {
                    mu8_time = INSTALL_FLUSHING_TIME;
                }
                else
                {
                    mu8_time = NEO_INO_REPLACE_FLUSHING_TIME;
                }
            }

            /*..hui [23-6-1���� 7:33:54] 30�� ���..*/
            /*if( gu8_flushing_operation_timer_min >= INSTALL_FLUSHING_TIME )*/
            if( gu8_flushing_operation_timer_min >= mu8_time )
            {
                gu16_flushing_timer = 0;
                //gu8_flushing_operation_timer_min = 0;
                gu8_flushing_step++;
            }
            else
            {
                if( gu8_flushing_okay_key_indicator == SET )
                {
                    /*halt_flushing();*/
                    gu16_flushing_timer = 0;
                    gu8_flushing_step++;
                    bit_flushing_halt = SET;

                    /*..hui [23-6-14���� 1:06:11] ������ Ŀ�� ������ �������� ������ �ȳ�������..*/
                    if( u8FlushingStop == CLEAR )
                    {
                        play_melody_setting_off_199();
                    }
                    else{}
                }
                else{}
            }

            /*..hui [23-8-18���� 3:21:14] �ۼ�Ʈ�� ǥ�÷� �ٲ����� �켱 ���ܳ���.. ȣ���� �ϴµ� ǥ���Ҷ� �Ⱦ��°ɷ�..*/
            /*calc_flushing_remain_time();*/

            break;

        case 9:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:34:21] �ǵ� ��� OFF..*/
            /*if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )*/
            /*..hui [23-8-18���� 3:03:38] OFF�ϰ� 2�� ���..*/
            if( gu16_flushing_timer >= 20 )
            {
                gu16_flushing_timer = 0;

                if( bit_flushing_halt == CLEAR )
                {
                    gu8_flushing_step++;
                }
                else
                {
                    gu8_flushing_step = 15;
                }
            }
            else{}

            break;

        case 10:

            gu16_flushing_timer++;

            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;

                /*..hui [23-6-14���� 7:33:43] RO �÷��� ��ũ ���� OPEN..*/
                run_open_ro_drain();
            }
            else{}


            break;

        case 11:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� OPEN �Ϸ�Ǹ�..*/
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_OPEN )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 12:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:33:19] �ǵ��� ON..*/
            /*..hui [23-8-16���� 3:12:14] 10�� ���� ����..*/
            /*..hui [23-8-18���� 2:53:51] 10�� �Ϸ� �� �ǵ��� OFF..*/
            /*if( gu16_flushing_timer >= 100 )*/
            /*..hui [23-9-21���� 2:00:13] 30�ʷ� ����.. ������ ����..ro ct�� ���� ����.. ����� ����..*/
            /*..hui [23-9-21���� 2:00:23] �� �ð����� ���� �ܼ� �����ϴ°ɷ� ���� ���濹��..*/
            if( gu16_flushing_timer >= RO_DRAIN_FLUSHING_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 13:

            gu16_flushing_timer++;

            if( gu16_flushing_timer >= 20 )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;

                /*..hui [23-8-16���� 3:12:54] �ǵ��� �ݰ� ro �巹�� ��� ����..*/
                run_close_ro_drain();
            }
            else{}

            break;

        case 14:

            /*..hui [23-6-14���� 7:37:24] RO �巹�� ���� CLOSE �Ϸ�Ǹ�..*/
            if( gu8_ro_drain_status == RO_DRAIN_STATUS_CLOSE )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 15:

            gu16_flushing_timer++;

            /*..hui [23-9-22���� 1:29:44] �÷��� NOS ��� ����..*/
            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 16:

            gu16_flushing_timer++;

            /*..hui [23-6-1���� 7:34:41] �÷��� ������ȯ �ǵ� ��� OFF..*/
            if( gu16_flushing_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_timer = 0;
                gu8_flushing_step++;
            }
            else{}

            break;

        case 17:

            gu8_flushing_step = 0;
            gu16_flushing_timer = 0;

            if( bit_flushing_halt == SET )
            {
                halt_flushing();
            }
            else
            {
                /*..hui [21-5-28���� 4:50:52]   �÷��� ����..*/
                mu8_return = SET;
            }

            break;


        default:

            gu8_flushing_step = 0;
            gu16_flushing_timer = 0;
            gu8_flushing_operation_timer_min = 0;

        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_finish(void)
{
    /*..hui [23-12-18���� 7:04:18] �÷��� �� ��뷮 ���..*/
    calc_flushing_water();

    convert_filter_change_type();

    bit_install_flushing_state = CLEAR;
    ////////u8FilterResetState = FILTER_NO_CHANGE;
    gu8_filter_flushing_state = FILTER_FLUSHING_NONE;

    gu8_flushing_mode = FLUSHING_NONE_STATE;
    gu8_flushing_operation_timer_min = 0;

    init_tank_flushing();

    /*..hui [23-8-16���� 3:35:12] ������ �ٽ� �÷��� �ϰԵɶ� ro �巹�κ��� �ϱ�����..*/
    bit_ro_drain_finish = CLEAR;

    /*..hui [23-12-15���� 1:24:51] ���� �÷����� �Ϸ�Ǿ� ��ǰ ����� �����մϴ�...*/
    play_voice_filter_flushing_finish_24();

    /*..hui [24-1-11���� 10:43:17] ��ġ �÷��� �Ϸ� -> �ٷ� �����÷��� ����.. 100%���� ������..*/
    gu8_display_flushing_total_percent = 0;

    /*..hui [24-1-18���� 9:14:00] ���� ���� ���µ� �ʱ�ȭ..*/
    u8FilterResetState = FILTER_NO_CHANGE;

    /*..hui [24-2-21���� 4:11:06] CT ���� �÷��� ����..*/
    finish_ct_forced_flushing();

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_flushing_remain_time(void)
{
    U8 mu8_time = 0;
    U8 mu8_percent = 0;

    #if 0
    if( bit_install_flushing_state == SET )
    {
        mu8_time = (U8)(INSTALL_FLUSHING_TIME - gu8_flushing_operation_timer_min);
        mu8_percent = (U8)((U8)(gu8_flushing_operation_timer_min / 3) * 10);

        gu8_display_flushing_reamin_minute = mu8_time;
        gu8_display_flushing_elapsed_percent = mu8_percent;
    }
    else
    {
        /*if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_INO )*/
        if( gu8_filter_flushing_state == FILTER_FLUSHING_NEO_INO )
        {
            mu8_time = (U8)(NEO_INO_REPLACE_FLUSHING_TIME - gu8_flushing_operation_timer_min);

            if( mu8_time == 2 )
            {
                mu8_percent = 0;
            }
            else if( mu8_time == 1 )
            {
                mu8_percent = 50;
            }
            else
            {
                mu8_percent = 100;
            }

            gu8_display_flushing_reamin_minute = mu8_time;
            gu8_display_flushing_elapsed_percent = mu8_percent;
        }
        else
        {
            mu8_time = (U8)(INSTALL_FLUSHING_TIME - gu8_flushing_operation_timer_min);
            mu8_percent = (U8)((U8)(gu8_flushing_operation_timer_min / 3) * 10);

            gu8_display_flushing_reamin_minute = mu8_time;
            gu8_display_flushing_elapsed_percent = mu8_percent;
        }
    }
    #endif
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void halt_flushing(void)
{
    bit_flushing_start = CLEAR;
    gu8_flushing_step = 0;
    gu16_flushing_timer = 0;
    bit_flushing_halt = CLEAR;

    gu8_flushing_mode = FLUSHING_STANDBY_STATE;

    /*..hui [23-6-8���� 5:03:08] �����÷��� -> ���� -> �ߴ������� �ü� ��ư OFF.. ��Ҿȵ�..*/
    ///////bit_filter_flushing_no_cancel = SET;

    /*..hui [24-1-5���� 4:06:20] Ŀ�� ���½ÿ��� �ʱ�ȭ.. ���� �߰� ��ü������������..?..*/
    if( Bit3_Leakage_Sensor_Error__E01 == SET
        || Bit6_Main_Water_Flow_Block_Error__E09 == SET
        || Bit16_Drain_Pump_Error__E60 == SET
        || Bit4_Room_Low_Water_Level_Error__E21 == SET
        || Bit1_Flushing_Cover_Open_Stop_State == SET )
    {
        gu8_flushing_operation_timer_min = 0;

        /*..hui [23-8-21���� 4:17:55] ǥ�� ������� �ʱ�ȭ..*/
        gu8_display_flushing_total_percent = 0;

        /*..hui [23-8-21���� 4:23:05] �ܼ��� ro �巹�ε� ����� �ȵ����״� �ٽ�..*/
        if( Bit6_Main_Water_Flow_Block_Error__E09 == SET )
        {
            bit_ro_drain_finish = CLEAR;
        }
        else{}
    }
    else{}

    bit_flushing_tank_start = CLEAR;
    gu8_flushing_tank_step = 0;
    gu16_flushing_tank_timer = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void halt_tank_flushing(void)
{
    bit_flushing_tank_start = CLEAR;
    gu8_flushing_tank_step = 0;
    gu16_flushing_tank_timer = 0;
    /*bit_tank_flushing_halt = CLEAR;*/

    gu8_flushing_mode = FLUSHING_STANDBY_STATE;

    if( Bit3_Leakage_Sensor_Error__E01 == SET
        || Bit6_Main_Water_Flow_Block_Error__E09 == SET
        || Bit16_Drain_Pump_Error__E60 == SET
        || Bit4_Room_Low_Water_Level_Error__E21 == SET )
    {
        gu8_flushing_operation_timer_min = 0;

        /*..hui [23-8-21���� 4:17:55] ǥ�� ������� �ʱ�ȭ..*/
        gu8_display_flushing_total_percent = 0;

        /*..hui [23-8-23���� 2:45:13] ���� �ɸ��� �ƿ� ó������ �ٽ�..*/
        gu8_return_flushing_tank_step = 0;
        bit_tank_flushing_halt = CLEAR;
        gu32_tank_flushing_operation_timer = 0;

        /*..hui [23-8-21���� 4:23:05] �ܼ��� ro �巹�ε� ����� �ȵ����״� �ٽ�..*/
        if( Bit6_Main_Water_Flow_Block_Error__E09 == SET )
        {
            bit_ro_drain_finish = CLEAR;
        }
        else{}
    }
    else{}

    init_tank_flushing();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_pairing_start(void)
{
    U8 mu8_ble_ap_mode = 0;

    /*..hui [21-8-10���� 9:04:14] ���� �÷��� �ʱ�ȭ ��� ��� �߰���..*/
    /*..hui [21-8-10���� 9:04:33] ����ߴٰ� �ٽ� �����ϸ� ���� �������ϱ� Ȯ�� �Ŀ�~~..*/
    mu8_ble_ap_mode  = GetWifiStatusValue( WIFI_STATUS_AP_BLE );


    if( bit_install_flushing_state == SET
        && mu8_ble_ap_mode == CLEAR
        && gu8_wifi_ap_first_temporary == CLEAR )
    {
        WifiKey(WIFI_KEY_BLE);

        /*..hui [24-1-10���� 2:13:36] �ڵ����� �����մϴ� ���� ��� ����..*/
        /*play_voice_pairing_auto_start_76();*/
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void forced_finish_flushing(void)
{
    if( gu8_flushing_mode > FLUSHING_NONE_STATE )
    {
        /*bit_install_flushing_state = CLEAR;*/
        /*gu8_filter_flushing_state = FILTER_FLUSHING_NONE;*/

        /*..hui [24-1-19���� 3:33:18] �ü� 3ȸ ������쿡�� �ƿ� ���..*/
        if( gu8_flushing_finish_input_count == 3 )
        {
            bit_install_flushing_state = CLEAR;
            gu8_filter_flushing_state = FILTER_FLUSHING_NONE;
        }
        else{}

        gu8_flushing_mode = FLUSHING_NONE_STATE;
        gu8_flushing_operation_timer_min = 0;
        /*play_melody_setting_on_198();*/
        play_voice_test_mode_151();
    }
    else
    {
        play_melody_warning_197();
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void check_flushing_error(void)
{
    if( Bit3_Leakage_Sensor_Error__E01 == SET
        || Bit6_Main_Water_Flow_Block_Error__E09 == SET
        || Bit16_Drain_Pump_Error__E60 == SET
        || Bit4_Room_Low_Water_Level_Error__E21 == SET )
    {
        Bit0_Flushing_Error_Stop_State = SET;
    }
    else
    {
        Bit0_Flushing_Error_Stop_State = CLEAR;
    }

    /*if( bit_filter_cover == CLEAR || bit_ro_filter_2_reed == CLEAR )*/
    if( bit_filter_all == CLEAR )
    {
        Bit1_Flushing_Cover_Open_Stop_State = SET;
    }
    else
    {
        Bit1_Flushing_Cover_Open_Stop_State = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void flushing_tank_control(void)
{
    U8 mu8_finish = 0;

    check_flushing_error();

    if( u8FlushingStop == CLEAR )
    {
        if( bit_flushing_tank_start == CLEAR )
        {
            bit_flushing_tank_start = SET;
        }
        else{}
    }
    else
    {
        if( bit_flushing_tank_start == SET )
        {
            halt_tank_flushing();
        }
        else{}
    }

    if( bit_flushing_tank_start == SET )
    {
        mu8_finish = flushing_tank_proc();

        if( mu8_finish == SET )
        {
            gu8_flushing_mode = FLUSHING_FINISH_STATE;
            bit_flushing_tank_start = CLEAR;
        }
        else{}
    }
    else
    {
        gu8_flushing_tank_step = 0;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 flushing_tank_proc(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_ble_ap_mode = 0;
    U8 mu8_time = 0;

    /*..hui [23-8-23���� 10:38:44] �򰥷��� �������� �̵�..*/
    /*..hui [23-8-23���� 10:38:54] ��ũ �÷����� ��� �ܰ迡�� ��� �����ϵ��� ����..*/
    if( gu8_flushing_okay_key_indicator == SET )
    {
        if( gu8_flushing_tank_step <= 2 )
        {
            save_return_step(0);
        }
        else if( gu8_flushing_tank_step == 3 )
        {
            save_return_step(3);
        }
        else if( gu8_flushing_tank_step == 4 || gu8_flushing_tank_step == 5 )
        {
            save_return_step(4);
        }
        else if( gu8_flushing_tank_step == 6 || gu8_flushing_tank_step == 7 )
        {
            save_return_step(6);
        }
        else if( gu8_flushing_tank_step == 8 || gu8_flushing_tank_step == 9 || gu8_flushing_tank_step == 10 )
        {
            save_return_step(8);
        }
        else{}

        gu16_flushing_tank_timer = 0;
        gu8_flushing_tank_step = 12;
        bit_tank_flushing_halt = SET;

        /*..hui [23-6-14���� 1:06:11] ������ Ŀ�� ������ �������� ������ �ȳ�������..*/
        if( u8FlushingStop == CLEAR )
        {
            play_melody_setting_off_199();
        }
        else{}
    }
    else{}

    switch( gu8_flushing_tank_step )
    {
        case 0:

            gu16_flushing_tank_timer = 0;
            gu8_flushing_tank_step++;

            break;

        case 1:

            gu16_flushing_tank_timer++;

            /*..hui [23-8-14���� 4:34:13] �ǵ��� ON..*/
            if( gu16_flushing_tank_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-8-14���� 4:35:57] ���������� ���� �� ���� �ܰ�� �̵�..*/
            /*..hui [23-8-23���� 9:14:28] ���� �������� ��쿡��..*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_MID || gu8_Room_Water_Level == ROOM_LEVEL_FULL )
            {
                gu16_flushing_tank_timer++;

                /*..hui [23-8-23���� 9:18:57] ���������� �����ϴ� ���.. �ּ� 5�ʰ� ������ ���� �ܰ��..*/
                if( gu16_flushing_tank_timer >= 60 )
                {
                    gu16_flushing_tank_timer = 0;
                    gu32_tank_flushing_operation_timer = 0;
                    gu8_flushing_tank_step++;
                }
                else
                {
                    /*..hui [23-8-23���� 9:40:34] �߼���, ������ ���� ���¿��� �������� ���..*/
                    /*..hui [23-8-23���� 9:40:47] 3�ʵ��� 50% ǥ��, ���� 3�ʵ��� 60% ǥ��..*/
                    if( gu32_tank_flushing_operation_timer == 0 )
                    {
                        if( gu16_flushing_tank_timer >= 30 )
                        {
                            gu32_tank_flushing_operation_timer = 6001;
                        }
                        else{}
                    }
                    else{}
                }
            }
            else
            {
                /*..hui [23-8-14���� 4:36:05] �ִ� �ð� ���� �߰�..*/
                gu32_tank_flushing_operation_timer++;

                /*..hui [23-9-22���� 1:43:57] ���� �߰��ϸ鼭 ������������ �¼� ä��� �ð��� �ֱ� ������ �ִ�ð� 1�ð� 30������..*/
                /*..hui [23-11-13���� 3:36:46] ���������� 2�ð�30��.. ����ȯ�����.. �������..*/
                /*..hui [23-11-13���� 3:37:04] ������ - ������������ 2�ð�..*/
                if( gu32_tank_flushing_operation_timer >= FLUSHING_LOW_WATER_MAX_TIME )
                {
                    gu16_flushing_tank_timer = 0;
                    gu32_tank_flushing_operation_timer = 0;
                    gu8_flushing_tank_step++;

                    Bit6_Main_Water_Flow_Block_Error__E09 = SET;
                }
                else{}
            }

            break;

        case 3:

            if( gu8_Room_Water_Level == ROOM_LEVEL_FULL )
            {
                gu16_flushing_tank_timer++;

                /*..hui [23-8-23���� 9:18:57] ���������� �����ϴ� ���.. �ּ� 5�ʰ� ������ ���� �ܰ��..*/
                if( gu16_flushing_tank_timer >= 30 )
                {
                    gu16_flushing_tank_timer = 0;
                    gu32_tank_flushing_operation_timer = 0;
                    gu8_flushing_tank_step++;
                }
                else{}
            }
            else
            {
                /*..hui [23-8-14���� 4:36:05] �ִ� �ð� ���� �߰�..*/
                gu32_tank_flushing_operation_timer++;

                /*..hui [23-9-22���� 1:44:16] ���������� �������� 1�ð�����..*/
                if( gu32_tank_flushing_operation_timer >= FLUSHING_HIGH_WATER_MAX_TIME )
                {
                    gu16_flushing_tank_timer = 0;
                    gu32_tank_flushing_operation_timer = 0;
                    gu8_flushing_tank_step++;

                    Bit6_Main_Water_Flow_Block_Error__E09 = SET;
                }
                else{}
            }

            break;

        case 4:

            if( gu8_ice_system_ok == SET )
            {
                /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                up_tray_motor();
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else
            {
                /*..hui [23-8-24���� 2:28:45] Ʈ���� �����̰ų� ��õ��߿��� �׳� �����뿡 ����..*/
                /*..hui [23-8-24���� 2:30:43] �׳� ���� �巹������ ����ϴ°ɷ�..*/
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step = 10;
            }

            break;

        case 5:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else
            {
                gu16_tank_flushing_max_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_tank_flushing_max_timer >= 600 )
                {
                    gu16_flushing_tank_timer = 0;
                    gu16_tank_flushing_max_timer = 0;
                    gu8_flushing_tank_step++;
                }
                else{}
            }

            break;

        case 6:

            gu16_flushing_tank_timer++;

            /*..hui [23-8-16���� 1:13:02] Ʈ���� �Լ� ��� ON..*/
            if( gu16_flushing_tank_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu32_tank_flushing_operation_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 7:

            gu32_tank_flushing_operation_timer++;

            /*..hui [23-8-16���� 1:13:21] Ʈ���� �Լ� ���� ON..*/
            /*..hui [23-8-16���� 1:14:17] 1�е��� �־��ش�..*/
            if( gu32_tank_flushing_operation_timer >= ICE_TRAY_FLUSHING_TIME )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu32_tank_flushing_operation_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 8:

            gu16_flushing_tank_timer++;

            /*..hui [23-8-16���� 1:15:43] Ʈ���� �Լ� ���� OFF..*/
            if( gu16_flushing_tank_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 9:

            gu16_flushing_tank_timer++;

            /*..hui [23-8-16���� 1:16:03] Ʈ���� �Լ� ��� OFF..*/
            if( gu16_flushing_tank_timer >= FLUSHING_DELAY_TIME )
            {
                /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
                down_tray_motor();

                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 10:

            gu32_tank_flushing_operation_timer++;

            /*..hui [23-8-14���� 4:42:57] �÷��� ��� �ִ� �ð��� �켱 30��..*/
            /*..hui [23-8-16���� 1:16:30] ���� �� ���..*/
            if(gu32_tank_flushing_operation_timer >= FLUSHING_TANK_MAX_TIME)
            {
                gu16_flushing_tank_timer = 0;
                gu32_tank_flushing_operation_timer = 0;
                gu8_flushing_tank_step++;

                /*..hui [24-5-27���� 5:28:25] �������� �巹�ι�갡 ��� ������..*/
                init_tank_flushing();
            }
            else
            {
                tank_flushing_pump_output();
            }

            break;

        case 11:

            gu16_flushing_tank_timer++;

            if( gu16_flushing_tank_timer >= FLUSHING_DELAY_TIME )
            {
                gu16_flushing_tank_timer = 0;
                gu16_tank_flushing_max_timer = 0;
                gu8_flushing_tank_step++;
            }
            else{}

            break;

        case 12:

            gu8_flushing_tank_step = 0;
            gu16_flushing_tank_timer = 0;
            gu16_tank_flushing_max_timer = 0;

            if( bit_tank_flushing_halt == SET )
            {
                halt_tank_flushing();
            }
            else
            {
                /*..hui [21-5-28���� 4:50:52]   �÷��� ����..*/
                mu8_return = SET;
            }

            /*..hui [21-5-28���� 4:50:52]   �÷��� ����..*/
            /*mu8_return = SET;*/

            break;


        default:

            gu8_flushing_tank_step = 0;
            gu16_flushing_tank_timer = 0;
            gu16_tank_flushing_max_timer = 0;

        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void tank_flushing_pump_output(void)
{
    /*..hui [23-8-14���� 4:17:30] �巹�� �ð� - ���������� ����..*/
    /* 600
       710
       757
       780
       775
       930
       930 */

    switch(u8DrainWaterLevel)
    {
        case DRAIN_LEVEL_EMPTY :

             bit_tank_drain_pump_output = CLEAR;
             bit_tank_drain_valve_output = SET;

             gu8_before_tank_drain_level = DRAIN_LEVEL_EMPTY;
             gu16_tank_drain_op_timer = 0;
             gu8_tank_drain_no_water_timer = 0;

             /*..hui [23-8-14���� 2:04:53] �ü���ũ ������ �̰��� ���Ͽ����� Ȯ���ϵ���..*/
             if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
             {
                 gu16_tank_drain_finish_timer++;

                 /*..hui [23-8-14���� 1:37:19] x�е��� �巹�ι�� �����µ� ������ �̻� ���� �ȵǸ� ����..*/
                 if( gu16_tank_drain_finish_timer >= MANUAL_DRAIN_FINISH_CHECK_TIME )
                 {
                     gu16_tank_drain_finish_timer = 0;
                     /*gu16_tank_flushing_max_timer = FLUSHING_TANK_MAX_TIME;*/
                     gu32_tank_flushing_operation_timer = FLUSHING_TANK_MAX_TIME;
                 }
                 else{}
             }
             else
             {
                 gu16_tank_drain_finish_timer = 0;
             }

            break;

        case DRAIN_LEVEL_LOW :

             gu16_tank_drain_finish_timer = 0;

             /*..hui [18-1-14���� 6:06:23] ������ ���¿��� �ü� ������ ON ���·� ������ �����ϸ�..*/
             if(gu8_before_tank_drain_level == DRAIN_LEVEL_EMPTY)
             {
                 gu16_tank_drain_op_timer++;

                 /*..hui [18-1-14���� 6:06:47] 40�� �̻� �ü� ����ߴµ��� �������� �������� ���ϸ�..*/
                 /*..hui [18-1-14���� 6:07:00] �ٽ� �巹������ �����ؼ� �巹�� ����..*/
                 /*..hui [18-1-14���� 6:11:06] ���� ������, ���θ������� ������.. �����ũ ��ġ�� �ʰ� �ϱ�����..???..*/
                 if(gu16_tank_drain_op_timer >= DRAIN_VALVE_OPEN_TIME)
                 {
                     bit_tank_drain_pump_output = SET;
                     bit_tank_drain_valve_output = CLEAR;

                     /*..hui [18-1-25���� 4:11:59] �巹������ �������� ��ȯ�ϰ� 3���Ŀ� �ǵ�� Ȯ��..*/
                     if(gu16_tank_drain_op_timer >= DRAIN_VALVE_OPEN_TIME + 30)
                     {
                         /*..hui [18-1-25���� 4:12:27] �ǵ�� �����̸� �ٽ� �ü� ��� ON..*/
                         if(gu16_AD_Drain_Pump_Current <= DRAIN_COMPLETE_FEEDBACK)
                         {
                             gu16_tank_drain_op_timer = 0;
                         }
                         else
                         {
                             /*..hui [18-1-25���� 4:12:45] �ǵ�� �ʰ��̸� �巹������ ON ���� ����..*/
                             gu16_tank_drain_op_timer = DRAIN_VALVE_OPEN_TIME + 30;
                         }
                     }
                     else{}
                 }
                 else
                 {
                     bit_tank_drain_pump_output = CLEAR;
                     bit_tank_drain_valve_output = SET;
                 }
             }
             else
             {
                 gu16_tank_drain_op_timer = 0;
                 /*..hui [18-1-14���� 6:15:33] ������ �����ǰ� �巹������ �����Ͽ� ���������� ����������..*/
                 /*..hui [18-1-14���� 6:21:04] �̰͵� ���� �������� ���� ������� ������ ���������� �� �ȳ�������..*/
                 /*..hui [18-1-14���� 6:21:55] �ٽ� �巹������ OFF�ϰ� �ü� ��� ON�Ͽ� �������� ������....*/
                 if( gu16_AD_Drain_Pump_Current <= DRAIN_COMPLETE_FEEDBACK )
                 {
                     gu8_tank_drain_no_water_timer++;

                     if( gu8_tank_drain_no_water_timer >= 100 )
                     {
                         gu8_tank_drain_no_water_timer = 100;
                         bit_tank_drain_pump_output = CLEAR;
                         bit_tank_drain_valve_output = SET;
                     }
                     else
                     {
                         bit_tank_drain_pump_output = SET;
                         bit_tank_drain_valve_output = CLEAR;
                     }
                 }
                 else
                 {
                     gu8_tank_drain_no_water_timer = 0;
                     bit_tank_drain_pump_output = SET;
                     bit_tank_drain_valve_output = CLEAR;
                 }
             }

            break;

        case DRAIN_LEVEL_ERROR :
        case DRAIN_LEVEL_HIGH :

             bit_tank_drain_pump_output = SET;
             bit_tank_drain_valve_output = CLEAR;
             gu8_before_tank_drain_level = DRAIN_LEVEL_HIGH;
             gu8_tank_drain_no_water_timer = 0;

            break;

        //=====================================================
        default :

             bit_tank_drain_pump_output = CLEAR;
             bit_tank_drain_valve_output = CLEAR;
             gu8_before_tank_drain_level = DRAIN_LEVEL_EMPTY;

            break;
      }
}




/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_tank_flushing(void)
{
    /////gu16_tank_flushing_max_timer = 0;
    bit_tank_drain_pump_output = CLEAR;
    bit_tank_drain_valve_output = CLEAR;
    gu8_before_tank_drain_level = DRAIN_LEVEL_EMPTY;
    gu16_tank_drain_op_timer = 0;
    gu16_tank_drain_finish_timer = 0;
    gu8_tank_drain_no_water_timer = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void calc_flushing_total_time(void)
{
    U8 mu8_time = 0;
    U8 mu8_percent = 0;

    if( gu8_flushing_mode == FLUSHING_NONE_STATE )
    {
        return;
    }
    else{}

    if( gu8_flushing_mode == FLUSHING_STANDBY_STATE )
    {
        return;
    }
    else{}

    if( bit_flushing_halt == SET )
    {
        return;
    }
    else{}

    if( bit_tank_flushing_halt == SET )
    {
        return;
    }
    else{}

    if( bit_install_flushing_state == SET )
    {
        /*..hui [23-12-12���� 11:27:26] ��ġ�÷���..RO ���� �÷���..*/
        if( gu8_flushing_mode == FLUSHING_MAIN_STATE )
        {
            if( gu8_flushing_step <= 7 )
            {
                if( gu8_display_flushing_total_percent < 10 )
                {
                    gu8_display_flushing_total_percent = 0;
                }
                else{}
            }
            else if( gu8_flushing_step == 8 )
            {
                if( gu8_flushing_operation_timer_min <= 3 )
                {
                    if( gu8_display_flushing_total_percent < 10 )
                    {
                        gu8_display_flushing_total_percent = 0;
                    }
                    else{}
                }
                else if( gu8_flushing_operation_timer_min <= 10 )
                {
                    if( gu8_display_flushing_total_percent < 10 )
                    {
                        gu8_display_flushing_total_percent = 10;
                    }
                    else{}
                }
                else if( gu8_flushing_operation_timer_min <= 17 )
                {
                    if( gu8_display_flushing_total_percent < 20 )
                    {
                        gu8_display_flushing_total_percent = 20;
                    }
                    else{}
                }
                else if( gu8_flushing_operation_timer_min <= 24 )
                {
                    if( gu8_display_flushing_total_percent < 30 )
                    {
                        gu8_display_flushing_total_percent = 30;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 40 )
                    {
                        gu8_display_flushing_total_percent = 40;
                    }
                    else{}
                }
            }
            else if( gu8_flushing_step >= 9 )
            {
                if( gu8_display_flushing_total_percent < 40 )
                {
                    gu8_display_flushing_total_percent = 40;
                }
                else{}
            }
        }
        else if( gu8_flushing_mode == FLUSHING_TANK_STATE )
        {
            if( gu8_flushing_tank_step <= 1 )
            {
                if( gu8_display_flushing_total_percent < 40 )
                {
                    gu8_display_flushing_total_percent = 40;
                }
                else{}
            }
            else if( gu8_flushing_tank_step == 2 )
            {
                if( gu32_tank_flushing_operation_timer <= 6000 )
                {
                    if( gu8_display_flushing_total_percent < 50 )
                    {
                        gu8_display_flushing_total_percent = 50;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 60 )
                    {
                        gu8_display_flushing_total_percent = 60;
                    }
                    else{}
                }
            }
            else if( gu8_flushing_tank_step == 3 )
            {
                /*..hui [24-1-4���� 1:58:30] ������ -> ������ ä��� ��.. 70%�� ����..*/
                if( gu8_display_flushing_total_percent < 70 )
                {
                    gu8_display_flushing_total_percent = 70;
                }
                else{}

                #if 0
                if( gu32_tank_flushing_operation_timer <= 3000 )
                {
                    if( gu8_display_flushing_total_percent < 70 )
                    {
                        gu8_display_flushing_total_percent = 70;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 80 )
                    {
                        gu8_display_flushing_total_percent = 80;
                    }
                    else{}
                }
                #endif
            }
            /*else if( gu8_flushing_tank_step >= 4 && gu8_flushing_tank_step <= 14 )*/
            else if( gu8_flushing_tank_step >= 4 && gu8_flushing_tank_step <= 9 )
            {
                if( gu8_display_flushing_total_percent < 80 )
                {
                    gu8_display_flushing_total_percent = 80;
                }
                else{}
            }
            /*else if( gu8_flushing_tank_step == 15 )*/
            else if( gu8_flushing_tank_step == 10 )
            {
                if( gu32_tank_flushing_operation_timer <= 3000 )
                {
                    if( gu8_display_flushing_total_percent < 80 )
                    {
                        gu8_display_flushing_total_percent = 80;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 90 )
                    {
                        gu8_display_flushing_total_percent = 90;
                    }
                    else{}
                }
            }
            else
            {
                if( gu8_display_flushing_total_percent < 100 )
                {
                    gu8_display_flushing_total_percent = 100;
                }
                else{}
            }
        }
        else
        {
            gu8_display_flushing_total_percent = 100;
        }
    }
    else
    {
        if( gu8_filter_flushing_state == FILTER_FLUSHING_NEO_INO )
        {
            /*..hui [23-12-12���� 12:15:00] �� ������ �ȳ����� ����Ǳ����� finish state���� step�� 0�̵Ǹ鼭 ��� 0��ǥ�õɼ��̾�..*/
            if( gu8_flushing_mode == FLUSHING_MAIN_STATE )
            {
                /*..hui [23-12-12���� 11:27:33] �׿�,�̳� ��ü �÷���..*/
                if( gu8_flushing_step <= 3 )
                {
                    if( gu8_display_flushing_total_percent < 10 )
                    {
                        gu8_display_flushing_total_percent = 0;
                    }
                    else{}
                }
                else if( gu8_flushing_step == 4 )
                {
                    if( gu8_display_flushing_total_percent < 10 )
                    {
                        gu8_display_flushing_total_percent = 10;
                    }
                    else{}
                }
                else if( gu8_flushing_step <= 7 )
                {
                    if( gu8_display_flushing_total_percent < 20 )
                    {
                        gu8_display_flushing_total_percent = 20;
                    }
                    else{}
                }
                else if( gu8_flushing_step == 8 )
                {
                    if( gu8_flushing_operation_timer_min == 0 )
                    {
                        if( gu16_flushing_timer <= 200 )
                        {
                            if( gu8_display_flushing_total_percent < 30 )
                            {
                                gu8_display_flushing_total_percent = 30;
                            }
                            else{}
                        }
                        else if( gu16_flushing_timer <= 400 )
                        {
                            if( gu8_display_flushing_total_percent < 40 )
                            {
                                gu8_display_flushing_total_percent = 40;
                            }
                            else{}
                        }
                        else
                        {
                            if( gu8_display_flushing_total_percent < 50 )
                            {
                                gu8_display_flushing_total_percent = 50;
                            }
                            else{}
                        }
                    }
                    else
                    {
                        if( gu16_flushing_timer <= 200 )
                        {
                            if( gu8_display_flushing_total_percent < 60 )
                            {
                                gu8_display_flushing_total_percent = 60;
                            }
                            else{}
                        }
                        else if( gu16_flushing_timer <= 400 )
                        {
                            if( gu8_display_flushing_total_percent < 70 )
                            {
                                gu8_display_flushing_total_percent = 70;
                            }
                            else{}
                        }
                        else
                        {
                            if( gu8_display_flushing_total_percent < 80 )
                            {
                                gu8_display_flushing_total_percent = 80;
                            }
                            else{}
                        }
                    }
                }
                else if( gu8_flushing_step <= 14 )
                {
                    if( gu8_display_flushing_total_percent < 90 )
                    {
                        gu8_display_flushing_total_percent = 90;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 100 )
                    {
                        gu8_display_flushing_total_percent = 100;
                    }
                    else{}
                }
            }
            else
            {
                gu8_display_flushing_total_percent = 100;
            }
        }
        else /*if( gu8_filter_flushing_state == FILTER_FLUSHING_RO )*/
        {
            if( gu8_flushing_mode == FLUSHING_MAIN_STATE )
            {
                /*..hui [23-12-12���� 12:01:58] RO���� ��ü �÷���... 30��..*/
                if( gu8_flushing_step <= 7 )
                {
                    if( gu8_display_flushing_total_percent < 10 )
                    {
                        gu8_display_flushing_total_percent = 0;
                    }
                    else{}
                }
                else if( gu8_flushing_step == 8 )
                {
                    if( gu8_flushing_operation_timer_min <= 4 )
                    {
                        if( gu8_display_flushing_total_percent < 10 )
                        {
                            gu8_display_flushing_total_percent = 10;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 8 )
                    {
                        if( gu8_display_flushing_total_percent < 20 )
                        {
                            gu8_display_flushing_total_percent = 20;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 12 )
                    {
                        if( gu8_display_flushing_total_percent < 30 )
                        {
                            gu8_display_flushing_total_percent = 30;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 16 )
                    {
                        if( gu8_display_flushing_total_percent < 40 )
                        {
                            gu8_display_flushing_total_percent = 40;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 20 )
                    {
                        if( gu8_display_flushing_total_percent < 50 )
                        {
                            gu8_display_flushing_total_percent = 50;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 24 )
                    {
                        if( gu8_display_flushing_total_percent < 60 )
                        {
                            gu8_display_flushing_total_percent = 60;
                        }
                        else{}
                    }
                    else if( gu8_flushing_operation_timer_min <= 27 )
                    {
                        if( gu8_display_flushing_total_percent < 70 )
                        {
                            gu8_display_flushing_total_percent = 70;
                        }
                        else{}
                    }
                    else
                    {
                        if( gu8_display_flushing_total_percent < 80 )
                        {
                            gu8_display_flushing_total_percent = 80;
                        }
                        else{}
                    }
                }
                else if( gu8_flushing_step <= 14 )
                {
                    if( gu8_display_flushing_total_percent < 90 )
                    {
                        gu8_display_flushing_total_percent = 90;
                    }
                    else{}
                }
                else
                {
                    if( gu8_display_flushing_total_percent < 100 )
                    {
                        gu8_display_flushing_total_percent = 100;
                    }
                    else{}
                }
            }
            else
            {
                gu8_display_flushing_total_percent = 100;
            }
        }
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void save_return_step( U8 mu8_step )
{
    gu8_return_flushing_tank_step = mu8_step;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void convert_filter_change_type(void)
{
    /*..hui [23-12-12���� 12:51:07] ��ġ �÷��� ����.. ���� �÷��� ����Ǹ� ���� ����..*/
    if( gu8_filter_flushing_state == FILTER_FLUSHING_NONE )
    {
        return;
    }
    else{}

    if( bit_install_flushing_state == SET )
    {
        return;
    }
    else{}

    /*..hui [24-2-21���� 4:12:01] CT ���� �÷��� �Ҷ��� ��ȯ ���� ���� ����..*/
    if( gu8_ct_forced_flushing_start == SET )
    {
        return;
    }
    else{}

    #if 0
    if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_INO )
    {
        gu8_filter_change_type = FILTER_CHANGE_TYPE__NEO_RO_INO_ALL;
    }
    else /*if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_RO_INO_ALL )*/
    {
        gu8_filter_change_type = FILTER_CHANGE_TYPE__NEO_INO;
    }
    #endif

    /*..hui [24-7-30���� 1:47:36] �����꿡���� ��ȯ�ؾ��ؼ� �и�..*/
    change_filter_type();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void change_filter_type(void)
{
    if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_INO )
    {
        gu8_filter_change_type = FILTER_CHANGE_TYPE__NEO_RO_INO_ALL;
    }
    else /*if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_RO_INO_ALL )*/
    {
        gu8_filter_change_type = FILTER_CHANGE_TYPE__NEO_INO;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


















