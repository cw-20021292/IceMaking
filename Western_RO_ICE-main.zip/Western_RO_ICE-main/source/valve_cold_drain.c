/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "valve_cold_drain.h"

void output_cold_drain_valve(void);


/***********************************************************************************************************************/
TYPE_BYTE          U8ColdDrainValveONB;
#define            u8ColdDrainValveON                      U8ColdDrainValveONB.byte
#define            Bit0_CD_Flushing_Tank_Drain_On_State    U8ColdDrainValveONB.Bit.b0
#define            Bit1_CD_Circul_Drain_On_State           U8ColdDrainValveONB.Bit.b1
#define            Bit2_CD_Manual_Drain_On_State           U8ColdDrainValveONB.Bit.b2
#define            Bit3_CD_Ice_Ster_On_State               U8ColdDrainValveONB.Bit.b3
#define            Bit4_CD_Drain_Retry_On_State            U8ColdDrainValveONB.Bit.b4
#define            Bit5_CD_Drain_Acid_On_State             U8ColdDrainValveONB.Bit.b5




TYPE_BYTE          U8ColdDrainValveOFFB;
#define            u8ColdDrainValveOFF                     U8ColdDrainValveOFFB.byte
#define            Bit0_CD_Error_Off_State                 U8ColdDrainValveOFFB.Bit.b0



/***********************************************************************************************************************/
bit F_auto_drain_mode_cold_water_valve_out;

bit bit_cold_drain_output;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void output_cold_drain_valve(void)
{
    /***********************************************************************************************/
    /*..hui [23-8-25���� 1:22:05] �÷��� ������.. ��ũ ���� �Ҷ�..*/
    if( gu8_flushing_mode == FLUSHING_TANK_STATE )
    {
        if( bit_flushing_tank_start == SET )
        {
            if( bit_tank_drain_valve_output == SET )
            {
                Bit0_CD_Flushing_Tank_Drain_On_State = SET;
            }
            else
            {
                Bit0_CD_Flushing_Tank_Drain_On_State = CLEAR;
            }
        }
        else
        {
            Bit0_CD_Flushing_Tank_Drain_On_State = CLEAR;
        }
    }
    else
    {
        Bit0_CD_Flushing_Tank_Drain_On_State = CLEAR;
    }

    /*..hui [23-8-25���� 1:19:11] ��ȯ��� ���� ON..*/
    if( F_Circul_Drain == SET )
    {
        if( F_DrainStatus == SET )
        {
            /*..hui [23-8-25���� 1:19:18] ��ȯ��� ���� ��..*/
            if(F_auto_drain_mode_cold_water_valve_out == SET)
            {
                Bit1_CD_Circul_Drain_On_State = SET;
            }
            else
            {
                Bit1_CD_Circul_Drain_On_State = CLEAR;
            }
        }
        else
        {
            Bit1_CD_Circul_Drain_On_State = CLEAR;
        }
    }
    else
    {
        Bit1_CD_Circul_Drain_On_State = CLEAR;
    }

    /*..hui [23-8-25���� 1:21:54] ���� ��� ���� ��..*/
    if( bit_manual_drain_start == SET )
    {
        if(bit_manual_drain_valve_output == SET)
        {
            Bit2_CD_Manual_Drain_On_State = SET;
        }
        else
        {
            Bit2_CD_Manual_Drain_On_State = CLEAR;
        }
    }
    else
    {
        Bit2_CD_Manual_Drain_On_State = CLEAR;
    }


    /*..hui [23-8-25���� 1:34:34] �¼� ��ô �� �巹�� ��ũ ���⿡ ���� ���� ���� �����ϱ� ����..*/
    if( bit_ice_tank_ster_start == SET )
    {
        /*..hui [23-10-12���� 5:26:31] 45�� ������ ��� �غ��忡�� �ü� 10�� �־���� ����..*/
        if( gu8_ice_ster_mode ==  STER_MODE_PREPARE )
        {
            Bit3_CD_Ice_Ster_On_State = CLEAR;
        }
        else if( gu8_ice_ster_mode ==  STER_MODE_HOT_SPRAY_STATE )
        {
            /*Bit3_CD_Ice_Ster_On_State = CLEAR;*/

            if( gu8_hot_spray_step == 4 || gu8_hot_spray_step == 9 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [24-1-29���� 1:05:12] 1�� ��ô���� 7.5�ʷ�..*/
                        if( gu16_hot_spray_timer <= 120 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else
            {
                Bit3_CD_Ice_Ster_On_State = CLEAR;
            }
        }
        else if( gu8_ice_ster_mode ==  STER_MODE_LUKEWARM_SPRAY_STATE )
        {
            if( gu8_lukewarm_spray_step == 6 || gu8_lukewarm_spray_step == 11 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        /*if( gu16_lukewarm_spray_timer <= ICE_STER_COLD_DRAIN_OPEN_TIME )*/
                        /*if( gu16_lukewarm_spray_timer <= 100 )*/
                        if( gu16_lukewarm_spray_timer <= 120 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else
            {
                Bit3_CD_Ice_Ster_On_State = CLEAR;
            }
        }
        else if( gu8_ice_ster_mode ==  STER_MODE_FINAL_CLEAN_STATE )
        {
            if( gu8_final_clean_step == 6 || gu8_final_clean_step == 11)
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        /*if( gu16_final_clean_timer <= ICE_STER_COLD_DRAIN_OPEN_TIME )*/
                        if( gu16_final_clean_timer <= 120 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else
            {
                Bit3_CD_Ice_Ster_On_State = CLEAR;
            }
        }
        else if( gu8_ice_ster_mode ==  STER_MODE_ICE_TRAY_CLEAN )
        {
            if( gu8_ice_tray_clean_step == 9 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        if( gu16_ice_tray_clean_timer <= 80 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else if( gu16_ice_tray_clean_timer > 300
                                 && gu16_ice_tray_clean_timer <= 380 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else if( gu16_ice_tray_clean_timer > 600
                                 && gu16_ice_tray_clean_timer <= 680 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else if( gu16_ice_tray_clean_timer > 900
                                 && gu16_ice_tray_clean_timer <= 980 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else if( gu16_ice_tray_clean_timer > 1200
                                 && gu16_ice_tray_clean_timer <= 1280 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else if( gu16_ice_tray_clean_timer > 1500
                                 && gu16_ice_tray_clean_timer <= 1600 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }


                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else if( gu8_ice_tray_clean_step == 14 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )*/
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        /*if( gu16_ice_tray_clean_timer <= ICE_STER_COLD_DRAIN_OPEN_TIME )*/
                        /*if( gu16_ice_tray_clean_timer <= 150 )*/
                        /*if( gu16_ice_tray_clean_timer <= 200 )*/
                        /*if( gu16_ice_tray_clean_timer <= 250 )*/
                        if( gu16_ice_tray_clean_timer <= 100 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else if( gu8_ice_tray_clean_step == 16 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        /*if( gu16_ice_tray_clean_timer <= ICE_STER_COLD_DRAIN_OPEN_TIME )*/
                        /*if( gu16_ice_tray_clean_timer <= 50 )*/
                        /*if( gu16_ice_tray_clean_timer <= 80 )*/
                        if( gu16_ice_tray_clean_timer <= 100 )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else
            {
                Bit3_CD_Ice_Ster_On_State = CLEAR;
            }
        }
        else if( gu8_ice_ster_mode ==  STER_MODE_MELT_ICE )
        {
            /*..hui [23-10-17���� 2:43:05] ���� �غ��۾� �Ҷ��� 5�ʵ��� �־��ش�..*/
            if( gu8_melt_ice_step == 7 || gu8_melt_ice_step == 11 || gu8_melt_ice_step == 15 || gu8_melt_ice_step == 19 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
                    {
                        /*..hui [23-8-25���� 1:31:30] �켱 5�ʵ��� ����..*/
                        /*..hui [24-2-7���� 4:41:36] 7�ʷ� ����..*/
                        if( gu16_melt_ice_timer <= ICE_STER_COLD_DRAIN_OPEN_TIME )
                        {
                            Bit3_CD_Ice_Ster_On_State = SET;
                        }
                        else
                        {
                            Bit3_CD_Ice_Ster_On_State = CLEAR;
                        }
                    }
                    else
                    {
                        Bit3_CD_Ice_Ster_On_State = CLEAR;
                    }
                }
                else
                {
                    Bit3_CD_Ice_Ster_On_State = CLEAR;
                }
            }
            else
            {
                Bit3_CD_Ice_Ster_On_State = CLEAR;
            }
        }
        else
        {
            Bit3_CD_Ice_Ster_On_State = CLEAR;
        }
    }
    else
    {
        Bit3_CD_Ice_Ster_On_State = CLEAR;
    }



    /*..hui [24-3-28���� 2:38:31] ������ �Ͻ��� �������϶� �ľ��ֱ�..*/
    if( bit_drain_error_check_enable == SET )
    {
        /*..hui [24-3-28���� 2:37:17] �巹����ũ ������ ���� ������ ��쿡��..*/
        /*..hui [24-3-28���� 2:37:27] Ȥ�ø��� ����ִ� ���µ� �߰�..*/
        if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
        {
            if( gu8_drain_pump_retry_step == DRAIN_RETRY_COLD_DRIN_ON )
            {
                Bit4_CD_Drain_Retry_On_State = SET;
            }
            else
            {
                Bit4_CD_Drain_Retry_On_State = CLEAR;
            }
        }
        else
        {
            Bit4_CD_Drain_Retry_On_State = CLEAR;
        }
    }
    else
    {
        Bit4_CD_Drain_Retry_On_State = CLEAR;
    }


    /*..hui [24-5-23���� 5:40:22] ������ ��ô�Ҷ�..*/
    if( bit_acid_clean_start == SET )
    {
        if( gu8_acid_clean_mode == ACID_CLEAN_NONE_STATE )
        {
            Bit5_CD_Drain_Acid_On_State = CLEAR;
        }
        else if( gu8_acid_clean_mode == ACID_CLEAN_STANDBY )
        {
            Bit5_CD_Drain_Acid_On_State = CLEAR;
        }
        else if( gu8_acid_clean_mode == ACID_CLEAN_PREPARE )
        {
            if( gu8_acid_prepare_step == 1 )
            {
                if( bit_acid_drain_valve_output == SET )
                {
                    Bit5_CD_Drain_Acid_On_State = SET;
                }
                else
                {
                    Bit5_CD_Drain_Acid_On_State = CLEAR;
                }
            }
            else if( gu8_acid_prepare_step == 4 )
            {
                /*..hui [24-7-22���� 3:00:06] ������ �������ϸ鼭 ������ �̻� ����.. �巹����ũ�� ������ �Լ�..*/
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    Bit5_CD_Drain_Acid_On_State = SET;
                }
                else
                {
                    Bit5_CD_Drain_Acid_On_State = CLEAR;
                }
            }
            else
            {
                Bit5_CD_Drain_Acid_On_State = CLEAR;
            }
        }
        else if( gu8_acid_clean_mode == ACID_CLEAN_CHANGE_FILTER )
        {
            Bit5_CD_Drain_Acid_On_State = CLEAR;
        }
        else if( gu8_acid_clean_mode == ACID_CLEAN_WAIT_1_HOUR )
        {
            Bit5_CD_Drain_Acid_On_State = CLEAR;
        }
        else if( gu8_acid_clean_mode == ACID_CLEAN_RINSE )
        {
            if( gu8_acid_rinse_step == 1|| gu8_acid_rinse_step == 10 || gu8_acid_rinse_step == 13 )
            {
                if( bit_acid_drain_valve_output == SET )
                {
                    Bit5_CD_Drain_Acid_On_State = SET;
                }
                else
                {
                    Bit5_CD_Drain_Acid_On_State = CLEAR;
                }
            }
            else
            {
                Bit5_CD_Drain_Acid_On_State = CLEAR;
            }
        }
        else /*if( gu8_acid_clean_mode == ACID_CLEAN_FINISH )*/
        {
            Bit5_CD_Drain_Acid_On_State = CLEAR;
        }
    }
    else
    {
        Bit5_CD_Drain_Acid_On_State = CLEAR;
    }




///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
    /*..hui [23-8-25���� 1:10:25] �巹�� ���� ����, ���� ������ ��� ������ OFF..*/
    if( Bit16_Drain_Pump_Error__E60 == SET || Bit3_Leakage_Sensor_Error__E01 == SET )
    {
        Bit0_CD_Error_Off_State = SET;
    }
    else
    {
        Bit0_CD_Error_Off_State = CLEAR;
    }



/***********************************************************************************************/
    if (u8ColdDrainValveOFF > 0)
    {
        pVALVE_COLD_DRAIN = CLEAR;      /*off*/
        bit_cold_drain_output = CLEAR;
    }
    else
    {
        if (u8ColdDrainValveON > 0)
        {
            pVALVE_COLD_DRAIN = SET;    /*on*/
            bit_cold_drain_output = SET;
        }
        else
        {
            pVALVE_COLD_DRAIN = CLEAR;  /*off*/
            bit_cold_drain_output = CLEAR;
        }
    }
/***********************************************************************************************/

}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/



