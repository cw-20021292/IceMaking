/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "display_led_icon.h"

void icon_led_out(void);
void left_icon_led_output(void);
void preparing_text_output(void);
void current_text_output(void);
void filter_flushing_text_output(void);
//void water_usage_text_output(void);
void eco_icon_output(void);
void percent_oC_oF_icon_output(void);
//void gal_text_output(void);
void right_icon_led_output(void);
void replace_filter_text_output(void);
void replace_filter_1_3_num_led_output(void);
void wifi_icon_output(void);
void oz_ml_icon_output(void);
void min_left_text_output(void);
void days_left_text_output(void);
void under_icon_led_output(void);
void ice_full_led_output(void);
void ice_lock_icon_output(void);
void hot_lock_icon_output(void);
void ice_first_icon_output(void);
void making_text_led_output(void);
void heating_text_led_output(void);
void cooling_text_led_output(void);
void low_water_led_output(void);
void wifi_pairing_display(void);

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void icon_led_out(void)
{
    left_icon_led_output();
    right_icon_led_output();
    under_icon_led_output();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void left_icon_led_output(void)
{
    preparing_text_output();
    current_text_output();
    /*water_usage_text_output();*/
    eco_icon_output();
    filter_flushing_text_output();
    percent_oC_oF_icon_output();
    /*gal_text_output();*/
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void preparing_text_output(void)
{

    if( F_Ice == SET && gu8_Led_Display_Step == LED_Display__ICE_EXTRACT )
    {
        /*..hui [23-8-18���� 11:26:43] ���� �����߿��� ����..*/
        Bit0_Front_Left_Led_Preparing_Text = CLEAR;
    }
    else if( u8WaterOutState == HOT_WATER_SELECT )
    {
        if( F_WaterOut == SET )
        {
            /*..hui [23-11-27���� 3:39:33] �������� �ʿ��Ҷ� �� �����Ҷ��� OFF..*/
            Bit0_Front_Left_Led_Preparing_Text = CLEAR;
        }
        else if( gu8_hot_prepare_mode == HOT_PREPARE_MODE_ON )
        {
            Bit0_Front_Left_Led_Preparing_Text = SET;
        }
        else /*if( gu8_hot_prepare_mode == HOT_PREPARE_MODE_OFF )*/
        {
            Bit0_Front_Left_Led_Preparing_Text = CLEAR;
        }
    }
    else
    {
        Bit0_Front_Left_Led_Preparing_Text = CLEAR;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void current_text_output(void)
{
    if( F_Ice == SET && gu8_Led_Display_Step == LED_Display__ICE_EXTRACT )
    {
        /*..hui [23-8-18���� 11:26:43] ���� �����߿��� ����..*/
        Bit1_Front_Left_Led_Current_Text = CLEAR;
    }
    else if( u8WaterOutState == COLD_WATER_SELECT )
    {
        if( gu8_cooling_display_mode == COOLING_DISPLAY_1_ON )
        {
            /*..hui [23-11-17���� 12:06:13] �ð����� �ƴ϶�.. �ð��� �ʿ��� ����..*/
            Bit1_Front_Left_Led_Current_Text = SET;
        }
        else
        {
            /*..hui [23-11-17���� 12:06:38] ����� ������ ������ �ð��� �Ϸ�Ȼ���..*/
            Bit1_Front_Left_Led_Current_Text = CLEAR;
        }
    }
    else if( u8WaterOutState == HOT_WATER_SELECT )
    {
        if( F_WaterOut == SET )
        {
            if( bit_hot_current_temp_on == SET )
            {
                Bit1_Front_Left_Led_Current_Text = SET;
            }
            else
            {
                Bit1_Front_Left_Led_Current_Text = CLEAR;
            }
        }
        else
        {
            Bit1_Front_Left_Led_Current_Text = CLEAR;
        }
    }
    else
    {
        Bit1_Front_Left_Led_Current_Text = CLEAR;
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void filter_flushing_text_output(void)
{

    /*..hui [23-6-2���� 12:01:22] �÷����߿� ����..*/
    if( gu8_flushing_mode == FLUSHING_STANDBY_STATE || bit_flushing_halt == SET )
    {
        Bit2_Front_Left_Led_Filter_Flushing_Text = CLEAR;
    }
    else if( gu8_flushing_mode > FLUSHING_STANDBY_STATE )
    {
        Bit2_Front_Left_Led_Filter_Flushing_Text = SET;
    }
    else
    {
        Bit2_Front_Left_Led_Filter_Flushing_Text = CLEAR;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
#if 0
void water_usage_text_output(void)
{
    if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN
        && bit_filter_all == CLEAR )
    {
        Bit2_Front_Left_Led_Filter_Flushing_Text = SET;
    }
    else
    {
        Bit2_Front_Left_Led_Filter_Flushing_Text = CLEAR;
    }
}
#endif

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void eco_icon_output(void)
{
    if( gu8_Led_Display_Step == LED_Display__SLEEP )
    {
        /*set_duty_percent( DIMMING__PERCENT_ECCO_ICON, DIIMMING__10_PERCENT );*/
        /*set_duty_percent( DIMMING__PERCENT_ECCO_ICON, DIIMMING__100_PERCENT );*/
        set_duty_percent( DIMMING__PERCENT_ECCO_ICON, DIIMMING__20_PERCENT );
    }
    else
    {
        set_duty_percent( DIMMING__PERCENT_ECCO_ICON, TOP_ICON__DIMMING__50_PERCENT );
    }

    /*..hui [23-3-2���� 7:14:46] ���߿� �ٽ�..*/
    //Bit3_Front_Left_Led_Eco_Icon = CLEAR;
    //return;

    /*if( F_Save == SET )*/
    if( bit_sleep_mode_enable == SET )
    {
        Bit3_Front_Left_Led_Eco_Icon = SET;
    }
    else
    {
        Bit3_Front_Left_Led_Eco_Icon = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void percent_oC_oF_icon_output(void)
{
    /*..hui [23-6-2���� 12:01:22] �÷����߿� ����..*/
    /*..hui [23-6-5���� 10:30:55] �÷��� �ߴ��ϰ� ��� ���½ð� 1�ʵ��� ���÷��� off..*/
    if( (gu8_Led_Display_Step == LED_Display__FLUSHING
        && gu8_flushing_mode == FLUSHING_STANDBY_STATE)
        || bit_flushing_halt == SET )
    {
        Bit5_Front_Left_Led_Percent_Icon = CLEAR;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__FLUSHING
        && gu8_flushing_mode > FLUSHING_STANDBY_STATE )
    {
        Bit5_Front_Left_Led_Percent_Icon = SET;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( bit_self_test_start == SET )
    {
        Bit5_Front_Left_Led_Percent_Icon = SET;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__WIFI_PAIRING )
    {
        if( bit_display_wifi_error == SET || bit_display_last_error == SET )
        {
            Bit5_Front_Left_Led_Percent_Icon = CLEAR;
            Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
            Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
        }
        else
        {
            /*..hui [23-12-4���� 2:14:01] �� �ܰ� ǥ��ȭ�鿡���� �ۼ�Ʈ�� ǥ��..*/
            Bit5_Front_Left_Led_Percent_Icon = SET;
            Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
            Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
        }
    }
    else if( gu8_Led_Display_Step == LED_Display__ICE_EXTRACT )
    {
        Bit5_Front_Left_Led_Percent_Icon = CLEAR;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__ERROR )
    {
        Bit5_Front_Left_Led_Percent_Icon = CLEAR;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__STEAM_CLEAN )
    {
        Bit5_Front_Left_Led_Percent_Icon = SET;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__UV )
    {
        /*..hui [23-6-1���� 3:27:53] UV ����� ǥ��..*/
        Bit5_Front_Left_Led_Percent_Icon = SET;
        Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
        Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
    }
    else
    {
        Bit5_Front_Left_Led_Percent_Icon = CLEAR;

        if( gu8_oF__oC_select == Fahrenheit_oF_SELECT )
        {
            Bit4_Front_Left_Led_Fahrenheit_oF_Icon = SET;
            Bit6_Front_Left_Led_Celcius_oC_Icon = CLEAR;
        }
        else
        {
            Bit4_Front_Left_Led_Fahrenheit_oF_Icon = CLEAR;
            Bit6_Front_Left_Led_Celcius_oC_Icon = SET;
        }
    }





}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
#if 0
void gal_text_output(void)
{
    if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN
        && bit_filter_all == CLEAR )
    {
        Bit7_Front_Left_Led_Gal_Icon = SET;
    }
    else
    {
        Bit7_Front_Left_Led_Gal_Icon = CLEAR;
    }
}
#endif

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void right_icon_led_output(void)
{
    replace_filter_text_output();
    /*..hui [23-12-6���� 5:52:39] ���� �ѹ� 1,2,3 ���� ǥ�� �߰�..*/
    replace_filter_1_3_num_led_output();
    wifi_icon_output();
    oz_ml_icon_output();
    min_left_text_output();
    days_left_text_output();
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void replace_filter_text_output(void)
{
    if( bit_ct_flushing_standby_start == SET || gu8_ct_forced_flushing_start == SET )
    {
        Bit4_Front_New_Led_Replace_Filter_Text = F_Wink_500ms;
    }
    else if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN
            && bit_filter_all == CLEAR
            && bit_filter_alarm_start == SET )
    {
        Bit4_Front_New_Led_Replace_Filter_Text = SET;
    }
    /*else if( gu8_Led_Display_Step == LED_Display__FILTER_ALARM
        && bit_filter_alarm_start == SET )*/
    else if( bit_filter_alarm_start == SET )
    {
        Bit4_Front_New_Led_Replace_Filter_Text = SET;
    }
    else
    {
        Bit4_Front_New_Led_Replace_Filter_Text = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void replace_filter_1_3_num_led_output(void)
{
    if( bit_ct_flushing_standby_start == SET || gu8_ct_forced_flushing_start == SET )
    {
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, TOP_ICON__DIMMING__50_PERCENT );
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

        #if 0
        Bit5_Front_New_Led_Replace_Filter_1_Num = Bit0_Neo_Filter_1_Reset_State & F_Wink_500ms;
        Bit6_Front_New_Led_Replace_Filter_2_Num = Bit1_Ro_Filter_2_Reset_State & F_Wink_500ms;
        Bit7_Front_New_Led_Replace_Filter_3_Num = Bit2_Ino_Filter_3_Reset_State & F_Wink_500ms;
        #endif

        Bit5_Front_New_Led_Replace_Filter_1_Num = Bit0_CT_Neo_Filter_1_Replace & F_Wink_500ms;
        Bit6_Front_New_Led_Replace_Filter_2_Num = Bit1_CT_Ro_Filter_2_Replace & F_Wink_500ms;
        Bit7_Front_New_Led_Replace_Filter_3_Num = Bit2_CT_Ino_Filter_3_Replace & F_Wink_500ms;
    }
    else if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN
        && bit_filter_all == CLEAR
        && bit_filter_alarm_start == SET )
    {
        if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_INO )
        {
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, DIIMMING__10_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

            Bit5_Front_New_Led_Replace_Filter_1_Num = SET;
            Bit6_Front_New_Led_Replace_Filter_2_Num = SET;
            Bit7_Front_New_Led_Replace_Filter_3_Num = SET;
        }
        else /*if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_RO_INO_ALL )*/
        {
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

            Bit5_Front_New_Led_Replace_Filter_1_Num = SET;
            Bit6_Front_New_Led_Replace_Filter_2_Num = SET;
            Bit7_Front_New_Led_Replace_Filter_3_Num = SET;
        }
    }
    else if( bit_filter_alarm_start == SET )
    {
        if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_INO )
        {
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, DIIMMING__10_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

            Bit5_Front_New_Led_Replace_Filter_1_Num = SET;
            Bit6_Front_New_Led_Replace_Filter_2_Num = SET;
            Bit7_Front_New_Led_Replace_Filter_3_Num = SET;
        }
        else /*if( gu8_filter_change_type == FILTER_CHANGE_TYPE__NEO_RO_INO_ALL )*/
        {
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, TOP_ICON__DIMMING__50_PERCENT );
            set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

            Bit5_Front_New_Led_Replace_Filter_1_Num = SET;
            Bit6_Front_New_Led_Replace_Filter_2_Num = SET;
            Bit7_Front_New_Led_Replace_Filter_3_Num = SET;
        }
    }
    else
    {
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_1_NUM, TOP_ICON__DIMMING__50_PERCENT );
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_2_NUM, TOP_ICON__DIMMING__50_PERCENT );
        set_duty_percent( DIMMING__PERCENT_NEW_REPLACE_FILTER_3_NUM, TOP_ICON__DIMMING__50_PERCENT );

        Bit5_Front_New_Led_Replace_Filter_1_Num = CLEAR;
        Bit6_Front_New_Led_Replace_Filter_2_Num = CLEAR;
        Bit7_Front_New_Led_Replace_Filter_3_Num = CLEAR;
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_icon_output(void)
{
    /*..hui [24-3-27���� 6:49:17] ȭ��Ʈ, ���� �ۼ�Ʈ�� �и��Ǿ� �Ʒ������� �̵�..*/
    #if 0
    if( gu8_Led_Display_Step == LED_Display__SLEEP )
    {
        /*set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, DIIMMING__10_PERCENT );*/
        /*set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, DIIMMING__100_PERCENT );*/
        /*set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, DIIMMING__20_PERCENT );*/
        set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, DIIMMING__10_PERCENT );
    }
    else
    {
        set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, TOP_ICON__DIMMING__50_PERCENT );
    }
    #endif

    if( gu8_Wifi_Connect_State == WIFI_OFF )
    {
        Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
        Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
        gu8_wifi_disp_timer = 0;
        gu16_wifi_pairing_30min_timer = 0;
        gu8_wifi_pairing_5sec_timer = 0;
        bit_pairing_5s_display_start = CLEAR;
    }
    else if( gu8_Wifi_Connect_State == WIFI_CONNECT )
    {
        Bit1_Front_Right_Led_Wifi_Icon_White = SET;
        Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
        gu8_wifi_disp_timer = 0;
        gu16_wifi_pairing_30min_timer = 0;
        gu8_wifi_pairing_5sec_timer = 0;
        bit_pairing_5s_display_start = CLEAR;
    }
    else /*if( gu8_Wifi_Connect_State == WIFI_DISCONNECT )*/
    {
        gu8_wifi_disp_timer++;

        if( gu8_wifi_disp_timer >= 10 )
        {
            gu8_wifi_disp_timer = 0;
        }
        else{}

        if( gu8_wifi_ap_mode == SET || gu8_ble_ap_mode == SET )
        {
            if( bit_install_flushing_state == SET )
            {
                /*..hui [24-8-6���� 9:49:17] ��ġ �÷����߿��� ���������� ���� ǥ��..*/
                gu16_wifi_pairing_30min_timer = 0;
                gu8_wifi_pairing_5sec_timer = 0;
                bit_pairing_5s_display_start = CLEAR;
                wifi_pairing_display();
            }
            else
            {
                gu16_wifi_pairing_30min_timer++;

                if( gu16_wifi_pairing_30min_timer >= WIFI_PAIRING_START_30_MIN )
                {
                    /*..hui [24-8-6���� 9:50:14] �����忡�� 30�е��� ǥ�� �� OFF ǥ��..*/
                    gu16_wifi_pairing_30min_timer  = WIFI_PAIRING_START_30_MIN;

                    if( bit_pairing_5s_display_start == SET && gu8_Led_Display_Step != LED_Display__WATER_EXTRACT )
                    {
                        gu8_wifi_pairing_5sec_timer++;

                        /*..hui [24-8-6���� 9:58:42] �� ���� ����ǰ� 5�� ���� ǥ��..*/
                        if( gu8_wifi_pairing_5sec_timer >= 50 )
                        {
                            gu8_wifi_pairing_5sec_timer = 0;
                            bit_pairing_5s_display_start = CLEAR;
                        }
                        else{}

                        wifi_pairing_display();
                    }
                    else
                    {
                        Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
                        Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
                        gu8_wifi_disp_timer = 0;
                        gu8_wifi_pairing_5sec_timer = 0;
                    }
                }
                else
                {
                    gu8_wifi_pairing_5sec_timer = 0;
                    bit_pairing_5s_display_start = CLEAR;
                    wifi_pairing_display();
                }
            }
        }
        else
        {
            gu16_wifi_pairing_30min_timer = 0;
            gu8_wifi_pairing_5sec_timer = 0;
            bit_pairing_5s_display_start = CLEAR;

            if( gu8_wifi_disp_timer >= 5 )
            {
                Bit1_Front_Right_Led_Wifi_Icon_White = SET;
                Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
            }
            else
            {
                Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
                Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
            }
        }
    }

    if( gu8_Led_Display_Step == LED_Display__SLEEP )
    {
        set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, DIIMMING__20_PERCENT );
        set_duty_percent( DIMMING__PERCENT_WIFI_BLUE_ICON, DIIMMING__20_PERCENT );
    }
    else
    {
        if( Bit1_Front_Right_Led_Wifi_Icon_White == SET && Bit2_Front_Right_Led_Wifi_Icon_Blue == SET )
        {
            /*..hui [24-3-27���� 7:32:46] ���� ���縸 ������ ����.. ȭ��Ʈ�� 10%�� ��������..*/
            set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, WIFI_BLUE_WITH_WHITE_LED_10_PERCENT );
            set_duty_percent( DIMMING__PERCENT_WIFI_BLUE_ICON, WIFI_BLUE_LED_100_PERCENT );
        }
        else if( Bit1_Front_Right_Led_Wifi_Icon_White == SET && Bit2_Front_Right_Led_Wifi_Icon_Blue == CLEAR )
        {
            set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, WIFI_WHITE_LED_70_PERCENT );
            set_duty_percent( DIMMING__PERCENT_WIFI_BLUE_ICON, WIFI_BLUE_LED_100_PERCENT );
        }
        else if( Bit1_Front_Right_Led_Wifi_Icon_White == CLEAR && Bit2_Front_Right_Led_Wifi_Icon_Blue == SET )
        {
            set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, WIFI_WHITE_LED_70_PERCENT );
            set_duty_percent( DIMMING__PERCENT_WIFI_BLUE_ICON, WIFI_BLUE_LED_100_PERCENT );
        }
        else
        {
            set_duty_percent( DIMMING__PERCENT_WIFI_WHITE_ICON, WIFI_WHITE_LED_70_PERCENT );
            set_duty_percent( DIMMING__PERCENT_WIFI_BLUE_ICON, WIFI_BLUE_LED_100_PERCENT );
        }
    }


}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void wifi_pairing_display(void)
{
    /*..hui [23-6-14���� 9:34:53] BLE�� ��� BLUE..*/
    if( gu8_ble_ap_mode == SET )
    {
        /*Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;*/

        if( gu8_wifi_disp_timer == 0 )
        {
            /*..hui [24-3-27���� 7:31:20] ���� �Ӌ� ȭ��Ʈ 10%�� ���� ����..���ڤӤ�..*/
            Bit2_Front_Right_Led_Wifi_Icon_Blue = SET;
            Bit1_Front_Right_Led_Wifi_Icon_White = SET;
        }
        else if( gu8_wifi_disp_timer == 1 )
        {
            Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
            Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
        }
        else if( gu8_wifi_disp_timer == 2 )
        {
            /*..hui [24-3-27���� 7:31:20] ���� �Ӌ� ȭ��Ʈ 10%�� ���� ����..���ڤӤ�..*/
            Bit2_Front_Right_Led_Wifi_Icon_Blue = SET;
            Bit1_Front_Right_Led_Wifi_Icon_White = SET;
        }
        else
        {
            Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;
            Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
        }
    }
    else
    {
        Bit2_Front_Right_Led_Wifi_Icon_Blue = CLEAR;

        if( gu8_wifi_disp_timer == 0 )
        {
            Bit1_Front_Right_Led_Wifi_Icon_White = SET;
        }
        else if( gu8_wifi_disp_timer == 1 )
        {
            Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
        }
        else if( gu8_wifi_disp_timer == 2 )
        {
            Bit1_Front_Right_Led_Wifi_Icon_White = SET;
        }
        else
        {
            Bit1_Front_Right_Led_Wifi_Icon_White = CLEAR;
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void oz_ml_icon_output(void)
{
    /*if( F_WaterOut == SET && u8Extract_Continue == SET )*/
    if( F_WaterOut == SET )
    {
        /*..hui [23-5-11���� 4:20:58] �� �����Ҷ� �Ѱ� ���� �����Ҷ� ����..*/
        if( u8Extract_Continue == CLEAR )
        {
            if( gu8_ml__oz_select == Oz_SELECT )
            {
                Bit3_Front_Right_Led_OZ_Text = SET;
                Bit5_Front_Right_Led_ml_Text = CLEAR;
            }
            else
            {
                Bit3_Front_Right_Led_OZ_Text = CLEAR;
                Bit5_Front_Right_Led_ml_Text = SET;
            }
        }
        else
        {
            Bit3_Front_Right_Led_OZ_Text = CLEAR;
            Bit5_Front_Right_Led_ml_Text = CLEAR;

        }
    }
    else if( F_Ice == SET && gu8_Led_Display_Step == LED_Display__ICE_EXTRACT )
    {
        /*..hui [23-5-11���� 3:55:08] ���� �����Ҷ��� ����..*/
        Bit3_Front_Right_Led_OZ_Text = CLEAR;
        Bit5_Front_Right_Led_ml_Text = CLEAR;
    }
    else
    {
        /*..hui [23-8-16���� 10:41:24] ������ �޴������� �߰�.....*/
        if( gu8Cup_level == CUP_LEVEL__CONTINUE )
        {
            Bit3_Front_Right_Led_OZ_Text = CLEAR;
            Bit5_Front_Right_Led_ml_Text = CLEAR;
        }
        else
        {
            if( gu8_ml__oz_select == Oz_SELECT )
            {
                Bit3_Front_Right_Led_OZ_Text = SET;
                Bit5_Front_Right_Led_ml_Text = CLEAR;
            }
            else
            {
                Bit3_Front_Right_Led_OZ_Text = CLEAR;
                Bit5_Front_Right_Led_ml_Text = SET;
            }
        }
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void min_left_text_output(void)
{
    /*..hui [23-6-2���� 12:01:22] �÷����߿� ����..*/
    if( (gu8_Led_Display_Step == LED_Display__FLUSHING
        && gu8_flushing_mode == FLUSHING_STANDBY_STATE)
        || bit_flushing_halt == SET )
    {
        Bit4_Front_Right_Led_Min_Left_Text = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__FLUSHING
        && gu8_flushing_mode > FLUSHING_STANDBY_STATE )
    {
        /*..hui [23-8-21���� 3:23:16] �÷����Ҷ��� %�θ� ǥ���ϵ��� �����..*/
        Bit4_Front_Right_Led_Min_Left_Text = CLEAR;
    }
    else if( gu8_Led_Display_Step == LED_Display__UV )
    {
        Bit4_Front_Right_Led_Min_Left_Text = SET;
    }
    else
    {
        Bit4_Front_Right_Led_Min_Left_Text = CLEAR;
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void days_left_text_output(void)
{
    if( gu8_Led_Display_Step == LED_Display__FILTER_COVER_OPEN
        && bit_filter_all == CLEAR
        && bit_filter_alarm_start == SET )
    {
        Bit6_Front_Right_Led_Days_Left_Text = SET;
    }
    else if( gu8_Led_Display_Step == LED_Display__FILTER_ALARM
        && bit_filter_alarm_start == SET )
    {
        Bit6_Front_Right_Led_Days_Left_Text = SET;
    }
    else
    {
        Bit6_Front_Right_Led_Days_Left_Text = CLEAR;
    }
}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void under_icon_led_output(void)
{
    ice_full_led_output();
    ice_lock_icon_output();
    hot_lock_icon_output();
    ice_first_icon_output();

    making_text_led_output();
    heating_text_led_output();
    cooling_text_led_output();
    low_water_led_output();
}




/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_full_led_output(void)
{
    if( F_IceFull == SET )
    {
        Bit5_Front_Under_Led_Ice_Full = SET;
    }
    else
    {
        Bit5_Front_Under_Led_Ice_Full = CLEAR;
    }
}
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_lock_icon_output(void)
{
    if( F_Ice_Lock == SET )
    {
        Bit1_Front_Under_Icon_Led_Ice_Lock = SET;
    }
    else
    {
        Bit1_Front_Under_Icon_Led_Ice_Lock = CLEAR;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void hot_lock_icon_output(void)
{
    if( F_Hot_Lock == SET )
    {
        Bit2_Front_Under_Icon_Led_Hot_Lock = SET;
    }
    else
    {
        Bit2_Front_Under_Icon_Led_Hot_Lock = CLEAR;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_first_icon_output(void)
{

    #if 0
    if( bit_fast_ice_make == ICE_FIRST_ICE_MAKE )
    {
        Bit0_Front_Under_Txt_Led_Ice_First = SET;
    }
    else
    {
        Bit0_Front_Under_Txt_Led_Ice_First = CLEAR;
    }
    #endif


    /*..hui [24-2-21���� 2:38:24] ���� OFF�ϸ� ���̽��۽�Ʈ�� OFF�ϵ���..*/
    /*..hui [24-2-21���� 2:38:34] ��, ������� ���Խÿ��� �������¿� ���� ���������..*/
    if( bit_setting_mode_start == CLEAR )
    {
        if( F_IceOn == SET )
        {
            if( bit_fast_ice_make == ICE_FIRST_ICE_MAKE )
            {
                Bit0_Front_Under_Txt_Led_Ice_First = SET;
            }
            else
            {
                Bit0_Front_Under_Txt_Led_Ice_First = CLEAR;
            }
        }
        else
        {
            Bit0_Front_Under_Txt_Led_Ice_First = CLEAR;
        }
    }
    else
    {
        if( bit_fast_ice_make == ICE_FIRST_ICE_MAKE )
        {
            Bit0_Front_Under_Txt_Led_Ice_First = SET;
        }
        else
        {
            Bit0_Front_Under_Txt_Led_Ice_First = CLEAR;
        }
    }




}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void making_text_led_output(void)
{
    if( F_IceOn == CLEAR )
    {
        /*..hui [23-11-10���� 2:12:18] making off..*/
        Bit0_Front_New_Led_Ice_Making_Text = CLEAR;
    }
    else if( Bit2_Room_Temp_Open_Short_Error__E42 == SET
             /*|| Bit18_Tray_In_Temp_Open_Short_Error__E41 == SET*/
             || Bit1_Room_OverHeat_Error__E49 == SET
             || Bit17_Tray_Micro_SW_Dual_Detect_Error__E61 == SET
             || Bit18_Tray_Micro_SW_Up_Move_Error__E62 == SET
             || Bit19_Tray_Micro_SW_Down_Move_Error__E63 == SET

             || Bit16_Drain_Pump_Error__E60 == SET
             || Bit4_Room_Low_Water_Level_Error__E21 == SET

             /*..hui [23-9-20���� 9:24:23] �� �� ����..*/
             || (Bit15_Amb_Temp_Open_Short_Error__E43 == SET && Bit21_Amb_Side_Temp_Open_Short_Error__E53 == SET)
             /*|| Bit21_Amb_Side_Temp_Open_Short_Error__E53 == SET*/

             || Bit3_Leakage_Sensor_Error__E01 == SET

             || Bit7_BLDC_Communication_Error__E27 == SET
             || bit_bldc_operation_error_total == SET )
    {
        /*..hui [23-12-22���� 4:38:00] ���� ����� ���� ���� ���� �ɷ�����.. �ν�..*/
        Bit0_Front_New_Led_Ice_Making_Text = CLEAR;
    }
    else if( F_IceFull == CLEAR )
    {
        /*..hui [20-1-28���� 4:10:16] ���� ��..*/
        /*..hui [23-11-17���� 12:04:48] ���� �� -> ������ �ʿ��� ����..*/
        Bit0_Front_New_Led_Ice_Making_Text = SET;
    }
    else
    {
        /*..hui [20-1-28���� 4:10:22] ǥ�� ����..*/
        /*..hui [23-11-17���� 12:04:56] �����̶� �ݴ�� ����..*/
        Bit0_Front_New_Led_Ice_Making_Text = CLEAR;
    }

}
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void heating_text_led_output(void)
{
    if( gu8_heating_display_mode == HEATING_DISPLAY_2_ON )
    {
        /*..hui [23-11-27���� 2:26:18] ������ �ʿ��� ����..*/
        Bit1_Front_New_Led_Hot_Heating_Text = SET;
    }
    else
    {
        /*..hui [24-2-21���� 10:05:34] 92���϶�.. Heating�� �����ִµ� �¼� ���ý� Preparing�� �����ִ� ���� �߻�..*/
        /*..hui [24-2-21���� 10:05:55] �¼� ������������ Heating OFF �����̴��� Preparing�� ON�������� ���� �ѵ��� ����..*/
        /*..hui [24-2-21���� 10:06:02] ��, ���� ������ �ֿ켱..*/
        if( u8WaterOutState == HOT_WATER_SELECT )
        {
            if( gu8_heating_display_mode == HEATING_DISPLAY_0_INIT )
            {
                Bit1_Front_New_Led_Hot_Heating_Text = CLEAR;
            }
            else
            {
                if( gu8_hot_prepare_mode == HOT_PREPARE_MODE_ON )
                {
                    Bit1_Front_New_Led_Hot_Heating_Text = SET;
                }
                else
                {
                    Bit1_Front_New_Led_Hot_Heating_Text = CLEAR;
                }
            }
        }
        else
        {
            /*..hui [23-11-27���� 2:26:27] ����� �߰ſ� ������ ������ �Ϸ�Ȼ���..*/
            Bit1_Front_New_Led_Hot_Heating_Text = CLEAR;
        }
    }


}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void cooling_text_led_output(void)
{

    if( gu8_cooling_display_mode == COOLING_DISPLAY_1_ON )
    {
        /*..hui [23-11-17���� 12:06:13] �ð����� �ƴ϶�.. �ð��� �ʿ��� ����..*/
        Bit2_Front_New_Led_Cold_Cooling_Text = SET;
    }
    else
    {
        /*..hui [23-11-17���� 12:06:38] ����� ������ ������ �ð��� �Ϸ�Ȼ���..*/
        Bit2_Front_New_Led_Cold_Cooling_Text = CLEAR;
    }

}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void low_water_led_output(void)
{
    U8 mu8_low_water_flick_state = 0;

    if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
    {
        if( Bit5_Low_Water_Indicator == CLEAR )
        {
            Bit3_Front_New_Led_Low_Water_Text = SET;
        }
        else
        {
            mu8_low_water_flick_state = low_water_flickering_timer(3, 5);

            if( mu8_low_water_flick_state == SET )
            {
                Bit3_Front_New_Led_Low_Water_Text = SET;
            }
            else
            {
                Bit3_Front_New_Led_Low_Water_Text = CLEAR;
            }
        }
    }
    else
    {
        Bit3_Front_New_Led_Low_Water_Text = CLEAR;
    }
}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


