/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "ster_ice_tank.h"

void start_ice_tank_ster(void);
void stop_ice_tank_ster(void);
void ice_tank_ster_control(void);
void halt_ice_tank_ster(void);

void finish_ice_ster(void);
void skip_ice_ster(void);

U8 check_ice_ster_enable(void);
U8 prepare_ster(void);
U8 hot_circulation(void);

U8 hot_spray(void);
U8 overheat_circulation(void);
U8 lukewarm_spray(void);
U8 final_clean(void);
/////U8 ice_tank_ster_proc(void);
void init_ice_ster(void);
void periodic_ster(void);
void manual_disable_timer(void);
void hot_ster_temp_decision(void);
U8 prepare_melt_ice(void);
U8 melt_ice(void);
U8 wait_finish_clean(void);
U8 prepare_icetray_clean(void);
U8 icetray_clean(void);
void sel_start_temp(void);


/***********************************************************************************************************************/

TYPE_BYTE          U8SkipIceSterB;
#define            u8SkipIceSter                            U8SkipIceSterB.byte
#define            Bit0_Circulation_Hot_Skip_State          U8SkipIceSterB.Bit.b0
#define            Bit1_Hot_Spray_Skip_State                U8SkipIceSterB.Bit.b1
#define            Bit2_Lukewarm_Spray_Skip_State           U8SkipIceSterB.Bit.b2
#define            Bit3_Final_Clean_Skip_State              U8SkipIceSterB.Bit.b3
#define            Bit4_Ice_Tray_Clean_Skip_State           U8SkipIceSterB.Bit.b4
#define            Bit5_Melt_Ice_Skip_State                 U8SkipIceSterB.Bit.b5



/***********************************************************************************************************************/
U8 gu8_prepare_ster_step;
U16 gu16_prepare_ster_timer;
U16 gu16_prepare_ster_max_timer;

U8 gu8_hot_circulation_step;
U16 gu16_hot_circulation_timer;
U16 gu16_hot_circulation_max_timer;


U8 gu8_hot_spray_step;
U16 gu16_hot_spray_timer;
U16 gu16_hot_spray_max_timer;


U8 gu8_overheat_circul_step;
U16 gu16_overheat_circul_timer;

U8 gu8_lukewarm_spray_step;
U16 gu16_lukewarm_spray_timer;
U16 gu16_lukewarm_spray_max_timer;

U8 gu8_final_clean_step;
U16 gu16_final_clean_timer;
U16 gu16_final_clean_max_timer;

U8 gu8_ice_tray_prepare_step;
U16 gu16_ice_tray_prepare_timer;
U32 gu32_ice_tray_prepare_max_timer;

U8 gu8_ice_tray_clean_step;
U16 gu16_ice_tray_clean_timer;
U32 gu32_ice_tray_clean_max_timer;


U8 gu8_melt_ice_prepare_step;
U16 gu16_melt_ice_prepare_timer;
U32 gu32_melt_ice_prepare_max_timer;

U8 gu8_melt_ice_step;
U16 gu16_melt_ice_timer;
U32 gu32_melt_ice_max_timer;

U8 gu8_melt_ice_count;

U8 gu8_wait_finish_step;
U16 gu16_wait_finish_timer;
U16 gu16_wait_finish_max_timer;


U8 gu8_ice_tank_ster_step;
U16 gu16_ice_tank_ster_timer;

bit bit_ice_tank_ster_start;
U16 gu16_Ice_Tank_Ster_Hz;

/*..hui [23-2-28���� 7:53:51] steam off ������ �ӽ�..*/
bit bit_steam_off;


U16 gu16_steam_timer;

ICE_STER_MODE gu8_ice_ster_mode;
U16 gu16_ice_ster_op_timer;

bit bit_periodic_ster_enable;
bit bit_periodic_ster_first_display;

U8 gu8_wifi_period_ster_hour;
U8 gu8_wifi_period_ster_minute;


U8 gu8_ster_pump_stage;

U16 gu16_periodic_ster_time_total;
U16 gu16_periodic_ster_current_time_total;

U16 gu16_20_minute_before_ster;
U16 gu16_2_hour_before_ster;

bit bit_extract_stop_before_ster_start;

bit bit_periodic_ster_ready;

U16 gu16_ster_ready_max_timer;

U8 gu8_periodic_ster_count;
bit bit_ster_count_check;

U16 gu16_drain_fault_timer;


HOT_STER_OP_TEMP gu8_hot_ster_temp_mode;
U8 gu8_hot_ster_operation_temp;

bit bit_hot_ster_ice_full;
U8 gu8_ster_ice_extract_timer;
U8 gu8_ster_ice_extract_count;


U8 gu8_manual_operation_count;
U16 gu16_manual_minute;
U16 gu16_manual_hour;

bit bit_hot_ster_today;


U8 gu8_test_count;

bit bit_debug_skip_ice_ster;


U8 gu8_hot_spray_start_hot_temp;
U8 gu8_lukewarm_spray_start_hot_temp;
U8 gu8_final_clean_start_hot_temp;

U8 gu8_ice_tray_start_hot_temp;
U8 gu8_mlet_ice_start_hot_temp;


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void start_ice_tank_ster(void)
{
    bit_ice_tank_ster_start = SET;

    /*bit_extract_stop_before_ster_start = CLEAR;*/
    bit_periodic_ster_ready = CLEAR;

    gu8_steam_clean_percent = 0;
    gu16_drain_fault_timer = 0;

    init_ice_ster();

    #if 0
    /*..hui [23-8-29���� 10:10:01] � �����̴��� ���� ���� ���� �����̸� 75����..*/
    if( F_IceFull == SET )
    {
        gu8_hot_ster_temp_mode = HOT_STER_TEMP_HIGH_MODE;
    }
    else{}
    #endif

    /*..hui [23-9-7���� 3:59:14] �¼� ���� ������ ����..*/
    /*bit_extract_stop_before_ster_start = CLEAR;*/

    gu8_melt_ice_count = 0;

    u8SkipIceSter = 0;
    bit_debug_skip_ice_ster = CLEAR;

    /*..hui [24-5-28���� 3:23:42] ���̽� ���� ������ �ݴ´�....*/
    /*..hui [24-5-28���� 3:23:54] �����־��µ� �ƹ��� ��............. �ŷڼ����� �߰�..*/
    F_IceDoorClose = SET;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void stop_ice_tank_ster(void)
{
    bit_ice_tank_ster_start = CLEAR;

    bit_periodic_ster_ready = CLEAR;

    gu8_steam_clean_percent = 0;
    gu16_drain_fault_timer = 0;

    finish_ice_ster();

    /*..hui [23-8-28���� 4:36:23] ��ô �����ϸ� ���� �ʱ�ȭ..*/

    /*..hui [23-11-8���� 2:10:48] �����翡 ���� ���� ���� ����. ���� ������� ����..*/
    /*gu8_hot_ster_temp_mode = HOT_STER_TEMP_LOW_MODE;*/
    /*bit_hot_ster_ice_full = CLEAR;*/
    /*bit_extract_stop_before_ster_start = CLEAR;*/

    gu8_ster_ice_extract_timer = 0;
    gu8_ster_ice_extract_count = 0;

    /*..hui [23-9-7���� 3:59:14] �¼� ���� ������ ����..*/
    /*bit_extract_stop_before_ster_start = CLEAR;*/

    gu8_melt_ice_count = 0;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void ice_tank_ster_control(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_enable = 0;

    halt_ice_tank_ster();

    manual_disable_timer();

    sel_start_temp();

    switch( gu8_ice_ster_mode )
    {
        case STER_MODE_NONE_STATE:

            mu8_enable = check_ice_ster_enable();

            if( mu8_enable == SET )
            {
                gu8_ice_ster_mode = STER_MODE_PREPARE;
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step = 0;
            }
            else{}

        break;

        case STER_MODE_PREPARE:

            mu8_enable = prepare_ster();

            if( mu8_enable == SET )
            {
                gu8_ice_ster_mode = STER_MODE_CIRCULATION_HOT_STATE;
                gu16_hot_circulation_timer = 0;
                gu8_hot_circulation_step = 0;
            }
            else{}

        break;

        case STER_MODE_CIRCULATION_HOT_STATE:

            mu8_enable = hot_circulation();

            if( mu8_enable == SET )
            {
                gu8_ice_ster_mode = STER_MODE_HOT_SPRAY_STATE;
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step = 0;
            }
            else{}

        break;


        case STER_MODE_HOT_SPRAY_STATE:

            mu8_finish = hot_spray();

            if( mu8_finish == SET )
            {
                gu8_ice_ster_mode = STER_MODE_LUKEWARM_SPRAY_STATE;
                gu16_lukewarm_spray_timer = 0;
                gu8_lukewarm_spray_step = 0;
            }
            else{}

        break;

        case STER_MODE_LUKEWARM_SPRAY_STATE:

            mu8_finish = lukewarm_spray();

            if( mu8_finish == SET )
            {
                gu8_ice_ster_mode = STER_MODE_FINAL_CLEAN_STATE;
                gu16_final_clean_timer = 0;
                gu8_final_clean_step = 0;
            }
            else{}

        break;

        case STER_MODE_FINAL_CLEAN_STATE:

            mu8_finish = final_clean();

            if( mu8_finish == SET )
            {
                #if 0
                /*finish_ice_ster();*/
                gu8_ice_ster_mode = STER_MODE_MELT_ICE_PREPARE;
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step = 0;

                gu8_melt_ice_count = 0;
                #endif

                gu8_ice_ster_mode = STER_MODE_ICE_TRAY_CLEAN_PREPARE;
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step = 0;
            }
            else{}

        break;

        case STER_MODE_ICE_TRAY_CLEAN_PREPARE:

            mu8_finish = prepare_icetray_clean();

            if( mu8_finish == SET )
            {
                gu8_ice_ster_mode = STER_MODE_ICE_TRAY_CLEAN;
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step = 0;
            }
            else{}

        break;

        case STER_MODE_ICE_TRAY_CLEAN:

            mu8_finish = icetray_clean();

            if( mu8_finish == SET )
            {
                gu8_ice_ster_mode = STER_MODE_MELT_ICE_PREPARE;
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step = 0;

                gu8_melt_ice_count = 0;
            }
            else{}

        break;


        case STER_MODE_MELT_ICE_PREPARE:

            mu8_finish = prepare_melt_ice();

            if( mu8_finish == SET )
            {
                gu8_ice_ster_mode = STER_MODE_MELT_ICE;
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step = 0;
            }
            else{}

        break;


        case STER_MODE_MELT_ICE:

            mu8_finish = melt_ice();

            if( mu8_finish == SET )
            {
                gu8_melt_ice_count++;

                /*..hui [23-10-17���� 2:23:54] �����ϰ� 3ȸ �ݺ�..*/
                /*if( gu8_melt_ice_count >= ICE_MELT_OPERATION_COUNT )*/
                /*if( gu8_melt_ice_count >= gu8_test_count )*/
                /*..hui [23-10-23���� 1:53:39] 4ȸ ����..*/
                /*..hui [24-1-25���� 11:50:07] ���̽� Ʈ���� ��ô �߰��Ǹ鼭 3ȸ�� �ٽ� ����..*/
                if( gu8_melt_ice_count >= ICE_MELT_OPERATION_COUNT )
                {
                    gu8_ice_ster_mode = STER_MODE_FINISH;
                    gu8_melt_ice_count = 0;

                    gu8_wait_finish_step = 0;
                    gu16_wait_finish_timer = 0;
                    gu16_wait_finish_max_timer = 0;
                }
                else
                {
                    gu8_ice_ster_mode = STER_MODE_MELT_ICE_PREPARE;
                    gu16_melt_ice_prepare_timer = 0;
                    gu32_melt_ice_prepare_max_timer = 0;
                    gu8_melt_ice_prepare_step = 0;
                }
            }
            else{}

        break;

        case STER_MODE_FINISH:

            mu8_finish = wait_finish_clean();

            if( mu8_finish == SET )
            {
                finish_ice_ster();
            }
            else{}

        break;


        default:

            gu8_ice_ster_mode = STER_MODE_NONE_STATE;

        break;
    }
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void halt_ice_tank_ster(void)
{
    /*if( gu8_ice_ster_mode >= STER_MODE_HOT_SPRAY_STATE )*/
    if( gu8_ice_ster_mode >= STER_MODE_CIRCULATION_HOT_STATE )
    {
        if( gu8_Room_Water_Level == ROOM_LEVEL_LOW )
        {
            /*play_melody_warning_197();*/
            /*finish_ice_ster();*/
            /*..hui [24-1-31���� 5:32:20] �л��ϴٰ� ������ �����ɶ��� ���� �ܰ�� �̵��ϵ��� ����..*/
            /*..hui [24-1-31���� 5:32:33] ��¼�� �ѹ� �̰����� ��쿡�� ���� �����ϱ�����..*/
            skip_ice_ster();

            if( bit_debug_skip_ice_ster == CLEAR )
            {
                bit_debug_skip_ice_ster = SET;

                gu8_ice_ster_low_water_stop_count++;

                if( gu8_ice_ster_low_water_stop_count >= 99 )
                {
                    gu8_ice_ster_low_water_stop_count = 99;
                }
                else{}
            }
            else{}
        }
        else
        {
            bit_debug_skip_ice_ster = CLEAR;
        }

        if( Bit3_Ice_Tank_Ster_Operation_Disable_State == SET )
        {
            /*play_melody_warning_197();*/
            finish_ice_ster();
        }
        else{}

        if( F_Tank_Cover_Input == CLEAR )
        {
            play_melody_warning_197();
            finish_ice_ster();
        }
        else{}

        /*..hui [23-7-28���� 3:42:30] �߰��� ���̵�Ŀ��, RO ���� ���� �����Ǹ� ����..*/
        /*if( bit_filter_cover == CLEAR || bit_ro_filter_2_reed == CLEAR )*/
        if( bit_filter_all == CLEAR )
        {
            play_melody_warning_197();
            finish_ice_ster();
        }
        else{}

        /*..hui [23-8-28���� 9:38:31] �巹�� ���� ����(��������/�����̰���)�� ��� ��ô �ߴ�.. ����ȯ ����� ��û..*/
        if( u8DrainWaterLevel == DRAIN_LEVEL_ERROR )
        {
            gu16_drain_fault_timer++;

            /*if( gu16_drain_fault_timer >= 50 )*/
            /*if( gu16_drain_fault_timer >= 600 )*/
            /*..hui [24-2-19���� 5:09:36] 10�� ���� ����ϰ� ������������ ����..*/
            if( gu16_drain_fault_timer >= 6000 )
            {
                gu16_drain_fault_timer = 0;
                /*play_melody_warning_197();*/
                finish_ice_ster();

                gu8_ice_ster_drain_stop_count++;

                if( gu8_ice_ster_drain_stop_count >= 99 )
                {
                    gu8_ice_ster_drain_stop_count = 99;
                }
                else{}
            }
            else{}
        }
        else
        {
            gu16_drain_fault_timer = 0;
        }
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void finish_ice_ster(void)
{
    bit_ice_tank_ster_start = CLEAR;
    gu8_ice_ster_mode = STER_MODE_NONE_STATE;

    /*..hui [23-2-28���� 7:52:59] NIC������ �ӽ�.....*/
    ////bit_steam_off  = CLEAR;

    /*..hui [23-8-28���� 4:36:23] ��ô �����ϸ� ���� �ʱ�ȭ..*/
    /*gu8_hot_ster_temp_mode = HOT_STER_TEMP_LOW_MODE;*/
    /*bit_hot_ster_ice_full = CLEAR;*/

    init_ice_ster();

    /*..hui [23-5-22���� 7:08:41] Ʈ���� �ö��ִ� ���¸� Ʈ���� ����..*/
    /*if( gu8_ice_system_ok == SET && F_TrayMotorUP == CLEAR && gu8IceTrayLEV != ICE_TRAY_POSITION_ICE_THROW )*/
    if( gu8_ice_system_ok == SET && gu8IceTrayLEV != ICE_TRAY_POSITION_ICE_THROW )
    {
        down_tray_motor();
    }
    else{}

    /*..hui [23-9-7���� 3:59:14] �¼� ���� ������ ����..*/
    /*bit_extract_stop_before_ster_start = CLEAR;*/

    gu8_melt_ice_count = 0;

    /*..hui [23-11-6���� 9:11:27] ��ô �߰��� �ߴܵǰų� ������ ��������..*/
    F_IR = SET;

    u8SkipIceSter = 0;
    bit_debug_skip_ice_ster = CLEAR;

}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void skip_ice_ster(void)
{

    if( gu8_ice_ster_mode == STER_MODE_CIRCULATION_HOT_STATE )
    {
        if( Bit0_Circulation_Hot_Skip_State == CLEAR )
        {
            Bit0_Circulation_Hot_Skip_State = SET;

            gu16_hot_circulation_timer = 0;
            gu16_hot_circulation_max_timer = 0;
            gu8_hot_circulation_step = 4;
        }
        else{}
    }
    else if( gu8_ice_ster_mode == STER_MODE_HOT_SPRAY_STATE )
    {
        if( Bit1_Hot_Spray_Skip_State == CLEAR )
        {
            Bit1_Hot_Spray_Skip_State = SET;

            gu16_hot_spray_timer = 0;
            gu16_hot_spray_max_timer = 0;
            gu8_hot_spray_step = 11;
        }
        else{}
    }
    else if( gu8_ice_ster_mode == STER_MODE_LUKEWARM_SPRAY_STATE )
    {
        if( Bit2_Lukewarm_Spray_Skip_State == CLEAR )
        {
            Bit2_Lukewarm_Spray_Skip_State = SET;

            gu16_lukewarm_spray_timer = 0;
            gu16_lukewarm_spray_max_timer = 0;
            gu8_lukewarm_spray_step = 13;
        }
        else{}
    }
    else if( gu8_ice_ster_mode == STER_MODE_FINAL_CLEAN_STATE )
    {
        if( Bit3_Final_Clean_Skip_State == CLEAR )
        {
            Bit3_Final_Clean_Skip_State = SET;

            gu16_final_clean_timer = 0;
            gu16_final_clean_max_timer = 0;
            gu8_final_clean_step = 15;
        }
        else{}
    }
    else if( gu8_ice_ster_mode == STER_MODE_ICE_TRAY_CLEAN )
    {
        if( Bit4_Ice_Tray_Clean_Skip_State == CLEAR )
        {
            Bit4_Ice_Tray_Clean_Skip_State = SET;

            gu16_ice_tray_clean_timer = 0;
            gu32_ice_tray_clean_max_timer = 0;
            gu8_ice_tray_clean_step = 19;
        }
        else{}
    }
    else if( gu8_ice_ster_mode == STER_MODE_MELT_ICE )
    {
        if( Bit5_Melt_Ice_Skip_State == CLEAR )
        {
            Bit5_Melt_Ice_Skip_State = SET;

            gu16_melt_ice_timer = 0;
            gu32_melt_ice_max_timer = 0;
            gu8_melt_ice_step = 23;
        }
        else{}
    }
    else
    {
        u8SkipIceSter = 0;
    }

}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 check_ice_ster_enable(void)
{
    U8 mu8_return = 0;

    periodic_ster();

    if( bit_ice_tank_ster_start == SET )
    {
        mu8_return = SET;
    }
    else{}

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void periodic_ster(void)
{
    U8 mu8_a = 0;
    U8 mu8_b = 0;

    if( bit_periodic_ster_enable == CLEAR || bit_first_time_setting == CLEAR )
    {
        /*bit_extract_stop_before_ster_start = CLEAR;*/
        bit_periodic_ster_ready = CLEAR;
        gu16_ster_ready_max_timer = 0;
        bit_ster_count_check = CLEAR;
        /*gu8_periodic_ster_count = PERIODIC__STER_CYCLE;*/
        gu8_periodic_ster_count = FIRST_POWER_ON_PERIODIC__STER_CYCLE;

        gu8_ster_ice_extract_timer = 0;
        gu8_ster_ice_extract_count = 0;

        return;
    }
    else{}

    /*..hui [23-6-29���� 4:01:43] �ð�, �� �и��Ǹ� ��~~~~~~~~~~~~ �򰥷��� �����ؼ�....*/
    gu16_periodic_ster_current_time_total = (U16)((U16)gu8_rtc_time_Hour * 100);
    gu16_periodic_ster_current_time_total = gu16_periodic_ster_current_time_total + gu8_rtc_time_Min;

    gu16_periodic_ster_time_total = (U16)((U16)gu8_wifi_period_ster_hour * 100);
    gu16_periodic_ster_time_total = gu16_periodic_ster_time_total + gu8_wifi_period_ster_minute;


///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
    #if 0
    /*..hui [23-7-7���� 4:08:26] ���� 1�� �������� �����Ǹ�.. 12�� 00�� ~ 12�� 59�� ����..*/
    if( gu16_periodic_ster_time_total < 100 )
    {
        gu16_2_hour_before_ster = (U16)((U16)22 * 100);
        gu16_2_hour_before_ster = gu16_2_hour_before_ster + gu8_wifi_period_ster_minute;
    }
    else if( gu16_periodic_ster_time_total < 200 )
    {
        /*..hui [23-8-28���� 10:51:04] ���� 1�� ���ĺ��� ���� 2�� �������� �����Ǹ�.. 1�� 00�� ~ 1�� 59��..*/
        gu16_2_hour_before_ster = (U16)((U16)23 * 100);
        gu16_2_hour_before_ster = gu16_2_hour_before_ster + gu8_wifi_period_ster_minute;
    }
    else
    {
        /*..hui [23-8-28���� 9:53:36] 2�ð� ��..*/
        gu16_2_hour_before_ster = gu16_periodic_ster_time_total - 200;
    }
    #endif

    #if 0
    if( gu8_periodic_ster_count >= (PERIODIC__STER_CYCLE - 1) )
    {
        /*..hui [23-9-6���� 3:31:40] ���¼�ô �ϴ³�..*/
        bit_hot_ster_today = SET;
    }
    else
    {
        bit_hot_ster_today = CLEAR;
    }
    #endif


    #if 0
    if( bit_hot_ster_today == SET )
    {
        /*..hui [23-8-28���� 4:30:51] ��ô ���� 2�ð� ���� �������� Ȯ��..*/
        if( gu16_periodic_ster_current_time_total == gu16_2_hour_before_ster )
        {
            /*..hui [23-8-28���� 11:06:21] ��ô ���� 2�ð� ���� 1�е��� ���� �������� Ȯ��..*/
            /*..hui [23-8-28���� 11:14:43] ��ô�ϴ³� ���Ͽ���..*/
            if( F_IceFull == SET )
            {
                bit_hot_ster_ice_full = SET;
            }
            else
            {
                bit_hot_ster_ice_full = CLEAR;
            }
        }
        else
        {
            if( bit_hot_ster_ice_full == SET )
            {
                if( F_Ice == SET )
                {
                    gu8_ster_ice_extract_timer++;

                    /*..hui [23-8-28���� 11:11:59] ������ ���¿��� ������ 7�� �̻� �����߰ų�..*/
                    /*..hui [23-8-28���� 11:12:10] 7�ʰ� �ȵǴ��� ������ 2ȸ �̻� �������� ���..*/
                    /*if( gu8_ster_ice_extract_timer >= 70 || gu8_ster_ice_extract_count >= 2 )*/
                    /*..hui [23-9-6���� 5:00:10] 3ȸ�� �켱 ����..*/
                    /*if( gu8_ster_ice_extract_timer >= 80 || gu8_ster_ice_extract_count >= 3 )*/
                    if( gu8_ster_ice_extract_timer >= 80 )
                    {
                        gu8_ster_ice_extract_timer = 80;
                        bit_hot_ster_ice_full = CLEAR;
                    }
                    else{}
                }
                else
                {
                    /*..hui [23-9-6���� 5:05:26] 8�� �̸� ���������� 3�� �̻� ���� Ƚ���� 3ȸ �̻��� ���..*/
                    if( gu8_ster_ice_extract_timer >= 30 )
                    {
                        gu8_ster_ice_extract_count++;

                        if( gu8_ster_ice_extract_count >= 3 )
                        {
                            gu8_ster_ice_extract_count = 0;
                            bit_hot_ster_ice_full = CLEAR;
                        }
                        else{}
                    }
                    else{}

                    gu8_ster_ice_extract_timer = 0;
                }
            }
            else
            {
                gu8_ster_ice_extract_timer = 0;
                gu8_ster_ice_extract_count = 0;
            }
        }
    }
    else
    {
        bit_hot_ster_ice_full = CLEAR;
        gu8_ster_ice_extract_timer = 0;
        gu8_ster_ice_extract_count = 0;
    }
    #endif
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
    #if 0
    /*..hui [23-8-28���� 10:54:17] ���� 12�� 20�� �������� �����Ǹ�.. 12�� 00�� ~ 12�� 20��..*/
    if( gu16_periodic_ster_time_total < 20 )
    {
        gu16_20_minute_before_ster = (U16)((U16)23 * 100);

        mu8_b = gu8_wifi_period_ster_minute + 40;

        gu16_20_minute_before_ster = gu16_20_minute_before_ster + mu8_b;
    }
    else
    {
        /*..hui [23-8-28���� 10:55:51] 20�� ��..*/
        if( gu8_wifi_period_ster_minute < 20 )
        {
            mu8_b = gu8_wifi_period_ster_minute + 40;

            if( gu8_wifi_period_ster_hour == 0 )
            {
                gu16_20_minute_before_ster = (U16)((U16)23 * 100);
                gu16_20_minute_before_ster = gu16_20_minute_before_ster + mu8_b;
            }
            else
            {
                gu16_20_minute_before_ster = (U16)(((U16)gu8_wifi_period_ster_hour - 1) * 100);
                gu16_20_minute_before_ster = gu16_20_minute_before_ster + mu8_b;
            }
        }
        else
        {
            gu16_20_minute_before_ster = gu16_periodic_ster_time_total - 20;
        }
    }

    if( bit_hot_ster_today == SET )
    {
        if( gu16_periodic_ster_current_time_total == gu16_20_minute_before_ster )
        {
            /*..hui [23-7-7���� 4:27:56] 1�ð� �� ���� ������ ��������.. �Ѳ� ������.. �¼� ������������..*/
            /*..hui [23-10-4���� 2:42:31] ����/�ü� �µ��� 15�� ������ ��쿡��.. 15�� ������ ������ ���ϱ⶧����..*/
            if( Bit3_Ice_Tank_Ster_Operation_Disable_State == CLEAR
                && F_Tank_Cover_Input == SET
                /*&& bit_filter_cover == SET && bit_ro_filter_2_reed == SET*/
                && bit_filter_all == SET
                /*..hui [23-10-5���� 9:37:34] ������ �Ⱥ��� �ü��� Ȯ���ϱ��.. ����ȯ �����..*/
                /*&& gu8_Room_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP*/
                && gu8_Cold_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP
                && F_Hot_Enable == CLEAR )
                /*&& gu8_periodic_ster_count >= (PERIODIC__STER_CYCLE - 1) )*/
            {
                bit_extract_stop_before_ster_start = SET;
            }
            else
            {
                bit_extract_stop_before_ster_start = CLEAR;
            }
        }
        else
        {
            /*..hui [23-8-28���� 11:28:44] 20�� ������ �¼� �Ѹ�..?? �켱 ����..*/
            if( F_Hot_Enable == SET )
            {
                bit_extract_stop_before_ster_start = CLEAR;
            }
            else{}

            /*..hui [23-9-7���� 4:04:28] �����ϴ� ���� ��ô �Ұ� ���� �߻�������.. ���� ��� �ߴ�..*/
            /*..hui [23-9-7���� 4:04:52] ����Ŀ�� ���� -> ���� �̾ �ѹ� ���������� �׳� ��һ��� ����..*/
            /*..hui [23-9-7���� 4:05:05] 20���Ŀ� � ���°� ���� �˼����� ������.....*/
            /*..hui [23-10-4���� 2:43:52] �ü�/���� �µ� 15�� �ʰ��̸� �¼� OFF�� ������ �ߴ�....*/
            if( Bit3_Ice_Tank_Ster_Operation_Disable_State == SET
                || F_Tank_Cover_Input == CLEAR
                /*|| bit_filter_cover == CLEAR || bit_ro_filter_2_reed == CLEAR )*/
                || bit_filter_all == CLEAR
                /*|| gu8_Room_Temperature_One_Degree > STER_NO_OPERATION_COLD_TEMP*/
                || gu8_Cold_Temperature_One_Degree > STER_NO_OPERATION_COLD_TEMP )
            {
                bit_extract_stop_before_ster_start = CLEAR;
            }
            else{}
        }
    }
    else
    {
        /*..hui [23-9-7���� 3:56:29] ��ô ���ϴ³��� �ʱ�ȭ..*/
        bit_extract_stop_before_ster_start = CLEAR;
    }
    #endif

#if 0
0000 ��սð�
2340 20����

0019 ��սð�
2359 20����

0100 ��սð�
0040 20����

0010 ��սð�
2350 20����


1830 ��սð�
1810 20����


1305 ��սð�
1245 20����

20���� �ð��� ���� �ð����� ũ��???????


����ð��� ��� �ð� 20�к��� �۰�????
����ð��� ��� �ð����� ũ��?????


########
����ð��� ��� �ð� 20�к��� ũ��
����ð��� ��� �ð� ���� ������
��������
########
#endif




///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
    if( gu16_periodic_ster_current_time_total == gu16_periodic_ster_time_total )
    {
        if( bit_ster_count_check == CLEAR )
        {
            bit_ster_count_check = SET;

            gu8_periodic_ster_count++;

            if( gu8_periodic_ster_count >= PERIODIC__STER_CYCLE )
            {
                gu8_periodic_ster_count = PERIODIC__STER_CYCLE;
            }
            else{}
        }
        else{}

        /*..hui [23-7-7���� 4:27:56] ��������.. �Ѳ� ������.. �¼� ������������..*/
        /*..hui [23-10-4���� 2:39:55] ���� / �ü� �µ� �� �� 15�� �����϶��� ��ô ����..*/
        if( Bit3_Ice_Tank_Ster_Operation_Disable_State == CLEAR
            && F_Tank_Cover_Input == SET
            && bit_filter_all == SET
            /*&& F_Hot_Enable == SET*/
            /*&& gu8_Cold_Temperature_One_Degree < STER_NO_OPERATION_COLD_TEMP*/
            /*..hui [23-10-5���� 9:37:34] ������ �Ⱥ��� �ü��� Ȯ���ϱ��.. ����ȯ �����..*/
            /*&& gu8_Room_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP*/
            && gu8_Cold_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP
            && gu8_periodic_ster_count >= PERIODIC__STER_CYCLE )
        {
            bit_periodic_ster_ready = SET;
        }
        else{}
    }
    else
    {
        bit_ster_count_check = CLEAR;
    }


    if( bit_periodic_ster_ready == SET )
    {
        /*..hui [24-7-29���� 2:51:38] ������ ���� �� ���� ����..*/
        if( Bit3_Ice_Tank_Ster_Operation_Disable_State == CLEAR
            && F_Tank_Cover_Input == SET
            && bit_filter_all == SET
            /*&& gu8_Hot_Tank_Temperature_One_Degree >= HOT_SPRAY_STATE_START_HOT_TEMP*/
            /*&& gu8_Cold_Temperature_One_Degree < STER_NO_OPERATION_COLD_TEMP*/
            /*..hui [23-10-5���� 9:37:34] ������ �Ⱥ��� �ü��� Ȯ���ϱ��.. ����ȯ �����..*/
            /*&& gu8_Room_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP*/
            && gu8_Cold_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP
            && gu8_Room_Water_Level == ROOM_LEVEL_FULL
            && bit_self_test_start == CLEAR
            && bit_acid_clean_start == CLEAR )
        {
            /*hot_ster_temp_decision();*/
            start_ice_tank_ster();

            /*..hui [23-7-13���� 9:42:19] ���� ��� �����ϹǷ� ����Ŭ Ƚ�� �ʱ�ȭ..*/
            /*..hui [23-7-13���� 9:42:52] �ð��ƴµ� ��� ���ϴ� �����̸�.. ������.. �� ������.. �� �Ϸ羿 �и�..*/
            if( gu8_periodic_ster_count >= PERIODIC__STER_CYCLE )
            {
                gu8_periodic_ster_count = 0;
            }
            else{}
        }
        else
        {
            gu16_ster_ready_max_timer++;

            /*..hui [23-7-7���� 4:26:42] 1�ð����� ������, �¼� �µ� �� ���߸� �� ��..*/
            /*if( gu16_ster_ready_max_timer >= 36000 )*/
            /*..hui [23-8-28���� 11:31:55] 2������ ����.. ����ȯ �����..*/
            /*if( gu16_ster_ready_max_timer >= 1200 )*/
            /*..hui [23-8-29���� 2:38:34] 5������ ����..*/
            if( gu16_ster_ready_max_timer >= 3000 )
            {
                gu16_ster_ready_max_timer = 0;
                stop_ice_tank_ster();
            }
            else{}
        }
    }
    else
    {
        gu16_ster_ready_max_timer = 0;
    }


}



/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 prepare_ster(void)
{
    U8 mu8_return = 0;

    switch( gu8_prepare_ster_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:39:52] ���..*/
            gu16_prepare_ster_timer++;

            if( gu16_prepare_ster_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step++;
            }
            else{}

            break;

        case 1:

            gu8_cody_take_off_ice_start = SET;
            gu16_prepare_ster_timer = 0;
            gu16_prepare_ster_max_timer = 0;
            gu8_prepare_ster_step++;

            break;

        case 2:

            /*..hui [23-9-18���� 5:25:23] �ü� �ͽ� ���� ����..*/
            #if 0
            if( gu8_hot_flow_status != HOT_FLOW_MAX_CLOSE )
            {
                run_init_flow();
            }
            else{}
            #endif

            gu16_prepare_ster_timer = 0;
            gu16_prepare_ster_max_timer = 0;
            gu8_prepare_ster_step++;

            break;

        case 3:

            /*..hui [23-9-18���� 5:25:23] �ü� �ͽ� ���� ����..*/
            #if 0
            if( gu8_hot_flow_status == HOT_FLOW_MAX_CLOSE )
            {
                gu16_prepare_ster_timer = 0;
                gu8_prepare_ster_step++;
            }
            else{}
            #endif

            gu16_prepare_ster_timer = 0;
            gu16_prepare_ster_max_timer = 0;
            gu8_prepare_ster_step++;

            break;

        case 4:

            if( gu8IceStep == STATE_0_STANDBY )
            {
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step++;
            }
            else
            {
                // ���߿� Ÿ�̸� �ִ�ð� �߰�
                /*..hui [23-5-22���� 11:15:23] �ִ� ���ѽð��� �ְ��� �ִ� �ð� + 2������..*/
                gu16_prepare_ster_timer++;

                if( gu16_prepare_ster_timer >= HOT_GAS_TIME_9_UNDER_765S + 1200 )
                {
                    gu16_prepare_ster_timer = 0;
                    gu16_prepare_ster_max_timer = 0;
                    gu8_prepare_ster_step++;
                }
                else{}
            }

            break;

        case 5:

            if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY )
            {
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step++;
            }
            else
            {
                /*..hui [23-5-22���� 11:38:20] �巹�� ��� �ִ� �ð��� �켱 5������..*/
                gu16_prepare_ster_timer++;

                if( gu16_prepare_ster_timer >= 3000 )
                {
                    gu16_prepare_ster_timer = 0;
                    gu16_prepare_ster_max_timer = 0;
                    gu8_prepare_ster_step++;
                }
                else{}
            }

            break;

        case 6:

            /*..hui [23-11-8���� 3:38:12] �¼���ô ���� �¼��µ� ���� �߰�..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= 80 )*/
            /*..hui [23-11-17���� 4:42:45] ����ȯ ����� ��û....*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= 85 )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= 93 )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= HOT_SPRAY_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree >= gu8_hot_spray_start_hot_temp )
            {
                gu16_prepare_ster_timer++;

                if( gu16_prepare_ster_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_prepare_ster_timer = 0;
                    gu16_prepare_ster_max_timer = 0;
                    gu8_prepare_ster_step++;
                }
                else{}
            }
            else
            {
                gu16_prepare_ster_max_timer++;

                /*..hui [23-11-8���� 3:45:01] �¼� ���� �ִ� �ð��� 30��..*/
                if( gu16_prepare_ster_max_timer >= 18000 )
                {
                    gu16_prepare_ster_timer = 0;
                    gu16_prepare_ster_max_timer = 0;
                    gu8_prepare_ster_step++;
                }
                else{}
            }

            break;

        case 7:

            gu16_prepare_ster_timer++;

            /*..hui [23-10-12���� 5:27:16] 10�� ���� �ü� �巹�� ��� OPEN..*/
            /*..hui [23-10-12���� 5:28:10] �����Ʈ ��굵 �Ѿ���..*/
            /*..hui [23-10-17���� 9:58:01] 15�ʷ� ����..*/
            /*if( gu16_prepare_ster_timer >= 150 )*/
            /*..hui [24-1-29���� 12:02:37] 15�� �巹�� ����..*/
            if( gu16_prepare_ster_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step++;
            }
            else{}

            break;


        case 8:

            if( bit_flushing_water_start == CLEAR )
            {
                gu16_prepare_ster_timer = 0;
                gu16_prepare_ster_max_timer = 0;
                gu8_prepare_ster_step++;
            }
            else
            {
                /*..hui [23-8-24���� 9:21:30] ���� �÷��� �ִ� ���ð� 3��..*/
                gu16_prepare_ster_timer++;

                if( gu16_prepare_ster_timer >= 1800 )
                {
                    gu16_prepare_ster_timer = 0;
                    gu16_prepare_ster_max_timer = 0;
                    gu8_prepare_ster_step++;
                }
                else{}
            }

            break;

        case 9:

            gu16_prepare_ster_timer = 0;
            gu16_prepare_ster_max_timer = 0;
            gu8_prepare_ster_step = 0;

            /*..hui [23-5-22���� 11:39:04] ��� �غ��۾� ����..*/
            mu8_return = SET;

            break;

        default:

            gu16_prepare_ster_timer = 0;
            gu16_prepare_ster_max_timer = 0;
            gu8_prepare_ster_step = 0;

        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 hot_circulation(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_ble_ap_mode = 0;

    switch( gu8_hot_circulation_step )
    {
        case 0:

            gu16_hot_circulation_timer++;

            if( gu16_hot_circulation_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_circulation_timer = 0;
                gu8_hot_circulation_step++;
            }
            else{}

            break;

        case 1:

            /*..hui [23-2-28���� 6:54:26] ��ġ �ǵ��� 2 ON..*/
            gu16_hot_circulation_timer++;

            if( gu16_hot_circulation_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_circulation_timer = 0;
                gu8_hot_circulation_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-8-11���� 1:59:11] �������� NOS ��� 5-3 OFF ���� ����..*/
            /*..hui [23-8-11���� 1:59:23] �¼� �Լ� �ǵ��� 6-2 ON..*/
            gu16_hot_circulation_timer++;

            if( gu16_hot_circulation_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_circulation_timer = 0;
                gu16_hot_circulation_max_timer = 0;

                /*..hui [23-8-11���� 2:13:55] ���ؿµ� �����̸� ���� �������� �ʰ� �н�..*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= HOT_SPRAY_STATE_START_HOT_TEMP + 1 )*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_ster_operation_temp + 1 )*/
                /*..hui [23-10-12���� 5:23:28] 45�� ����, 75�� ���� �� �� 75����..*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= HOT_SPRAY_STATE_START_HOT_TEMP + 1 )*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= HOT_SPRAY_STATE_START_HOT_TEMP )*/
                if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_spray_start_hot_temp )
                {
                    gu8_hot_circulation_step = 4;
                }
                else
                {
                    gu8_hot_circulation_step++;
                }
            }
            else{}

            break;

        case 3:

            /*..hui [23-8-11���� 2:02:06] Ʈ���� ���� ����.. �¼� �µ� ���⶧����..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= HOT_SPRAY_STATE_START_HOT_TEMP )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_ster_operation_temp )*/
            /*..hui [23-10-12���� 5:24:09] 45�� ���ǵ� 75����.. ��� hot spray�� ª��..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= HOT_SPRAY_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_spray_start_hot_temp )
            {
                gu16_hot_circulation_timer++;

                if( gu16_hot_circulation_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_hot_circulation_timer = 0;
                    gu16_hot_circulation_max_timer = 0;
                    gu8_hot_circulation_step++;
                }
                else{}
            }
            else
            {
                gu16_hot_circulation_max_timer++;

                /*..hui [23-8-11���� 2:06:34] �켱 �ִ� 3������..*/
                /*..hui [23-8-11���� 5:31:02] ���� ���� 1�д� �뷫 260cc == 2���̸� 520cc == �¼� 1������ ����..*/
                /*..hui [23-8-24���� 3:04:50] 3������ ����.. ����ȯ�����..*/
                /*..hui [23-11-3���� 10:31:39] ���� �¼� ��ȯ�ÿ��� 5������.. 3���̳��� �¼� �ȶ�����..*/
                /*..hui [23-11-3���� 10:32:09] �������� 3�� ����..*/
                /*if( gu16_hot_circulation_max_timer >= HOT_CIRCULATION_MAX_TIME + 1200 )*/
                /*..hui [24-1-31���� 10:10:40] �µ� ���̱����� ��ȯ �ּ�ȭ.. 10��..*/
                if( gu16_hot_circulation_max_timer >= HOT_CIRCULATION_MAX_TIME )
                {
                    gu16_hot_circulation_timer = 0;
                    gu16_hot_circulation_max_timer = 0;
                    gu8_hot_circulation_step++;
                }
                else{}
            }

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            break;

        case 4:

            /*..hui [23-8-11���� 2:07:49] ���� ����.. �µ� ���� ����..*/
            gu16_hot_circulation_timer++;

            if( gu16_hot_circulation_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_circulation_timer = 0;
                gu8_hot_circulation_step++;
            }
            else{}

            break;

        case 5:

            /*..hui [23-8-11���� 2:09:27] ���¼�ô 6-2���� ON ���� ����..*/
            /*..hui [23-8-11���� 2:09:47] ��������NOS 5-3�� OFF ���� ���¿��� �����ܰ� ����..*/
            gu16_hot_circulation_timer = 0;
            gu8_hot_circulation_step = 0;

            /*..hui [23-5-15���� 7:43:06] 1�� ���� �л� ����..*/
            mu8_return = SET;

            break;

        default:

            gu16_hot_circulation_timer = 0;
            gu8_hot_circulation_step = 0;

        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 hot_spray(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_ble_ap_mode = 0;

    switch( gu8_hot_spray_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:39:52] ���..*/
            /*..hui [23-8-11���� 4:35:09] ��ġ �ǵ��� 2 / �¼� �Լ� �ǵ��� 6-2 ON ���¿��� ����..*/
            /*..hui [23-8-11���� 4:35:19] �������� NOS�� ��� OFF ����..*/
            gu16_hot_spray_timer++;

            if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 1:

            /*..hui [23-2-28���� 6:54:26] ��ġ �ǵ��� 2 ON..*/
            gu16_hot_spray_timer++;

            if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-2-28���� 6:55:35] �������� NOS ��� 5-3 ON..*/
            /*..hui [23-5-15���� 7:12:33] Ʈ���� �Լ� ��� 6-1 OFF..*/
            /*..hui [23-2-28���� 6:55:56] �¼� �Լ� �ǵ��� 6-2 ON..*/
            gu16_hot_spray_timer++;

            if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 3:

            /*..hui [23-5-15���� 7:15:25] ��� �ǵ� 5-1 ON..*/
            gu16_hot_spray_timer++;

            if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 4:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-1�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_hot_spray_timer++;
            }
            else
            {
                gu16_hot_spray_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_hot_spray_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else{}
            }

            /*..hui [23-11-8���� 2:10:48] �����翡 ���� ���� ���� ����. ���� ������� ����..*/
            /*if( gu16_hot_spray_timer >= 300 )*/
            if( gu16_hot_spray_timer >= 250 )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;


            #if 0
            /*if( gu16_hot_spray_timer <= 220 )*/
            if( gu16_hot_spray_timer <= 200 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 5:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_hot_spray_timer++;

            /*if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_hot_spray_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 6:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorDOWN == CLEAR )
                {
                    /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                    up_tray_motor();
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else
                {
                    gu16_hot_spray_timer++;

                    if( gu16_hot_spray_timer >= 600 )
                    {
                        gu16_hot_spray_timer = 0;
                        gu16_hot_spray_max_timer = 0;
                        gu8_hot_spray_step = 8;
                    }
                    else{}
                }
            }
            else
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step = 8;
            }

            break;

        case 7:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else
            {
                gu16_hot_spray_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_hot_spray_timer >= 600 )
                {
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else{}
            }

            break;

        case 8:

            /*..hui [23-5-15���� 7:17:17] ��� �ǵ� 5-1 OFF..*/
            /*..hui [23-5-15���� 7:17:02] ��� �ǵ� 5-2 ON..*/
            gu16_hot_spray_timer++;

            if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 9:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-2�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_hot_spray_timer++;
            }
            else
            {
                gu16_hot_spray_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_hot_spray_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else{}
            }

            /*..hui [23-11-8���� 2:10:48] �����翡 ���� ���� ���� ����. ���� ������� ����..*/
            /*if( gu16_hot_spray_timer >= 250 )*/
            if( gu16_hot_spray_timer >= 200 )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;


            #if 0
            /*if( gu16_hot_spray_timer <= 170 )*/
            if( gu16_hot_spray_timer <= 150 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 10:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_hot_spray_timer++;

            /*if( gu16_hot_spray_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_hot_spray_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else{}

            break;

        case 11:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorUP == CLEAR )
                {
                    /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
                    down_tray_motor();
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else
                {
                    gu16_hot_spray_timer++;

                    if( gu16_hot_spray_timer >= 600 )
                    {
                        gu16_hot_spray_timer = 0;
                        gu16_hot_spray_max_timer = 0;
                        gu8_hot_spray_step = 13;
                    }
                    else{}
                }
            }
            else
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step = 13;
            }

            break;

        case 12:

            /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_THROW )
            {
                gu16_hot_spray_timer = 0;
                gu16_hot_spray_max_timer = 0;
                gu8_hot_spray_step++;
            }
            else
            {
                gu16_hot_spray_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_hot_spray_timer >= 600 )
                {
                    gu16_hot_spray_timer = 0;
                    gu16_hot_spray_max_timer = 0;
                    gu8_hot_spray_step++;
                }
                else{}
            }

            break;


        case 13:

            /*..hui [23-5-22���� 3:58:02] ��� 5-2 OFF..*/
            gu16_hot_spray_timer = 0;
            gu16_hot_spray_max_timer = 0;
            gu8_hot_spray_step = 0;

            /*..hui [23-5-15���� 7:43:06] 1�� ���� �л� ����..*/
            mu8_return = SET;

            break;

        default:

            gu16_hot_spray_timer = 0;
            gu16_hot_spray_max_timer = 0;
            gu8_hot_spray_step = 0;

        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 overheat_circulation(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;
    U8 mu8_ble_ap_mode = 0;

    #if 0
    switch( gu8_overheat_circul_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:45:48] 5-1 OFF / 5-2 OFF / 5-3 ON / 6-1 OFF / 6-2 ON / PUMP OFF / 2 ON ���¿��� ����..*/
            gu16_overheat_circul_timer++;

            if( gu16_overheat_circul_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_overheat_circul_timer = 0;
                gu8_overheat_circul_step++;
            }
            else{}

            break;

        case 1:

            /*..hui [23-5-15���� 7:46:17] NOS ��� 5-3 OFF..*/
            gu16_overheat_circul_timer++;

            if( gu16_overheat_circul_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_overheat_circul_timer = 0;
                gu8_overheat_circul_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-5-15���� 7:47:07] Ʈ���� ���� ����.. �¼� �������� ��ȯ ����..*/
            gu16_overheat_circul_timer++;

            if( gu16_overheat_circul_timer >= 200 )
            {
                gu16_overheat_circul_timer = 0;
                gu8_overheat_circul_step++;
            }
            else{}


            break;

        case 3:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_overheat_circul_timer++;

            if( gu16_overheat_circul_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_overheat_circul_timer = 0;
                gu8_overheat_circul_step++;
            }
            else{}

            break;

        case 4:

            /*..hui [23-5-22���� 3:17:06] NOS ��� ON..*/
            gu16_overheat_circul_timer = 0;
            gu8_overheat_circul_step = 0;

            /*..hui [23-5-15���� 7:48:11] 2�� �������� ��ȯ ����..*/
            mu8_return = SET;

            break;

        default:

            gu16_overheat_circul_timer = 0;
            gu8_overheat_circul_step = 0;

        break;

    }
    #endif

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 lukewarm_spray(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;

    switch( gu8_lukewarm_spray_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:45:48] 5-1 OFF / 5-2 OFF / 5-3 ON / 6-1 OFF / 6-2 ON / PUMP OFF / 2 ON ���¿��� ����..*/
            /*..hui [23-7-5���� 7:42:27] Ʈ���� Ż�� ���� ���¿��� ����..*/
            gu16_lukewarm_spray_timer++;

            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                /*..hui [23-8-24���� 4:30:40] ���ؿµ� 55�� ������ ��쿡�� NOS 5-3 OFF ���¿��� �ٷ� 5-2 �Ѱ�..*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= LUKEWARM_STATE_START_HOT_TEMP )*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_ster_operation_temp )*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= LUKEWARM_STATE_START_HOT_TEMP )*/
                if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_lukewarm_spray_start_hot_temp )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step = 5;
                }
                else
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
            }
            else{}

            break;

        case 1:

            /*..hui [23-8-24���� 4:17:47] �������� NOS 5-3 OFF..*/
            gu16_lukewarm_spray_timer++;

            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-8-24���� 4:18:24] �µ� ������������ ���� ����..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= LUKEWARM_STATE_START_HOT_TEMP )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_ster_operation_temp )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= LUKEWARM_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_lukewarm_spray_start_hot_temp )
            {
                gu16_lukewarm_spray_timer++;

                if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }
            else
            {
                gu16_lukewarm_spray_max_timer++;

                /*..hui [23-8-11���� 2:06:34] �켱 �ִ� 3������..*/
                /*..hui [23-8-11���� 5:31:02] ���� ���� 1�д� �뷫 260cc == 2���̸� 520cc == �¼� 1������ ����..*/
                /*..hui [23-8-24���� 3:04:50] 3������ ����.. ����ȯ�����..*/
                if( gu16_lukewarm_spray_max_timer >= HOT_CIRCULATION_MAX_TIME )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            break;

        case 3:

            /*..hui [23-8-24���� 4:25:38] ���� ����. .�������� ��ȯ ����..*/
            gu16_lukewarm_spray_timer++;

            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            break;

        case 4:

            gu16_lukewarm_spray_timer++;

            /*..hui [23-8-24���� 4:26:46] �������� NOS 5-3 ON..*/
            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            break;

        case 5:

            /*..hui [23-5-15���� 7:50:38] ��� �ǵ� 5-1 ON..*/
            gu16_lukewarm_spray_timer++;

            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            break;

        case 6:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-1�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_lukewarm_spray_timer++;
            }
            else
            {
                gu16_lukewarm_spray_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_lukewarm_spray_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }

            /*if( gu16_lukewarm_spray_timer >= 250 )*/
            if( gu16_lukewarm_spray_timer >= 200 )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            #if 0
            /*if( gu16_lukewarm_spray_timer <= 170 )*/
            if( gu16_lukewarm_spray_timer <= 150 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 7:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_lukewarm_spray_timer++;

            /*if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}


            break;

        case 8:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorDOWN == CLEAR )
                {
                    /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                    up_tray_motor();
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else
                {
                    gu16_lukewarm_spray_timer++;

                    if( gu16_lukewarm_spray_timer >= 600 )
                    {
                        gu16_lukewarm_spray_timer = 0;
                        gu16_lukewarm_spray_max_timer = 0;
                        gu8_lukewarm_spray_step = 10;
                    }
                    else{}
                }
            }
            else
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step = 10;
            }


            break;

        case 9:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else
            {
                gu16_lukewarm_spray_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_lukewarm_spray_timer >= 600 )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }

            break;

        case 10:

            /*..hui [23-5-15���� 7:17:17] ��� �ǵ� 5-1 OFF..*/
            /*..hui [23-5-15���� 7:17:02] ��� �ǵ� 5-2 ON..*/
            gu16_lukewarm_spray_timer++;

            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}


            break;

        case 11:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-2�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_lukewarm_spray_timer++;
            }
            else
            {
                gu16_lukewarm_spray_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_lukewarm_spray_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }

            /*if( gu16_lukewarm_spray_timer >= 250 )*/
            if( gu16_lukewarm_spray_timer >= 200 )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            #if 0
            /*if( gu16_lukewarm_spray_timer <= 170 )*/
            if( gu16_lukewarm_spray_timer <= 150 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 12:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_lukewarm_spray_timer++;

            /*if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_lukewarm_spray_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else{}


            break;

        case 13:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorUP == CLEAR )
                {
                    /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
                    down_tray_motor();
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else
                {
                    gu16_lukewarm_spray_timer++;

                    if( gu16_lukewarm_spray_timer >= 600 )
                    {
                        gu16_lukewarm_spray_timer = 0;
                        gu16_lukewarm_spray_max_timer = 0;
                        gu8_lukewarm_spray_step = 15;
                    }
                    else{}
                }
            }
            else
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step = 15;
            }

            break;

        case 14:

            /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_THROW )
            {
                gu16_lukewarm_spray_timer = 0;
                gu16_lukewarm_spray_max_timer = 0;
                gu8_lukewarm_spray_step++;
            }
            else
            {
                gu16_lukewarm_spray_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_lukewarm_spray_timer >= 600 )
                {
                    gu16_lukewarm_spray_timer = 0;
                    gu16_lukewarm_spray_max_timer = 0;
                    gu8_lukewarm_spray_step++;
                }
                else{}
            }

            break;

        case 15:

            /*..hui [23-5-22���� 3:56:19] ��� 5-2 OFF..*/
            gu16_lukewarm_spray_timer = 0;
            gu16_lukewarm_spray_max_timer = 0;
            gu8_lukewarm_spray_step = 0;

            /*..hui [23-5-15���� 7:52:03] 3�� �̿¼� ��ô ����..*/
            mu8_return = SET;

            break;

        default:

            gu16_lukewarm_spray_timer = 0;
            gu16_lukewarm_spray_max_timer = 0;
            gu8_lukewarm_spray_step = 0;


        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 final_clean(void)
{
    U8 mu8_return = 0;
    U8 mu8_finish = 0;

    switch( gu8_final_clean_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:45:48] 5-1 OFF / 5-2 OFF / 5-3 ON / 6-1 OFF / 6-2 ON / PUMP OFF / 2 ON ���¿��� ����..*/
            /*..hui [23-7-5���� 7:46:26] Ż�� ��ġ���� ����..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                /*gu8_hot_ster_operation_temp = FINAL_CLEAN_STATE_START_HOT_TEMP;*/

                /*..hui [23-8-24���� 4:30:40] ���ؿµ� 45�� ������ ��쿡�� NOS 5-3 OFF ���¿��� �ٷ� 5-2 �Ѱ�..*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= FINAL_CLEAN_STATE_START_HOT_TEMP )*/
                if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_final_clean_start_hot_temp )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step = 5;
                }
                else
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
            }
            else{}

            break;


        case 1:

            /*..hui [23-8-24���� 4:17:47] �������� NOS 5-3 OFF..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-8-24���� 4:18:24] �µ� ������������ ���� ����..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= FINAL_CLEAN_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_final_clean_start_hot_temp )
            {
                gu16_final_clean_timer++;

                if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }
            else
            {
                gu16_final_clean_max_timer++;

                /*..hui [23-8-11���� 2:06:34] �켱 �ִ� 3������..*/
                /*..hui [23-8-11���� 5:31:02] ���� ���� 1�д� �뷫 260cc == 2���̸� 520cc == �¼� 1������ ����..*/
                /*..hui [23-8-24���� 3:04:50] 3������ ����.. ����ȯ�����..*/
                if( gu16_final_clean_max_timer >= HOT_CIRCULATION_MAX_TIME )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            break;

        case 3:

            /*..hui [23-8-24���� 4:25:38] ���� ����. .�������� ��ȯ ����..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 4:

            /*..hui [23-8-24���� 4:26:46] �������� NOS 5-3 ON..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;


        case 5:

            /*..hui [23-5-15���� 7:50:38] ��� �ǵ� 5-1 ON..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}


            break;

        case 6:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-1�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_final_clean_timer++;
            }
            else
            {
                gu16_final_clean_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_final_clean_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }

            /*..hui [23-11-24���� 2:35:53] ��ũ ���� ���� Ȯ���ϱ� ���� 10�� ����..*/
            /*if( gu16_final_clean_timer >= 500 )*/
            /*if( gu16_final_clean_timer >= 250 )*/
            if( gu16_final_clean_timer >= 200 )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            #if 0
            /*if( gu16_final_clean_timer <= 300 )*/
            /*if( gu16_final_clean_timer <= 170 )*/
            if( gu16_final_clean_timer <= 150 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 7:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_final_clean_timer++;

            /*if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_final_clean_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
                /*down_tray_motor();*/
            }
            else{}

            break;

        case 8:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorDOWN == CLEAR )
                {
                    /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                    up_tray_motor();
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else
                {
                    gu16_final_clean_timer++;

                    if( gu16_final_clean_timer >= 600 )
                    {
                        gu16_final_clean_timer = 0;
                        gu16_final_clean_max_timer = 0;
                        gu8_final_clean_step = 10;
                    }
                    else{}
                }
            }
            else
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step = 10;
            }

            break;

        case 9:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else
            {
                gu16_final_clean_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_final_clean_timer >= 600 )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }

            break;

        case 10:

            /*..hui [23-5-15���� 7:17:17] ��� �ǵ� 5-1 OFF..*/
            /*..hui [23-5-15���� 7:17:02] ��� �ǵ� 5-2 ON..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 11:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-2�� �л� ����..*/
            /*if(u8DrainWaterLevel == DRAIN_LEVEL_HIGH)*/
            /*if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR )*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_final_clean_timer++;
            }
            else
            {
                gu16_final_clean_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu16_final_clean_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }

            /*..hui [23-11-24���� 2:35:53] ��ũ ���� ���� Ȯ���ϱ� ���� 10�� ����..*/
            /*if( gu16_final_clean_timer >= 500 )*/
            /*if( gu16_final_clean_timer >= 250 )*/
            if( gu16_final_clean_timer >= 200 )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            #if 0
            /*if( gu16_final_clean_timer <= 300 )*/
            /*if( gu16_final_clean_timer <= 170 )*/
            if( gu16_final_clean_timer <= 150 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif

            break;

        case 12:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_final_clean_timer++;

            /*if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [23-7-26���� 4:19:43] �л��ִ� ����.. ����� �Ǵ��� Ȯ���غ��� ��..*/
            /*..hui [23-7-26���� 4:20:02] �������� ��������NOS ���� �������������� �� ��� ����..*/
            /*if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_final_clean_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 13:

            /*..hui [23-5-15���� 7:55:57] ��� 5-2 OFF..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 14:

            /*..hui [23-5-15���� 7:55:37] ��� 5-3 OFF, 6-2 OFF..*/
            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else{}

            break;

        case 15:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorUP == CLEAR )
                {
                    /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
                    down_tray_motor();
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else
                {
                    gu16_final_clean_timer++;

                    if( gu16_final_clean_timer >= 600 )
                    {
                        gu16_final_clean_timer = 0;
                        gu16_final_clean_max_timer = 0;
                        gu8_final_clean_step = 17;
                    }
                    else{}
                }
            }
            else
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step = 17;
            }

            break;

        case 16:

            /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_THROW )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;
            }
            else
            {
                gu16_final_clean_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_final_clean_timer >= 600 )
                {
                    gu16_final_clean_timer = 0;
                    gu16_final_clean_max_timer = 0;
                    gu8_final_clean_step++;
                }
                else{}
            }

            break;

        case 17:

            gu16_final_clean_timer++;

            if( gu16_final_clean_timer >= 10 )
            {
                gu16_final_clean_timer = 0;
                gu16_final_clean_max_timer = 0;
                gu8_final_clean_step++;

                /*..hui [23-9-6���� 4:20:55] ���� ������״� ��������..*/
                /*..hui [24-1-31���� 4:50:42] ���� ������ ����������..*/
                /*F_IR = SET;*/
            }
            else{}

            break;

        case 18:

            gu16_final_clean_timer = 0;
            gu16_final_clean_max_timer = 0;
            gu8_final_clean_step = 0;

            /*..hui [23-5-15���� 7:54:29] ���� ��ô �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_final_clean_timer = 0;
            gu8_final_clean_step = 0;

        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void init_ice_ster(void)
{
    gu16_prepare_ster_timer = 0;
    gu16_prepare_ster_max_timer = 0;
    gu8_prepare_ster_step = 0;

    gu16_hot_spray_timer = 0;
    gu16_hot_spray_max_timer = 0;
    gu8_hot_spray_step = 0;

    gu16_overheat_circul_timer = 0;
    gu8_overheat_circul_step = 0;

    gu16_lukewarm_spray_timer = 0;
    gu16_lukewarm_spray_max_timer = 0;
    gu8_lukewarm_spray_step = 0;

    gu16_final_clean_timer = 0;
    gu16_final_clean_max_timer = 0;
    gu8_final_clean_step = 0;

    gu8_ice_tray_prepare_step = 0;
    gu16_ice_tray_prepare_timer = 0;
    gu32_ice_tray_prepare_max_timer = 0;

    gu8_ice_tray_clean_step = 0;
    gu16_ice_tray_clean_timer = 0;
    gu32_ice_tray_clean_max_timer = 0;

    gu16_melt_ice_timer = 0;
    gu32_melt_ice_max_timer = 0;
    gu8_melt_ice_step = 0;

    gu16_melt_ice_prepare_timer = 0;
    gu32_melt_ice_prepare_max_timer = 0;
    gu8_melt_ice_prepare_step = 0;

    gu16_wait_finish_timer = 0;
    gu16_wait_finish_max_timer = 0;
    gu8_wait_finish_step = 0;

    /*..hui [24-1-29���� 3:35:24] ����׸�� �������̸� ����..*/
    bit_ice_ster_test_debug_start = CLEAR;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void manual_disable_timer(void)
{
    gu16_manual_minute++;

    if( gu16_manual_minute >= 36000 )
    {
        gu16_manual_minute = 0;
        gu16_manual_hour++;
    }
    else{}

    if( gu16_manual_hour >= 24 )
    {
        gu16_manual_hour = 0;
        gu8_manual_operation_count = 0;
    }
    else{}
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void hot_ster_temp_decision(void)
{
    #if 0
    if( F_IceFull == SET )
    {
        /*..hui [23-9-6���� 4:50:17] �����ϴ� ������ �����̸� ������ 75����..*/
        gu8_hot_ster_temp_mode = HOT_STER_TEMP_HIGH_MODE;
    }
    else
    {
        if( bit_hot_ster_ice_full == SET )
        {
            /*..hui [23-8-28���� 11:37:54] ���� �������� & ���� ���� ��� 75���� ��ô..*/
            /*..hui [23-9-6���� 4:14:07] ������ �����־ �������¿� ���� �µ� ����.. ����ȯ �����..*/
            gu8_hot_ster_temp_mode = HOT_STER_TEMP_HIGH_MODE;
        }
        else
        {
            /*..hui [23-8-28���� 11:38:22] ���� �������� �ƴϰų� ���� ���� 7�� �̻� �־��� ��� 45���� ��ô..*/
            gu8_hot_ster_temp_mode = HOT_STER_TEMP_LOW_MODE;
        }
    }
    #endif
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 prepare_melt_ice(void)
{
    U8 mu8_return = 0;

    switch( gu8_melt_ice_prepare_step )
    {
        case 0:

            /*..hui [23-10-17���� 11:18:31] �ǵ��� ����..*/
            /*..hui [23-10-17���� 11:19:19] ������� �¼����� ����.. 66�� OFF, 60�� ON..*/
            gu16_melt_ice_prepare_timer++;

            if( gu16_melt_ice_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else{}

            break;

        case 1:

            gu16_melt_ice_prepare_timer++;

            if( gu16_melt_ice_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-10-17���� 11:20:02] ������ ���������� ���.. �ִ� ��� �ð��� 1�ð� 30��..*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_FULL )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else
            {
                gu32_melt_ice_prepare_max_timer++;

                if( gu32_melt_ice_prepare_max_timer >= ICE_MELT_FEED_MAX_TIME )
                {
                    /*..hui [23-10-17���� 11:23:54] �켱�� �׳� �����°ɷ�..*/
                    finish_ice_ster();
                }
                else{}
            }

            break;

        case 3:

            /*..hui [24-1-25���� 5:53:33] ���̽�Ʈ���� ��ô ���� �µ� ���� �߰�..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= MELT_ICE_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree >= gu8_mlet_ice_start_hot_temp )
            {
                gu16_melt_ice_prepare_timer++;

                if( gu16_melt_ice_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_melt_ice_prepare_timer = 0;
                    gu32_melt_ice_prepare_max_timer = 0;
                    gu8_melt_ice_prepare_step++;
                }
                else{}
            }
            else
            {
                gu32_melt_ice_prepare_max_timer++;

                /*..hui [23-11-8���� 3:45:01] �¼� ���� �ִ� �ð��� 30��..*/
                if( gu32_melt_ice_prepare_max_timer >= 18000 )
                {
                    gu16_melt_ice_prepare_timer = 0;
                    gu32_melt_ice_prepare_max_timer = 0;
                    gu8_melt_ice_prepare_step++;
                }
                else{}
            }

            break;

        case 4:

            /*if( gu8_Cold_Temperature_One_Degree <= 20 )*/
            if( gu8_Cold_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else
            {
                gu32_melt_ice_prepare_max_timer++;

                /*..hui [23-10-23���� 1:57:10] �ð� ���ð� �ִ� 1�ð�..*/
                if( gu32_melt_ice_prepare_max_timer >= 36000 )
                {
                    gu16_melt_ice_prepare_timer = 0;
                    gu32_melt_ice_prepare_max_timer = 0;
                    gu8_melt_ice_prepare_step++;
                }
                else{}
            }

            break;

        case 5:

            if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else
            {
                /*..hui [23-5-22���� 11:38:20] �巹�� ��� �ִ� �ð��� �켱 5������..*/
                gu16_melt_ice_prepare_timer++;

                if( gu16_melt_ice_prepare_timer >= 3000 )
                {
                    gu16_melt_ice_prepare_timer = 0;
                    gu32_melt_ice_prepare_max_timer = 0;
                    gu8_melt_ice_prepare_step++;
                }
                else{}
            }

            break;

        case 6:

            gu16_melt_ice_prepare_timer++;

            if( gu16_melt_ice_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_prepare_timer = 0;
                gu32_melt_ice_prepare_max_timer = 0;
                gu8_melt_ice_prepare_step++;
            }
            else{}

            break;

        case 7:

            gu16_melt_ice_prepare_timer = 0;
            gu32_melt_ice_prepare_max_timer = 0;
            gu8_melt_ice_prepare_step = 0;

            /*..hui [23-10-17���� 11:22:52] ���� ���� �غ��۾� �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_melt_ice_prepare_timer = 0;
            gu32_melt_ice_prepare_max_timer = 0;
            gu8_melt_ice_prepare_step = 0;

        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 melt_ice(void)
{
    U8 mu8_return = 0;

    switch( gu8_melt_ice_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:39:52] ���..*/
            /*..hui [23-10-17���� 2:13:09] �����Ʈ ���� ���� ���·� ����..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 1:

            /*..hui [23-10-17���� 11:36:33] ���� ���� OFF ���¿��� ����..*/
            /*..hui [23-10-17���� 11:40:39] �¼� �Լ� �ǵ��� 6-2 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                /*gu8_hot_ster_operation_temp = MELT_ICE_STATE_START_HOT_TEMP;*/

                /*..hui [23-11-8���� 2:10:48] �����翡 ���� ���� ���� ����. ���� ������� ����..*/
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= MELT_ICE_STATE_START_HOT_TEMP )*/
                if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_mlet_ice_start_hot_temp )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;

                    gu8_melt_ice_step = 5;
                }
                else
                {
                    /*..hui [23-10-23���� 11:16:59] �ƴϸ� 45������ �������� ��ȯ�� ����..*/
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;

                    gu8_melt_ice_step++;
                }
            }
            else{}

            break;

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

        case 2:

            /*..hui [23-10-17���� 2:09:06] ���..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 3:

            /*..hui [23-10-17���� 11:41:17] 55�� ���� �ɶ����� ���� ����..*/
            /*..hui [23-10-23���� 11:17:14] �������� ���� 45������ �������� ��ȯ..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= MELT_NO_ICE_START_HOT_TEMP )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_hot_ster_operation_temp )*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= MELT_ICE_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_mlet_ice_start_hot_temp )
            {
                gu16_melt_ice_timer++;

                if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }
            else
            {
                gu32_melt_ice_max_timer++;

                /*..hui [23-10-17���� 11:42:56] �غ��۾��ÿ��� �ִ� 2��..*/
                /*if( gu32_melt_ice_max_timer >= MELT_ICE_HOT_CIRCULATION_MAX_TIME )*/
                /*..hui [24-1-31���� 10:13:51] �غ����� �ִ� 10��..*/
                /*if( gu32_melt_ice_max_timer >= HOT_CIRCULATION_MAX_TIME )*/
                /*..hui [24-2-1���� 2:23:19] �غ��� 20�� ����..*/
                if( gu32_melt_ice_max_timer >= MELT_ICE_HOT_CIRCULATION_MAX_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            break;

        case 4:

            /*..hui [23-8-24���� 4:25:38] ���� ����. .�������� ��ȯ ����..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

        case 5:

            /*..hui [23-8-24���� 4:26:46] �������� NOS 5-3 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;



        case 6:

            /*..hui [23-5-15���� 7:50:38] ��� �ǵ� 5-1 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 7:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-1�� �л� ����..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_melt_ice_timer++;
            }
            else
            {
                gu32_melt_ice_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_melt_ice_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }

            if( gu16_melt_ice_timer >= ICE_MELT_TOTAL_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            if( gu16_melt_ice_timer <= ICE_MELT_PUMP_90_PERCENT_TIME )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }


            break;

        case 8:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_melt_ice_timer++;

            /*if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_melt_ice_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 9:

            /*..hui [23-10-17���� 11:47:02] ����ǵ� 5-1 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 10:

            /*..hui [23-10-17���� 11:47:18] ����ǵ� 5-2 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 11:

            /*..hui [23-2-28���� 6:56:22] Ʈ���� ���� ����.. 5-2�� �л� ����..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_melt_ice_timer++;
            }
            else
            {
                gu32_melt_ice_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_melt_ice_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }


            if( gu16_melt_ice_timer >= ICE_MELT_TOTAL_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            if( gu16_melt_ice_timer <= ICE_MELT_PUMP_90_PERCENT_TIME )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }

            break;

        case 12:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_melt_ice_timer++;

            /*if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_melt_ice_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 13:

            /*..hui [23-10-17���� 11:47:02] ����ǵ� 5-2 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 14:

            /*..hui [23-10-17���� 11:47:18] ����ǵ� 5-1 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 15:

            /*..hui [23-10-17���� 11:49:17] Ʈ���� ���� ����.. 5-1�� 2ȸ° �л� ����..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_melt_ice_timer++;
            }
            else
            {
                gu32_melt_ice_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_melt_ice_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }


            if( gu16_melt_ice_timer >= ICE_MELT_TOTAL_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            if( gu16_melt_ice_timer <= ICE_MELT_PUMP_90_PERCENT_TIME )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }



            break;






        case 16:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_melt_ice_timer++;

            /*if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_melt_ice_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 17:

            /*..hui [23-10-17���� 11:47:02] ����ǵ� 5-1 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 18:

            /*..hui [23-10-17���� 11:47:18] ����ǵ� 5-2 ON..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 19:

            /*..hui [23-10-17���� 11:49:17] Ʈ���� ���� ����.. 5-2�� 2ȸ° �л� ����..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_melt_ice_timer++;
            }
            else
            {
                gu32_melt_ice_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_melt_ice_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_melt_ice_timer = 0;
                    gu32_melt_ice_max_timer = 0;
                    gu8_melt_ice_step++;
                }
                else{}
            }


            if( gu16_melt_ice_timer >= ICE_MELT_TOTAL_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            if( gu16_melt_ice_timer <= ICE_MELT_PUMP_90_PERCENT_TIME )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }



            break;


        case 20:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_melt_ice_timer++;

            /*if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_melt_ice_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 21:

            /*..hui [23-10-17���� 11:47:02] ����ǵ� 5-2 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 22:

            /*..hui [23-10-17���� 1:45:29] �������� NOS 5-3 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 23:

            /*..hui [23-10-17���� 1:45:44] �¼� �Լ� �ǵ��� 6-2 OFF..*/
            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;

                /////if( gu8_melt_ice_count == 0 || gu8_melt_ice_count == 1 )
                /*if( gu8_melt_ice_count == 0 || gu8_melt_ice_count == 1 || gu8_melt_ice_count == 2 )*/
                /*if( gu8_melt_ice_count == 0 || gu8_melt_ice_count == 1 )*/
                if( gu8_melt_ice_count == 0 )
                {
                    gu8_melt_ice_step++;
                }
                else
                {
                    gu8_melt_ice_step = 25;
                }
            }
            else{}

            break;

        case 24:

            gu16_melt_ice_timer++;

            if( gu16_melt_ice_timer >= HOT_STER_FEEDER_REVERSE_TEST_TIME )
            {
                gu16_melt_ice_timer = 0;
                gu32_melt_ice_max_timer = 0;
                gu8_melt_ice_step++;
            }
            else{}

            break;

        case 25:

            gu16_melt_ice_timer = 0;
            gu32_melt_ice_max_timer = 0;
            gu8_melt_ice_step = 0;


            /*..hui [23-10-17���� 1:54:12] �غ� �۾� �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_melt_ice_timer = 0;
            gu32_melt_ice_max_timer = 0;
            gu8_melt_ice_step = 0;


        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 wait_finish_clean(void)
{
    U8 mu8_return = 0;

    switch( gu8_wait_finish_step )
    {
        case 0:

            gu16_wait_finish_timer++;

            if( gu16_wait_finish_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_wait_finish_timer = 0;
                gu16_wait_finish_max_timer = 0;
                gu8_wait_finish_step++;
            }
            else{}

            break;

        case 1:

            gu16_wait_finish_timer++;

            /*..hui [24-2-15���� 5:03:20] ��ȯ�� �������� ������ �µ��� ����....*/
            /*..hui [24-2-15���� 5:03:33] �������� ���� �ּ� 10�а��� ���� �� ����..*/
            if( gu16_wait_finish_timer >= 6000 )
            {
                gu16_wait_finish_timer = 0;
                gu16_wait_finish_max_timer = 0;
                gu8_wait_finish_step++;
            }
            else{}

            break;

        case 2:

            if( gu8_Cold_Temperature_One_Degree <= HOT_STER_FINISH_COLD_TEMP
                && gu8_Room_Temperature_One_Degree <= HOT_STER_FINISH_ROOM_TEMP )
            {
                gu16_wait_finish_timer = 0;
                gu16_wait_finish_max_timer = 0;
                gu8_wait_finish_step++;
            }
            else
            {
                gu16_wait_finish_max_timer++;

                /*..hui [23-10-23���� 1:41:04] �켱 �ִ� 1�ð�����..*/
                if( gu16_wait_finish_max_timer >= HOT_STER_FINISH_MAX_TIME )
                {
                    gu16_wait_finish_timer = 0;
                    gu16_wait_finish_max_timer = 0;
                    gu8_wait_finish_step++;
                }
                else{}
            }

            break;

        case 3:

            gu16_wait_finish_timer++;

            if( gu16_wait_finish_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_wait_finish_timer = 0;
                gu16_wait_finish_max_timer = 0;
                gu8_wait_finish_step++;
            }
            else{}

            break;

        case 4:

            gu16_wait_finish_timer = 0;
            gu16_wait_finish_max_timer = 0;
            gu8_wait_finish_step = 0;

            /*..hui [23-10-23���� 1:36:15] ��ǰ ��� �غ� �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_wait_finish_timer = 0;
            gu16_wait_finish_max_timer = 0;
            gu8_wait_finish_step = 0;

        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 prepare_icetray_clean(void)
{
    U8 mu8_return = 0;

    switch( gu8_ice_tray_prepare_step )
    {
        case 0:

            /*..hui [23-10-17���� 11:18:31] �ǵ��� ����..*/
            /*..hui [24-1-24���� 5:29:19] ������� �¼����� ����.. 96�� OFF, 93�� ON..*/
            gu16_ice_tray_prepare_timer++;

            if( gu16_ice_tray_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else{}

            break;

        case 1:

            gu16_ice_tray_prepare_timer++;

            if( gu16_ice_tray_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else{}

            break;

        case 2:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorDOWN == CLEAR )
                {
                    /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                    up_tray_motor();
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else
                {
                    gu16_ice_tray_prepare_timer++;

                    if( gu16_ice_tray_prepare_timer >= 600 )
                    {
                        gu16_ice_tray_prepare_timer = 0;
                        gu32_ice_tray_prepare_max_timer = 0;
                        gu8_ice_tray_prepare_step = 4;
                    }
                    else{}
                }
            }
            else
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step = 4;

            }

            break;

        case 3:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else
            {
                gu16_ice_tray_prepare_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_ice_tray_prepare_timer >= 600 )
                {
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else{}
            }

            break;

        case 4:

            /*..hui [23-10-17���� 11:20:02] ������ ���������� ���.. �ִ� ��� �ð��� 1�ð� 30��..*/
            if( gu8_Room_Water_Level == ROOM_LEVEL_FULL )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else
            {
                gu32_ice_tray_prepare_max_timer++;

                if( gu32_ice_tray_prepare_max_timer >= ICE_MELT_FEED_MAX_TIME )
                {
                    /*..hui [23-10-17���� 11:23:54] �켱�� �׳� �����°ɷ�..*/
                    finish_ice_ster();
                }
                else{}
            }

            break;

        case 5:

            /*..hui [24-1-25���� 5:53:33] ���̽�Ʈ���� ��ô ���� �µ� ���� �߰�..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree >= ICE_TRAY_CLEAN_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree >= gu8_ice_tray_start_hot_temp )
            {
                gu16_ice_tray_prepare_timer++;

                if( gu16_ice_tray_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else{}
            }
            else
            {
                gu32_ice_tray_prepare_max_timer++;

                /*..hui [23-11-8���� 3:45:01] �¼� ���� �ִ� �ð��� 30��..*/
                if( gu32_ice_tray_prepare_max_timer >= 18000 )
                {
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else{}
            }

            break;

        case 6:

            /*if( gu8_Cold_Temperature_One_Degree <= 20 )*/
            if( gu8_Cold_Temperature_One_Degree <= STER_NO_OPERATION_COLD_TEMP )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else
            {
                gu32_ice_tray_prepare_max_timer++;

                /*..hui [23-10-23���� 1:57:10] �ð� ���ð� �ִ� 1�ð�..*/
                if( gu32_ice_tray_prepare_max_timer >= 36000 )
                {
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else{}
            }

            break;

        case 7:

            if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else
            {
                /*..hui [23-5-22���� 11:38:20] �巹�� ��� �ִ� �ð��� �켱 5������..*/
                gu16_ice_tray_prepare_timer++;

                if( gu16_ice_tray_prepare_timer >= 3000 )
                {
                    gu16_ice_tray_prepare_timer = 0;
                    gu32_ice_tray_prepare_max_timer = 0;
                    gu8_ice_tray_prepare_step++;
                }
                else{}
            }

            break;

        case 8:

            gu16_ice_tray_prepare_timer++;

            if( gu16_ice_tray_prepare_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_prepare_timer = 0;
                gu32_ice_tray_prepare_max_timer = 0;
                gu8_ice_tray_prepare_step++;
            }
            else{}

            break;

        case 9:

            gu16_ice_tray_prepare_timer = 0;
            gu32_ice_tray_prepare_max_timer = 0;
            gu8_ice_tray_prepare_step = 0;

            /*..hui [23-10-17���� 11:22:52] ���� ���� �غ��۾� �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_ice_tray_prepare_timer = 0;
            gu32_ice_tray_prepare_max_timer = 0;
            gu8_ice_tray_prepare_step = 0;

        break;

    }

    return mu8_return;
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
U8 icetray_clean(void)
{
    U8 mu8_return = 0;

    switch( gu8_ice_tray_clean_step )
    {
        case 0:

            /*..hui [23-5-15���� 7:39:52] ���..*/
            /*..hui [23-10-17���� 2:13:09] �����Ʈ ���� ���� ���·� ����..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 1:

            /*..hui [23-10-17���� 11:36:33] ���� ���� OFF ���¿��� ����..*/
            /*..hui [23-10-17���� 11:40:39] �¼� �Լ� �ǵ��� 6-2 ON..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                /*if( gu8_Hot_Tank_Temperature_One_Degree <= ICE_TRAY_CLEAN_STATE_START_HOT_TEMP )*/
                if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_ice_tray_start_hot_temp )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;

                    gu8_ice_tray_clean_step = 5;
                }
                else
                {
                    /*..hui [24-1-25���� 9:38:48] �ƴϸ� 93������ ��ȯ�� ����..*/
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;

                    gu8_ice_tray_clean_step++;
                }
            }
            else{}

            break;

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

        case 2:

            /*..hui [23-10-17���� 2:09:06] ���..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 3:

            /*..hui [24-1-25���� 9:39:08] 93�� ���ϱ��� ���� ����..*/
            /*if( gu8_Hot_Tank_Temperature_One_Degree <= ICE_TRAY_CLEAN_STATE_START_HOT_TEMP )*/
            if( gu8_Hot_Tank_Temperature_One_Degree <= gu8_ice_tray_start_hot_temp )
            {
                gu16_ice_tray_clean_timer++;

                if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }
            else
            {
                gu32_ice_tray_clean_max_timer++;

                /*..hui [24-1-25���� 9:39:37] ���̽�Ʈ���� ��ȯ �ִ� 2��..*/
                /*if( gu32_ice_tray_clean_max_timer >= ICE_TRAY_HOT_CIRCULATION_MAX_TIME )*/
                /*..hui [24-1-31���� 10:15:37] ���̽�Ʈ���� ��ô�� �ִ� 10��..*/
                if( gu32_ice_tray_clean_max_timer >= HOT_CIRCULATION_MAX_TIME )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            break;

        case 4:

            /*..hui [23-8-24���� 4:25:38] ���� ����. .�������� ��ȯ ����..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

        case 5:

            /*..hui [23-8-24���� 4:26:46] �������� NOS 5-3 ON..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 6:

            /*..hui [23-5-15���� 7:50:38] ��� �ǵ� 5-1 ON..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 7:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorDOWN == CLEAR )
                {
                    /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
                    up_tray_motor();
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else
                {
                    gu16_ice_tray_clean_timer++;

                    if( gu16_ice_tray_clean_timer >= 600 )
                    {
                        gu16_ice_tray_clean_timer = 0;
                        gu32_ice_tray_clean_max_timer = 0;
                        gu8_ice_tray_clean_step = 9;
                    }
                    else{}
                }
            }
            else
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step = 9;
            }

            break;

        case 8:

            /*..hui [23-7-5���� 7:37:03] Ʈ���� ���� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_MAKING )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else
            {
                gu16_ice_tray_clean_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_ice_tray_clean_timer >= 600 )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }

            break;

        case 9:

            /*..hui [24-1-25���� 9:51:54] Ʈ���� ���� ����.. �������� 5-1�����θ� 3�� ���� �л�..*/
            /*..hui [24-1-25���� 1:05:06] ���⼭ �ü� �巹�� ��굵 5��..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_ice_tray_clean_timer++;
            }
            else
            {
                gu32_ice_tray_clean_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_ice_tray_clean_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }

            if( gu16_ice_tray_clean_timer >= ICE_TRAY_CLEAN_SPRAY_TIME_3_MIN )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;

            #if 0
            if( gu16_ice_tray_clean_timer <= 900 )
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;
            }
            else
            {
                gu8_ster_pump_stage = STER_PUMP_STAGE_80_PERCENT;
            }
            #endif


            break;

        case 10:

            /*..hui [23-2-28���� 6:57:19] ���� ����.. �л� ����..*/
            gu16_ice_tray_clean_timer++;

            /*if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-30���� 5:25:51] ��� ������� ���·� 5�ʰ� ���.. ..*/
            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_AIR_REMOVE_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 11:

            /*..hui [23-10-17���� 11:47:02] ����ǵ� 5-1 OFF..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 12:

            /*..hui [24-1-25���� 9:54:07] �������� NOS ��� 5-3 OFF..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 13:

            /*..hui [24-1-25���� 9:59:19] ���¼�ô ��� 6-2 OFF..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 14:

            /*..hui [24-1-25���� 10:20:04] �� ���ä�� 3�е��� ���..*/
            gu16_ice_tray_clean_timer++;

            if( gu16_ice_tray_clean_timer >= ICE_TRAY_CLEAN_TIME_10_MIN )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 15:

            gu16_ice_tray_clean_timer++;

            /*..hui [24-1-25���� 10:21:41] ���̽� Ʈ���� �Լ� ��� 6-1 ON..*/
            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 16:

            /*..hui [24-1-25���� 10:22:41] Ʈ���� ���� ����..*/
            /*..hui [24-1-25���� 10:22:50] ���� �־ ����������..*/
            if( Bit1_Tray_Pump_Ster_Drain_Full_Off_State == CLEAR && bit_tray_pump_output == SET )
            {
                gu16_ice_tray_clean_timer++;
            }
            else
            {
                gu32_ice_tray_clean_max_timer++;

                /*..hui [24-1-25���� 3:15:22] ���� ���.. 10�гѰ� �������� ������ ���� �ܰ��..*/
                if( gu32_ice_tray_clean_max_timer >= HOT_STER_SAFETY_TIME )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }

            /*..hui [24-1-25���� 10:23:01] �켱 10�ʷ�..*/
            /*if( gu16_ice_tray_clean_timer >= 100 )*/
            /*if( gu16_ice_tray_clean_timer >= 50 )*/
            /*if( gu16_ice_tray_clean_timer >= 150 )*/
            /*if( gu16_ice_tray_clean_timer >= 50 )*/
            /*if( gu16_ice_tray_clean_timer >= 80 )*/
            if( gu16_ice_tray_clean_timer >= 100 )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            gu8_ster_pump_stage = STER_PUMP_STAGE_90_PERCENT;


            break;

        case 17:

            gu16_ice_tray_clean_timer++;

            /*..hui [24-1-25���� 10:23:38] ���� ���� �Լ� ����..*/
            if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else{}

            break;

        case 18:

            gu16_ice_tray_clean_timer++;

            /*..hui [24-1-25���� 10:24:18] Ʈ���� �Լ� ��� 6-1 OFF..*/
            /*if( gu16_ice_tray_clean_timer >= ICE_TANK_STER_DELAY_TIME )*/
            /*..hui [24-1-26���� 9:33:42] ������Ű�� 10�ʰ� ���..*/
            /*if( gu16_ice_tray_clean_timer >= 100 )*/
            /*..hui [24-2-14���� 5:54:24] 30�ʰ� ���..*/
            if( gu16_ice_tray_clean_timer >= 300 )
            {
                if( u8DrainWaterLevel == DRAIN_LEVEL_EMPTY || u8DrainWaterLevel == DRAIN_LEVEL_LOW )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else
                {
                    gu32_ice_tray_clean_max_timer++;

                    if( gu32_ice_tray_clean_max_timer >= HOT_STER_SAFETY_TIME )
                    {
                        gu16_ice_tray_clean_timer = 0;
                        gu32_ice_tray_clean_max_timer = 0;
                        gu8_ice_tray_clean_step++;
                    }
                    else{}
                }
            }
            else{}

            break;

        case 19:

            /*..hui [23-8-24���� 2:21:23] Ʈ���� ��õ� ���̰ų� ������ ���..*/
            if( gu8_ice_system_ok == SET )
            {
                if( F_TrayMotorUP == CLEAR )
                {
                    /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
                    down_tray_motor();
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else
                {
                    gu16_ice_tray_clean_timer++;

                    if( gu16_ice_tray_clean_timer >= 600 )
                    {
                        gu16_ice_tray_clean_timer = 0;
                        gu32_ice_tray_clean_max_timer = 0;
                        gu8_ice_tray_clean_step = 21;
                    }
                    else{}
                }
            }
            else
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step = 21;
            }

            break;

        case 20:

            /*..hui [23-7-5���� 7:41:30] Ʈ���� Ż�� ���� �̵�..*/
            if( gu8IceTrayLEV == ICE_TRAY_POSITION_ICE_THROW )
            {
                gu16_ice_tray_clean_timer = 0;
                gu32_ice_tray_clean_max_timer = 0;
                gu8_ice_tray_clean_step++;
            }
            else
            {
                gu16_ice_tray_clean_timer++;

                /*..hui [23-8-16���� 1:12:24] Ʈ���� �̵� �ִ� �ð� 1��..*/
                if( gu16_ice_tray_clean_timer >= 600 )
                {
                    gu16_ice_tray_clean_timer = 0;
                    gu32_ice_tray_clean_max_timer = 0;
                    gu8_ice_tray_clean_step++;
                }
                else{}
            }

            break;

        case 21:

            gu16_ice_tray_clean_timer = 0;
            gu32_ice_tray_clean_max_timer = 0;
            gu8_ice_tray_clean_step = 0;

            /*..hui [24-1-25���� 10:33:34] ���̽� Ʈ���� ��ô �۾� �Ϸ�..*/
            mu8_return = SET;

            break;

        default:

            gu16_ice_tray_clean_timer = 0;
            gu32_ice_tray_clean_max_timer = 0;
            gu8_ice_tray_clean_step = 0;


        break;

    }

    return mu8_return;
}

/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void sel_start_temp(void)
{
    if( gu8AltitudeStep == ALTITUDE_1_MODE_HIGH )
    {
        gu8_hot_spray_start_hot_temp = ALTITUDE__1__ICE_TANK_STER__HEATER_ON_TEMP;
        gu8_lukewarm_spray_start_hot_temp = 90;
        gu8_final_clean_start_hot_temp = 87;

        gu8_ice_tray_start_hot_temp = ALTITUDE__1__ICE_TRAY_CLEAN__HEATER_ON_TEMP;
        gu8_mlet_ice_start_hot_temp = ALTITUDE__1__MELT_ICE__HEATER_ON_TEMP;
    }
    else if( gu8AltitudeStep == ALTITUDE_2_MODE_MID )
    {
        gu8_hot_spray_start_hot_temp = ALTITUDE__2__ICE_TANK_STER__HEATER_ON_TEMP;
        gu8_lukewarm_spray_start_hot_temp = 87;
        gu8_final_clean_start_hot_temp = 84;

        gu8_ice_tray_start_hot_temp = ALTITUDE__2__ICE_TRAY_CLEAN__HEATER_ON_TEMP;
        gu8_mlet_ice_start_hot_temp = ALTITUDE__2__MELT_ICE__HEATER_ON_TEMP;
    }
    else if( gu8AltitudeStep == ALTITUDE_3_MODE_LOW )
    {
        gu8_hot_spray_start_hot_temp = ALTITUDE__3__ICE_TANK_STER__HEATER_ON_TEMP;
        gu8_lukewarm_spray_start_hot_temp = 84;
        gu8_final_clean_start_hot_temp = 81;

        gu8_ice_tray_start_hot_temp = ALTITUDE__3__ICE_TRAY_CLEAN__HEATER_ON_TEMP;
        gu8_mlet_ice_start_hot_temp = ALTITUDE__3__MELT_ICE__HEATER_ON_TEMP;
    }
    else /*if( gu8AltitudeStep == ALTITUDE_4_MODE_VERY_LOW )*/
    {
        gu8_hot_spray_start_hot_temp = ALTITUDE__4__ICE_TANK_STER__HEATER_ON_TEMP;
        gu8_lukewarm_spray_start_hot_temp = 82;
        gu8_final_clean_start_hot_temp = 79;

        gu8_ice_tray_start_hot_temp = ALTITUDE__4__ICE_TRAY_CLEAN__HEATER_ON_TEMP;
        gu8_mlet_ice_start_hot_temp = ALTITUDE__4__MELT_ICE__HEATER_ON_TEMP;
    }
}


/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/


