/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Main.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  : AT+CONNECT=74F07DB01010
***********************************************************************************************************************/
#include    "Macrodriver.h"
#include    "Global_Variable.h"
#include    "Port_Define.h"
#include    "valve_air_vent.h"


void output_valve_air_vent(void);





TYPE_WORD          U16AirValveOnW;
#define            u16AirValveON                                 U16AirValveOnW.word
#define            u8AirValveOn_L                                U16AirValveOnW.byte[0]
#define            u8AirValveOn_H                                U16AirValveOnW.byte[1]
#define            Bit0_Air_Valve_Feed_On_State                  U16AirValveOnW.Bit.b0
#define            Bit1_Air_Valve_Extract_On_State               U16AirValveOnW.Bit.b1
#define            Bit2_Air_Valve_Ice_Tray_Input_On_State        U16AirValveOnW.Bit.b2
#define            Bit3_Air_Valve_Hot_Ster_On_State              U16AirValveOnW.Bit.b3
#define            Bit4_Air_Valve_Auto_Drain_On_State            U16AirValveOnW.Bit.b4
#define            Bit5_Air_Valve_Manual_Drain_On_State          U16AirValveOnW.Bit.b5
#define            Bit6_Air_Valve_Install_Flushing_On_State      U16AirValveOnW.Bit.b6
#define            Bit7_Air_Valve_Water_lushing_On_State         U16AirValveOnW.Bit.b7
#define            Bit8_Air_Valve_Acid_Clean_On_State            U16AirValveOnW.Bit.b8






TYPE_BYTE          U8AirValveOFFB;
#define            u8AirValveOFF                                 U8AirValveOFFB.byte
#define            Bit0_Air_Valve_Off_State                      U8AirValveOFFB.Bit.b0

bit bit_air_vent_valve_output;
U16 gu16_air_vent_delay_timer;
bit bit_air_vent_close_delay;
/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/
void output_valve_air_vent(void)
{

    /*..hui [23-7-28���� 2:38:43] �������Ҷ��� �ݴ´�(��������)..*/
    /*Bit0_Air_Valve_Feed_On_State = bit_feed_output;*/


    /*..hui [24-3-5���� 2:25:30] �ǵ��� ON �ð� 3�ð� 40�� ��� �� 20�е��� ������ ON..*/
    /*..hui [24-3-5���� 2:25:47] Ȥ�ó� ���������� �ҷ��̸� �ٵ�� �� �������� �������� �ɸ����ϱ� ����..*/
    if( bit_feed_output == SET )
    {
        if( gu32_feed_overheat_on_timer >= HIGH_LEVEL_FAULT_CHECK_TIME )
        {
            Bit0_Air_Valve_Feed_On_State = bit_feed_output;
        }
        else
        {
            Bit0_Air_Valve_Feed_On_State = CLEAR;
        }
    }
    else
    {
        Bit0_Air_Valve_Feed_On_State = CLEAR;
    }




    Bit1_Air_Valve_Extract_On_State = F_WaterOut;


    if( gu8IceStep >= STATE_14_CHECK_ICE_TRAY_HZ && gu8IceStep <= STATE_20_WATER_IN_ICE_TRAY )
    {
        Bit2_Air_Valve_Ice_Tray_Input_On_State = SET;
    }
    else
    {
        Bit2_Air_Valve_Ice_Tray_Input_On_State = CLEAR;
    }


    if( bit_ice_tank_ster_start == SET )
    {
        /*if( gu8_ice_ster_mode >= STER_MODE_HOT_SPRAY_STATE )*/
        /*if( gu8_ice_ster_mode >= STER_MODE_CIRCULATION_HOT_STATE )*/
        /*..hui [23-10-12���� 5:29:26] �غ� �ܰ迡�� �巹�� ��ũ�� �� �ִ� ��� �߰��Ʊ� ������..*/
        if( gu8_ice_ster_mode >= STER_MODE_PREPARE )
        {
            Bit3_Air_Valve_Hot_Ster_On_State = SET;
        }
        else
        {
            Bit3_Air_Valve_Hot_Ster_On_State = CLEAR;
        }
    }
    else
    {
        Bit3_Air_Valve_Hot_Ster_On_State = CLEAR;
    }


    Bit4_Air_Valve_Auto_Drain_On_State = F_DrainStatus;

    /*..hui [23-8-14���� 1:25:44] ���������..*/
    Bit5_Air_Valve_Manual_Drain_On_State = bit_manual_drain_start;


    /*..hui [23-8-25���� 9:51:01] �÷����Ҷ�.. �׻� ����..*/
    /*..hui [23-8-25���� 10:04:07] ��ũ ����� �ؾ��ϰ�.. ������ȯ��� ������ ȿ������? ����ȯ �����....*/
    if( gu8_flushing_mode == FLUSHING_MAIN_STATE )
    {
        Bit6_Air_Valve_Install_Flushing_On_State = bit_flushing_start;
    }
    else if( gu8_flushing_mode == FLUSHING_TANK_STATE )
    {
        Bit6_Air_Valve_Install_Flushing_On_State = bit_flushing_tank_start;
    }
    else
    {
        Bit6_Air_Valve_Install_Flushing_On_State = CLEAR;
    }

    /*..hui [23-9-4���� 4:25:30] ���� �÷����Ҷ�.. ����ȯ�����.. �켱 �ʵ��׽�Ʈ�� ON�ϴ°ɷ�..*/
    /*..hui [23-9-4���� 4:25:37] ���߿� FEED-NOS�� ����Ǹ� ������..*/
    if( bit_flushing_water_start == SET )
    {
        if( gu8_water_flushing_step >= 1 && gu8_water_flushing_step <= 9 )
        {
            Bit7_Air_Valve_Water_lushing_On_State = SET;
        }
        else
        {
            Bit7_Air_Valve_Water_lushing_On_State = CLEAR;
        }
    }
    else
    {
        Bit7_Air_Valve_Water_lushing_On_State = CLEAR;
    }

    /*..hui [24-5-23���� 7:05:42] ������ �����Ҷ�..*/
    if( bit_acid_clean_start == SET )
    {
        if( gu8_acid_clean_mode > ACID_CLEAN_NONE_STATE )
        {
            Bit8_Air_Valve_Acid_Clean_On_State = Bit5_CD_Drain_Acid_On_State;
        }
        else
        {
            Bit8_Air_Valve_Acid_Clean_On_State = CLEAR;
        }
    }
    else
    {
        Bit8_Air_Valve_Acid_Clean_On_State = CLEAR;
    }

/***********************************************************************************************/
/***********************************************************************************************/
/***********************************************************************************************/

    Bit0_Air_Valve_Off_State = CLEAR;


/***********************************************************************************************/
/***********************************************************************************************/
/***********************************************************************************************/
    if (u8AirValveOFF > 0)
    {
        pVALVE_AIR_VENT = CLEAR;      /*off*/
        bit_air_vent_valve_output = CLEAR;
    }
    else
    {
        /*if (u8AirValveON > 0)*/
        if (u16AirValveON > 0)
        {
            pVALVE_AIR_VENT = SET;    /*on*/
            bit_air_vent_valve_output = SET;
            gu16_air_vent_delay_timer = 0;

            /*..hui [23-8-25���� 9:56:48] �� �����ϰ� ������ 1�� ���� �� OFF�ϵ���..*/
            if( Bit1_Air_Valve_Extract_On_State == SET )
            {
                bit_air_vent_close_delay = SET;
            }
            else{}
        }
        else
        {
            if( bit_air_vent_close_delay == SET )
            {
                gu16_air_vent_delay_timer++;

                /*..hui [23-6-15���� 12:00:42] ������� �ǵ� ������ 1���� �ݴ°ɷ�.. ��������..*/
                if( gu16_air_vent_delay_timer >= AIR_VENT_DELAY_TIME )
                {
                    pVALVE_AIR_VENT = CLEAR;  /*off*/
                    bit_air_vent_valve_output = CLEAR;
                    gu16_air_vent_delay_timer = 0;

                    bit_air_vent_close_delay = CLEAR;
                }
                else{}
            }
            else
            {
                pVALVE_AIR_VENT = CLEAR;  /*off*/
                bit_air_vent_valve_output = CLEAR;
                gu16_air_vent_delay_timer = 0;
            }
        }
    }


    #if 0
    if (u8AirValveOFF > 0)
    {
        pVALVE_AIR_VENT = CLEAR;      /*off*/
    }
    else
    {
        if (u8AirValveON > 0)
        {
            pVALVE_AIR_VENT = SET;    /*on*/
        }
        else
        {
            pVALVE_AIR_VENT = CLEAR;  /*off*/
        }
    }
    #endif
/***********************************************************************************************/
}





/***********************************************************************************************************************
* Function Name: System_ini
* Description  :
***********************************************************************************************************************/




