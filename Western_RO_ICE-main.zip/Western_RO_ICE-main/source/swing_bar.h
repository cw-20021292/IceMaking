/***********************************************************************************************************************
* Version      : BAS25(STEP_UP)
* File Name    : Remote_Comm.c
* Device(s)    : R5F100MG
* Creation Date: 2015/07/31
* Copyright    : Coway_Electronics Engineering Team (DH,Kim)
* Description  :
***********************************************************************************************************************/
#ifndef _SWING_BAR_H_
#define _SWING_BAR_H_

//
extern TYPE_BYTE       U8OperationB;
#define         u8Operation                                       U8OperationB.byte
#define         Bit0_Cold_Operation_Disable_State                 U8OperationB.Bit.b0
#define         Bit1_Hot_Operation_Disable_State                  U8OperationB.Bit.b1
#define         Bit2_Ice_Operation_Disable_State                  U8OperationB.Bit.b2
#define         Bit3_Ice_Tank_Ster_Operation_Disable_State        U8OperationB.Bit.b3






extern bit F_ErrTrayMotor_DualInital;
//extern bit F_ColdDIR;
extern U16 gu16IceMakeTime;
extern bit F_Safety_Routine;
extern ICE_STEP gu8IceStep;



//#define CRISTAL_ON          6                      // ���ڼ� ON
//#define CRISTAL_OFF         4                      // ���ڼ� OFF

//#define CRISTAL_ON            4                      // ���ڼ� ON
//#define CRISTAL_OFF           2                      // ���ڼ� OFF

//#define CRISTAL_ON            2                      // ���ڼ� ON
//#define CRISTAL_OFF           4                      // ���ڼ� OFF

#define CRISTAL_ON            2                      // ���ڼ� ON
#define CRISTAL_OFF           6                      // ���ڼ� OFF



#endif
